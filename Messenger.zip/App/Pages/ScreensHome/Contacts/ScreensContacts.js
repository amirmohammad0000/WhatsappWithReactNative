//////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import AppContactsPage from "./Pages/AppContactsPage/AppContactsPage";
import AddNewGroup from "./Pages/AddNewGroup/AddNewGroup";
import ScreensArchive from "./Pages/Archive/ScreensArchive";
import ConnectedDevices from "./Pages/ConnectedDevices/ConnectedDevices";
import ScreensGroupChat from "./Pages/GroupChat/ScreensGroupChat";
import NewReleaseList from "./Pages/NewReleaseList/NewReleaseList";
import SearchContacts from "./Pages/SearchContacts/SearchContacts";
import SelectContacts from "./Pages/SelectContacts/SelectContacts";
import ScreensSettings from "./Pages/Settings/ScreensSettings";
import StarredMessages from "./Pages/StarredMessages/StarredMessages";
import ScreensUserChat from "./Pages/UserChat/ScreensUserChat";
//////////////////////////////////////////////////////////////////////// End Section Import

const Stack = createNativeStackNavigator();

//////////////////////////////////////////////////////////////////////// Start Section Class
export default class ScreensContacts extends React.Component {
    render() {
        return (
            <Stack.Navigator>
                {/* Start Section Stack */}
                <Stack.Screen
                    name="AppContactsPage"
                    component={AppContactsPage}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="AddNewGroup"
                    component={AddNewGroup}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="ScreensArchive"
                    component={ScreensArchive}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="ConnectedDevices"
                    component={ConnectedDevices}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="ScreensGroupChat"
                    component={ScreensGroupChat}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="NewReleaseList"
                    component={NewReleaseList}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="SearchContacts"
                    component={SearchContacts}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="SelectContacts"
                    component={SelectContacts}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="ScreensSettings"
                    component={ScreensSettings}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="StarredMessages"
                    component={StarredMessages}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="ScreensUserChat"
                    component={ScreensUserChat}
                    options={{
                        headerShown: false,
                    }}
                />
                {/* End Section Stack */}
            </Stack.Navigator>
        );
    }
}
//////////////////////////////////////////////////////////////////////// End Section Class