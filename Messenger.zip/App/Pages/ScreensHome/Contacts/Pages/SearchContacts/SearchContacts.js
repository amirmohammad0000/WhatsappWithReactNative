﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity, FlatList } from "react-native";
import { styles } from "./Css/CssSearchContacts";
import { NativeBaseProvider, Box, Input, Text } from "native-base";
import { FontAwesome, FontAwesome5, MaterialCommunityIcons, Feather, AntDesign, Ionicons, MaterialIcons } from "@expo/vector-icons";
import SingleContacts from "./../AppContactsPage/Components/SingleContacts";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class SearchContacts extends React.Component {
    state = {
        data: [
            {
                id: "1",
                StateChat: "UserChat",
                ImageProfile: require("./../../../../../Assets/Images/ImageSingleProfile.png"),
                NameChat: "Amir",
                TimeLastMessage: "12:45",
                LastMessages: "پیام ها و تماس ها سرتاسر رمزگذاری شده اند",
            },
            {
                id: "2",
                StateChat: "GroupChat",
                ImageProfile: require("./../../../../../Assets/Images/ImageGroupProfile.png"),
                NameChat: "کامپیوتر",
                TimeLastMessage: "2021/10/18",
                LastMessages: "کسی گروه ساختمان داده رو داره +98 914 056 7646",
            },
        ],
        StateArchive: true,
        ValueInputSearch: "",
    };

    FuncGoToPageAppContactsPage = () => {
        this.props.navigation.goBack();
    };

    FuncSetValueInputSearch = (text) => {
        this.setState({
            ValueInputSearch: text,
        });
    };

    FuncRemoveValue = () => {
        this.setState({
            ValueInputSearch: "",
        });
    };

    FuncGoToPageArchive = () => {
        this.props.navigation.navigate("ScreensArchive");
    };

    FuncFilterImageSearch = () => {

    };

    FuncFilterVideoSearch = () => {

    };

    FuncFilterLinkSearch = () => {

    };

    FuncFilterGifSearch = () => {

    };

    FuncFilterVoiceSearch = () => {

    };

    FuncFilterDocumentSearch = () => {

    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <Box name="App" style={styles.app}>
                    {/* Start Section Header */}
                    <Box nmae="Header" style={styles.header}>
                        <Box name="Box_Top_Header" style={styles.box_top_header}>
                            <TouchableOpacity onPress={() => {
                                this.FuncGoToPageAppContactsPage();
                            }}>
                                <AntDesign name="arrowright" style={styles.icon_back} />
                            </TouchableOpacity>

                            <Input
                                placeholder="جستجو ..."
                                variant="ghost"
                                width="80%"
                                height="100%"
                                value={this.state.ValueInputSearch}
                                onChangeText={(text) => {
                                    this.FuncSetValueInputSearch(text);
                                }}
                            />

                            <TouchableOpacity onPress={() => {
                                this.FuncRemoveValue();
                            }}>
                                <FontAwesome name="remove" style={styles.icon_delete} />
                            </TouchableOpacity>
                        </Box>

                        <Box name="Box_Bottom_Header" style={styles.box_bottom_header}>
                            <Box name="Box_Top_Search" style={styles.box_top_search}>
                                <TouchableOpacity
                                    name="Box_Search_Image"
                                    style={styles.box_search}
                                    onPress={() => {
                                        this.FuncFilterImageSearch();
                                    }}                                >
                                    <MaterialIcons name="image" style={styles.icon_search} />

                                    <Text style={styles.text_search}>عکس ها</Text>
                                </TouchableOpacity>

                                <TouchableOpacity
                                    name="Box_Search_Video"
                                    style={styles.box_search}
                                    onPress={() => {
                                        this.FuncFilterVideoSearch();
                                    }}>
                                    <FontAwesome5 name="video" style={styles.icon_search} />

                                    <Text style={styles.text_search}>ویدیو ها</Text>
                                </TouchableOpacity>

                                <TouchableOpacity
                                    name="Box_Search_Links"
                                    style={styles.box_search}
                                    onPress={() => {
                                        this.FuncFilterLinkSearch();
                                    }}>
                                    <Feather name="link-2" style={styles.icon_search} />

                                    <Text style={styles.text_search}>پیوند ها</Text>
                                </TouchableOpacity>

                                <TouchableOpacity
                                    name="Box_Search_Gif"
                                    style={styles.box_search}
                                    onPress={() => {
                                        this.FuncFilterGifSearch();
                                    }}>
                                    <MaterialCommunityIcons name="gif" style={styles.icon_search} />

                                    <Text style={styles.text_search}>ها GIF</Text>
                                </TouchableOpacity>
                            </Box>

                            <Box
                                name="Box_Bottom_Search"
                                style={styles.box_bottom_search}
                                onPress={() => {
                                    this.FuncFilterVoiceSearch();
                                }}>
                                <TouchableOpacity name="Box_Search_Voice" style={styles.box_search}>
                                    <MaterialIcons name="record-voice-over" style={styles.icon_search} />

                                    <Text style={styles.text_search}>صدا</Text>
                                </TouchableOpacity>

                                <TouchableOpacity
                                    name="Box_Search_Documents"
                                    style={styles.box_search}
                                    onPress={() => {
                                        this.FuncFilterDocumentSearch();
                                    }}>
                                    <Ionicons name="document-text" style={styles.icon_search} />

                                    <Text style={styles.text_search}>اسناد</Text>
                                </TouchableOpacity>
                            </Box>
                        </Box>
                    </Box>
                    {/* End Section Header */}

                    {/* Start Section Content */}
                    <Box name="Content" style={styles.content}>
                        {
                            this.state.StateArchive === false ?
                                null
                                :
                                <TouchableOpacity
                                    name="Box_Archive"
                                    style={styles.box_archive}
                                    onPress={() => {
                                        this.FuncGoToPageArchive();
                                    }}                                        >
                                    <Ionicons name="archive-outline" style={styles.icon_archive} />

                                    <Text style={styles.text_archive}>بایگانی شده</Text>
                                </TouchableOpacity>
                        }

                        <Box name="Box_Flat_List" style={styles.box_flat_list}>
                            <FlatList data={this.state.data} renderItem={({ item }) => (
                                <SingleContacts
                                    navigation={this.props.navigation}
                                    ImageProfile={item.ImageProfile}
                                    NameChat={item.NameChat}
                                    TimeLastMessage={item.TimeLastMessage}
                                    LastMessages={item.LastMessages}
                                    StateChat={item.StateChat} />
                            )} />
                        </Box>
                    </Box>
                    {/* End Section Content */}
                </Box>
                {/* End Section App */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class