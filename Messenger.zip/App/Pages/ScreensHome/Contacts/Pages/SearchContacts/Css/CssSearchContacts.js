/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import { StyleSheet } from "react-native";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Style
const styles = StyleSheet.create({
    //////////////////////////////// Start Style App
    app: {
        width: "100%",
        height: "100%",
    },
    //////////////////////////////// End Style App

    //////////////////////////////// Start Style Header
    header: {
        width: "100%",
        height: 160,
    },

    box_top_header: {
        width: "100%",
        height: "40%",
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-evenly",
        backgroundColor: "#ffffff99",
        borderBottomColor: "#ddd",
        borderBottomWidth: 1,
    },

    icon_delete: {
        color: "#777",
        fontSize: 25,
    },

    icon_back: {
        color: "#777",
        fontSize: 25,
    },

    box_bottom_header: {
        width: "100%",
        height: "60%",
        backgroundColor: "#ffffff99",
    },

    box_top_search: {
        width: "100%",
        height: "50%",
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "flex-start",
        paddingLeft: 15,
    },

    box_bottom_search: {
        width: "100%",
        height: "50%",
        flexDirection: "row",
        alignItems: "flex-start",
        justifyContent: "flex-start",
        paddingLeft: 15,
    },

    box_search: {
        height: 30,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "#ddd",
        borderRadius: 1000,
        padding: 10,
        marginRight: 8,
    },

    icon_search: {
        color: "#666",
        fontSize: 16,
        paddingLeft: 8,
    },

    text_search: {
        color: "#555",
        fontSize: 14,
    },
    //////////////////////////////// End Style Header

    //////////////////////////////// Start Style Content
    content: {
        width: "100%",
        height: "80%",
    },

    box_archive: {
        width: "100%",
        height: 50,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "flex-start",
    },

    icon_archive: {
        color: "#080",
        fontSize: 20,
        paddingRight: 30,
    },

    text_archive: {
        color: "#222",
        fontSize: 18,
        paddingRight: 30,
    },

    box_flat_list: {
        width: "100%",
        height: "80%",
    },
    //////////////////////////////// End Style Content
});
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Style
export { styles };