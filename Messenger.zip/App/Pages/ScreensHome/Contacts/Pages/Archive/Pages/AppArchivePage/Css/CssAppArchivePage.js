/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import { StyleSheet } from "react-native";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Style
const styles = StyleSheet.create({
    //////////////////////////////// Start Style App
    app: {
        width: "100%",
        height: "100%",
    },
    //////////////////////////////// End Style App

    //////////////////////////////// Start Style Header
    header: {
        width: "100%",
        height: "8%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "space-between",
        backgroundColor: "#072",
    },

    button_menu: {
        width: "10%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    icon_menu: {
        color: "#eee",
        fontSize: 18,
    },

    box_center_header: {
        width: "80%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 25,
    },

    text_header: {
        color: "#eee",
        fontSize: 20,
    },

    button_back: {
        width: "10%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    icon_back: {
        color: "#eee",
        fontSize: 22,
    },
    //////////////////////////////// End Style Header

    //////////////////////////////// Start Style Content
    content: {
        width: "100%",
        height: "92%",
    },

    box_flat_list: {
        width: "100%",
        height: "100%",
    },
    //////////////////////////////// End Style Content

    /////////////////////////////// Start Section Menu
    menu: {
        position: "absolute",
        top: 0,
        width: "45%",
        height: "7%",
        backgroundColor: "#fff",
        borderRadius: 2,
    },

    menu_item: {
        width: "100%",
        height: 47,
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 20,
    },

    text_menu_item: {
        color: "#222",
        fontSize: 16,
    },
    /////////////////////////////// End Section Menu
});
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Style
export { styles };