﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity } from "react-native";
import { styles } from "./Css/CssSettingsArchive";
import { NativeBaseProvider, Box, Text, Switch } from "native-base";
import { AntDesign } from "@expo/vector-icons";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class SettingsArchive extends React.Component {
    state = {
        StateCheckedSwitchSaveConversation: true,
    };

    FuncGoToPageScreensArchive = () => {
        this.props.navigation.goBack();
    };

    FuncSetSwitch = () => {
        this.setState({
            StateCheckedSwitchSaveConversation: !this.state.StateCheckedSwitchSaveConversation,
        });
    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <Box name="App" style={styles.app}>
                    {/* Start Section Header */}
                    <Box name="Header" style={styles.header}>
                        <Box />

                        <Box name="Box_Center_Header" style={styles.box_center_header} >
                            <Text style={styles.text_header}>تنظیمات بایگانی</Text>
                        </Box>

                        <TouchableOpacity
                            onPress={() => {
                                this.FuncGoToPageScreensArchive();
                            }}
                            name="Box_Right_Header"
                            style={styles.button_back}>
                            <AntDesign name="arrowright" style={styles.icon_back} />
                        </TouchableOpacity>
                    </Box>
                    {/* End Section Header */}

                    {/* Start Section Content */}
                    <Box name="Content" style={styles.content}>
                        <TouchableOpacity onPress={() => {
                            this.FuncSetSwitch();
                        }}>
                            <Box name="Box_Button_Save_Conversation" style={styles.box_button_save_conversation}>
                                <Box name="Box_Switch" style={styles.box_switch}>
                                    <Switch
                                        isChecked={this.state.StateCheckedSwitchSaveConversation}
                                        onChange={() => {
                                            this.FuncSetSwitch();
                                        }} />
                                </Box>

                                <Box name="Box_Text" style={styles.box_text}>
                                    <Text style={styles.text_save_conversation}>نگه داشتن گفتگو در بایگانی</Text>
                                    <Text style={styles.text_explanation_save_conversation}>وقتی پیام جدید دریافت کنید, گفتگو های بایگانی شده همچنان در بایگانی باقی میماند.</Text>
                                </Box>
                            </Box>
                        </TouchableOpacity>
                    </Box>
                    {/* End Section Content */}
                </Box>
                {/* End Section App */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class