﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity, FlatList } from "react-native";
import { styles } from "./Css/CssAppArchivePage";
import { NativeBaseProvider, Box, Text } from "native-base";
import { AntDesign, Entypo } from "@expo/vector-icons";
import SingleContacts from "./../../../AppContactsPage/Components/SingleContacts";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class AppArchivePage extends React.Component {
    state = {
        data: [
            {
                id: "1",
                StateChat: "UserChat",
                ImageProfile: require("./../../../../../../../Assets/Images/ImageSingleProfile.png"),
                NameChat: "Hossein",
                TimeLastMessage: "16:36",
                LastMessages: "پیام ها و تماس ها سرتاسر رمزگذاری شده اند",
            },
            {
                id: "2",
                StateChat: "UserChat",
                ImageProfile: require("./../../../../../../../Assets/Images/ImageSingleProfile.png"),
                NameChat: "Yasin",
                TimeLastMessage: "2021/06/05",
                LastMessages: "کسی گروه ساختمان داده رو داره +98 914 056 7646",
            },
        ],
        PositionMenu: "100%",
    };

    FuncOpenMenu = () => {
        this.setState({
            PositionMenu: "55%",
        });
    };

    FuncCloseMenu = () => {
        this.setState({
            PositionMenu: "100%",
        });
    };

    FuncGoToPageScreensContacts = () => {
        this.props.navigation.goBack();
    };

    FuncGoToPageSettingsArchive = () => {
        this.props.navigation.navigate("SettingsArchive");
    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <TouchableOpacity
                    onPress={() => {
                        this.FuncCloseMenu();
                    }} activeOpacity={1}
                >
                    <Box name="App" style={styles.app}>
                        {/* Start Section Header */}
                        <Box name="Header" style={styles.header}>
                            <TouchableOpacity onPress={() => {
                                this.FuncOpenMenu();
                            }} style={styles.button_menu}>
                                <Entypo name="dots-three-vertical" style={styles.icon_menu} />
                            </TouchableOpacity>

                            <Box name="Box_Center_Header" style={styles.box_center_header} >
                                <Text style={styles.text_header}>بایگانی شده</Text>
                            </Box>

                            <TouchableOpacity
                                onPress={() => {
                                    this.FuncGoToPageScreensContacts();
                                }}
                                name="Box_Right_Header"
                                style={styles.button_back}>
                                <AntDesign name="arrowright" style={styles.icon_back} />
                            </TouchableOpacity>
                        </Box>
                        {/* End Section Header */}

                        {/* Start Section Content */}
                        <Box name="Content" style={styles.content}>
                            <Box name="Box_Flat_List" style={styles.box_flat_list}>
                                <FlatList data={this.state.data} renderItem={({ item }) => (
                                    <SingleContacts
                                        navigation={this.props.navigation}
                                        ImageProfile={item.ImageProfile}
                                        NameChat={item.NameChat}
                                        TimeLastMessage={item.TimeLastMessage}
                                        LastMessages={item.LastMessages}
                                        StateChat={item.StateChat} />
                                )} />
                            </Box>
                        </Box>
                        {/* End Section Content */}
                    </Box>
                </TouchableOpacity>
                {/* End Section App */}

                {/* Start Section Menu */}
                <Box name="Menu_Contacts" style={styles.menu} left={this.state.PositionMenu}>
                    <TouchableOpacity onPress={() => {
                        this.FuncCloseMenu();
                        this.FuncGoToPageSettingsArchive();
                    }}>
                        <Box name="Menu_Item" style={styles.menu_item}>
                            <Text style={styles.text_menu_item}>تنظیمات بایگانی</Text>
                        </Box>
                    </TouchableOpacity>
                </Box>
                {/* End Section Menu */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class