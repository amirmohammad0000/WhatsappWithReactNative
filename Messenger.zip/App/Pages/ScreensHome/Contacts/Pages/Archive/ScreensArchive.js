﻿//////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import AppArchivePage from "./Pages/AppArchivePage/AppArchivePage";
import SettingsArchive from "./Pages/SettingsArchive/SettingsArchive";
//////////////////////////////////////////////////////////////////////// End Section Import

const Stack = createNativeStackNavigator();

//////////////////////////////////////////////////////////////////////// Start Section Class
export default class ScreensArchive extends React.Component {
    render() {
        return (
            <Stack.Navigator>
                {/* Start Section Stack */}
                <Stack.Screen
                    name="AppArchivePage"
                    component={AppArchivePage}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="SettingsArchive"
                    component={SettingsArchive}
                    options={{
                        headerShown: false,
                    }}
                />
                {/* End Section Stack */}
            </Stack.Navigator>
        );
    }
}
//////////////////////////////////////////////////////////////////////// End Section Class