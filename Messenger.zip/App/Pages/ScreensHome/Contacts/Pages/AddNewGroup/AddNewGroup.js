﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity, FlatList } from "react-native";
import { styles } from "./Css/CssAddNewGroup";
import { NativeBaseProvider, Box, Image, Input, Text } from "native-base";
import { EvilIcons, AntDesign } from "@expo/vector-icons";
import SingleContacts from "./../AppContactsPage/Components/SingleContacts";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class AddNewGroup extends React.Component {
    state = {
        data: [
            {
                id: "1",
                StateChat: "UserChat",
                ImageProfile: require("./../../../../../Assets/Images/ImageSingleProfile.png"),
                NameChat: "Amir",
                TimeLastMessage: "12:45",
                LastMessages: "پیام ها و تماس ها سرتاسر رمزگذاری شده اند",
            },
            {
                id: "2",
                StateChat: "UserChat",
                ImageProfile: require("./../../../../../Assets/Images/ImageSingleProfile.png"),
                NameChat: "hossein",
                TimeLastMessage: "2021/9/5",
                LastMessages: "hello",
            },
            {
                id: "3",
                StateChat: "UserChat",
                ImageProfile: require("./../../../../../Assets/Images/ImageSingleProfile.png"),
                NameChat: "ali",
                TimeLastMessage: "2021/10/20",
                LastMessages: "سلام من خوبم تو خوبی",
            },
        ],
        SelectedParticipant: [
            {
                id: "1",
                ImageProfile: require("./../../../../../Assets/Images/ImageSingleProfile.png"),
                NameChat: "Amir",
            },
            {
                id: "2",
                ImageProfile: require("./../../../../../Assets/Images/ImageSingleProfile.png"),
                NameChat: "hossein",
            },
        ],
        PositionSearch: "100%",
        ValueInputSearch: "",
        TextParticipant: "افزودن شرکت کننده",
    };

    FuncOpenSearchBox = () => {
        this.setState({
            PositionSearch: "0",
        });
    };

    FuncCloseSearchBox = () => {
        this.setState({
            PositionSearch: "100%",
        });
    };

    FuncGoToPageAppContactsPage = () => {
        this.props.navigation.goBack();
    };

    FuncSetValueInputSearch = (text) => {
        this.setState({
            ValueInputSearch: text,
        });
    };

    FuncDeleteValueInputSearch = () => {
        this.setState({
            ValueInputSearch: "",
        });
    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <Box name="App" style={styles.app}>
                    {/* Start Section Header */}
                    <Box name="Header" style={styles.header}>
                        <TouchableOpacity style={styles.button_search} onPress={() => {
                            this.FuncOpenSearchBox();
                        }}>
                            <EvilIcons name="search" style={styles.icon_search} />
                        </TouchableOpacity>

                        <Box name="Box_Center_Header" style={styles.box_center_header} >
                            <Text style={styles.text_header}>گروه جدید</Text>
                            <Text style={styles.text_participant}>{this.state.TextParticipant}</Text>
                        </Box>

                        <TouchableOpacity
                            onPress={() => {
                                this.FuncGoToPageAppContactsPage();
                            }}
                            name="Box_Right_Header"
                            style={styles.button_back}>
                            <AntDesign name="arrowright" style={styles.icon_back} />
                        </TouchableOpacity>
                    </Box>
                    {/* End Section Header */}

                    {/* Start Section Content */}
                    <Box name="Content" style={styles.content}>
                        <Box name="Box_Selected_Participant" style={styles.box_selected_participant}>
                            {
                                this.state.SelectedParticipant !== "" ?
                                    <Box name="Box_Text_Selected_Participant" style={styles.box_text_selected_participant}>
                                        <FlatList horizontal={true} data={this.state.SelectedParticipant} renderItem={({ item }) => (
                                            <Box name="Box_Profile_Selected_Participant" style={styles.box_profile_selected_participant}>
                                                <Box name="Box_Image_Profile_Selected_Participant" style={styles.box_image_profile_selected_participant}>
                                                    <Image alt="Image Profile" source={item.ImageProfile} style={styles.image_profile_selected_participant} />
                                                </Box>

                                                <Text style={styles.text_selected_participant}>{item.NameChat}</Text>
                                            </Box>
                                        )} />
                                    </Box>
                                    :
                                    null
                            }
                        </Box>

                        <Box name="Box_Flat_List" style={styles.box_flat_list}>
                            <FlatList data={this.state.data} renderItem={({ item }) => (
                                <SingleContacts
                                    navigation={this.props.navigation}
                                    ImageProfile={item.ImageProfile}
                                    NameChat={item.NameChat}
                                    TimeLastMessage={item.TimeLastMessage}
                                    LastMessages={item.LastMessages}
                                    StateChat={item.StateChat} />
                            )} />
                        </Box>
                    </Box>
                    {/* End Section Content */}

                    {/* Start Section Footer */}
                    <Box name="Footer" style={styles.footer}>
                        <TouchableOpacity style={styles.button_footer} >
                            <AntDesign name="arrowleft" style={styles.icon_footer} />
                        </TouchableOpacity>
                    </Box>
                    {/* End Section Footer */}
                </Box>
                {/* End Section App */}

                {/* Start Section Header Search */}
                <Box name="Header_Section_Search" style={styles.header_section_search} left={this.state.PositionSearch}>
                    <Box name="Box_Menu_Section_Search" style={styles.box_menu_section_search}>
                        <TouchableOpacity
                            onPress={() => {
                                this.FuncDeleteValueInputSearch();
                            }}
                            style={styles.button_delete_section_search}>
                            <AntDesign name="close" style={styles.icon_delete_section_search} />
                        </TouchableOpacity>
                    </Box>

                    <Box name="Box_Center_Header_Section_Search" style={styles.box_center_header_section_search} >
                        <Input
                            placeholder="جستجو ..."
                            variant="ghost"
                            width="100%"
                            height="100%"
                            value={this.state.ValueInputSearch}
                            onChangeText={(text) => {
                                this.FuncSetValueInputSearch(text);
                            }} />
                    </Box>

                    <TouchableOpacity
                        onPress={() => {
                            this.FuncCloseSearchBox();
                        }}
                        name="Box_Right_Header"
                        style={styles.button_back_section_search}>
                        <AntDesign name="arrowright" style={styles.icon_back_section_search} />
                    </TouchableOpacity>
                </Box>
                {/* End Section Header Search */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class