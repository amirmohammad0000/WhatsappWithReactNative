/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import { StyleSheet } from "react-native";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Style
const styles = StyleSheet.create({
    //////////////////////////////// Start Style App
    app: {
        width: "100%",
        height: "100%",
    },
    //////////////////////////////// End Style App

    //////////////////////////////// Start Style Header
    header: {
        width: "100%",
        height: 60,
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "space-between",
        backgroundColor: "#072",
    },

    button_search: {
        width: "10%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    icon_search: {
        color: "#eee",
        fontSize: 25,
    },

    box_center_header: {
        width: "80%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 25,
    },

    text_header: {
        color: "#eee",
        fontSize: 20,
    },

    text_participant: {
        color: "#ccc",
        fontSize: 12,
    },

    button_back: {
        width: "10%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    icon_back: {
        color: "#eee",
        fontSize: 22,
    },
    //////////////////////////////// End Style Header

    //////////////////////////////// Start Style Content
    content: {
        width: "100%",
        height: "92%",
    },

    box_selected_participant: {
        width: "100%",
        height: 80,
        borderBottomColor: "#ddd",
        borderBottomWidth: 1,
    },

    box_text_selected_participant: {
        width: "100%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
    },

    box_profile_selected_participant: {
        height: "100%",
    },

    box_image_profile_selected_participant: {
        width: "100%",
        height: "60%",
        marginRight: 10,
        marginLeft: 10,
    },

    image_profile_selected_participant: {
        width: 60,
        height: 60,
        borderRadius: 1000,
    },

    text_selected_participant: {
        color: "#888",
        fontSize: 16,
        textAlign: "center",
    },

    text_selected_participant: {
        color: "#888",
        fontSize: 15,
        textAlign: "center",
        margin: 10,
    },

    box_flat_list: {
        width: "100%",
        height: "90%",
    },
    //////////////////////////////// End Style Content

    //////////////////////////////// Start Style Footer
    footer: {
        position: "absolute",
        bottom: 0,
        width: "100%",
        height: 80,
        alignItems: "flex-end",
        justifyContent: "flex-start",
    },

    button_footer: {
        width: "13%",
        height: "75%",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "#096",
        borderRadius: 1000,
        marginRight: 20,
    },

    icon_footer: {
        color: "#eee",
        fontSize: 25,
    },
    //////////////////////////////// End Style Footer

    //////////////////////////////// Start Style Header Search
    header_section_search: {
        width: "100%",
        height: 60,
        position: "absolute",
        top: 0,
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "flex-end",
        backgroundColor: "#fff",
    },

    box_menu_section_search: {
        width: "20%",
        height: "100%",
        flexDirection: "row-reverse",
    },

    button_delete_section_search: {
        width: "50%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
    },

    icon_delete_section_search: {
        color: "#888",
        fontSize: 20,
    },

    box_center_header_section_search: {
        width: "70%",
        height: "100%",
    },

    button_back_section_search: {
        width: "10%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    icon_back_section_search: {
        color: "#888",
        fontSize: 20,
    },
    //////////////////////////////// End Style Header Search
});
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Style
export { styles };