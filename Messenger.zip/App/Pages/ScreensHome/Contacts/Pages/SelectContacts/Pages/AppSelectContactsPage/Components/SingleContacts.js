﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity } from "react-native";
import { styles } from "./Css/CssSingleContacts";
import { NativeBaseProvider, Box, Image, Text } from "native-base";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class SingleContacts extends React.Component {
    FuncViewProfile = () => {

    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <Box name="App" style={styles.app}>
                    <Box name="Box_Item_Single_Contacts" style={styles.box_item_single_contacts}>
                        <Box name="Box_Image_UserNmae" style={styles.box_image_usernmae}>
                            <TouchableOpacity
                                name="Box_Image"
                                style={styles.box_image}
                                onPress={() => {
                                    this.FuncViewProfile();
                                }}>
                                <Image alt="Image" source={this.props.ImageProfile} style={styles.image_profile} />
                            </TouchableOpacity>

                            <Box name="Box_Text" style={styles.box_text}>
                                <Text style={styles.text_user_name}>{this.props.UserName}</Text>

                                <Text style={styles.text_bio_user}>{this.props.BioUser}</Text>
                            </Box>
                        </Box>
                    </Box>
                </Box>
                {/* End Section App */}
            </NativeBaseProvider >
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class