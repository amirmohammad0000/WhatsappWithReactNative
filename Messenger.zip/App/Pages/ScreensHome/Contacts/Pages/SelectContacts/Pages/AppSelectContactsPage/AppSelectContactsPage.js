﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity, FlatList } from "react-native";
import { styles } from "./Css/CssAppSelectContactsPage";
import { NativeBaseProvider, Box, Text, Input, Image } from "native-base";
import { Entypo, FontAwesome, EvilIcons, AntDesign } from '@expo/vector-icons';
import SingleContacts from "./Components/SingleContacts";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class AppSelectContactsPage extends React.Component {
    state = {
        data: [
            { id: "1", UserName: "Ali", BioUser: "Hello World", ImageProfile: require("./../../../../../../../Assets/Images/imagePerson1.png") },
            { id: "2", UserName: "Mohammad", BioUser: ".", ImageProfile: require("./../../../../../../../Assets/Images/imagePerson2.png") },
            { id: "3", UserName: "Amir", BioUser: "Single", ImageProfile: require("./../../../../../../../Assets/Images/imagePerson3.png") },
        ],
        PositionMenu: "100%",
        PositionSearchBox: "100%",
        TextNumberContacts: "15 مخاطب",
        ValueInputSearch: "",
    };

    FuncOpenMenu = () => {
        this.setState({
            PositionMenu: "55%",
        });
    };

    FuncCloseMenu = () => {
        this.setState({
            PositionMenu: "100%",
        });
    };

    FuncCloseSearchBox = () => {
        this.setState({
            PositionSearchBox: "100%",
        });
    };

    FuncOpenSearchBox = () => {
        this.setState({
            PositionSearchBox: "0",
        });
    };

    FuncGoToContactsMobile = () => {

    };

    FuncRefreshContacts = () => {

    };

    FuncGoToPageHelpForContacts = () => {
        this.props.navigation.navigate("HelpForContacts");
    };

    FuncGoToPageAppContactsPage = () => {
        this.props.navigation.goBack();
    };

    FuncCallsGroupContent = () => {
        this.props.navigation.navigate("AddNewGroup");
    };

    FuncBoxNewContacts = () => {

    };

    FuncInviteFriends = () => {
        this.props.navigation.navigate("SettingsInviteFriend");
    };

    FuncHelpForContacts = () => {
        this.props.navigation.navigate("HelpForContacts");
    };

    FuncSetValueInputSearch = (text) => {
        this.setState({
            ValueInputSearch: text,
        });
    };

    FuncRemoveValue = () => {
        this.setState({
            ValueInputSearch: "",
        });
    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <TouchableOpacity
                    onPress={() => {
                        this.FuncCloseMenu();
                    }}
                    activeOpacity={1}>
                    <Box name="App" style={styles.app}>
                        {/* Start Section Header */}
                        <Box name="Header" style={styles.header}>
                            <Box name="Box_Lef_Headert" style={styles.box_left_header}>
                                <TouchableOpacity
                                    onPress={() => {
                                        this.FuncOpenMenu();
                                    }}
                                    style={styles.button_menu}>
                                    <Entypo name="dots-three-vertical" style={styles.icon_menu} />
                                </TouchableOpacity>

                                <TouchableOpacity
                                    onPress={() => {
                                        this.FuncOpenSearchBox();
                                    }}
                                    style={styles.button_search}>
                                    <EvilIcons name="search" style={styles.icon_search} />
                                </TouchableOpacity>
                            </Box>

                            <Box name="Box_Right_Header" style={styles.box_right_header}>
                                <Box name="Box_Left_Inner_Header" style={styles.box_left_inner_header}>
                                    <Text style={styles.text_header_contacts}>انتخاب مخاطب</Text>

                                    <Text style={styles.text_header_number_contacts}>{this.state.TextNumberContacts}</Text>
                                </Box>

                                <Box name="Box_Right_Inner_Header" style={styles.box_right_inner_header}>
                                    <TouchableOpacity
                                        onPress={() => {
                                            this.FuncGoToPageAppContactsPage();
                                        }}
                                        style={styles.button_back}>
                                        <AntDesign name="arrowright" style={styles.icon_arrow} />
                                    </TouchableOpacity>
                                </Box>
                            </Box>
                        </Box>
                        {/* End Section Header */}

                        {/* Start Section Content */}
                        <Box name="Content" style={styles.content}>
                            <TouchableOpacity
                                onPress={() => {
                                    this.FuncCallsGroupContent();
                                }}
                                name="Box_Calls_Group_Content"
                                style={styles.box_calls_group_content}>
                                <Text style={styles.text_group_content}>گروه جدید</Text>

                                <Box name="Box_Image_Group_Content" style={styles.box_image_group_content}>
                                    <Image alt="Image" source={require("./../../../../../../../Assets/Images/ImageNewGroup.png")} style={styles.image_group_content} />
                                </Box>
                            </TouchableOpacity>

                            <TouchableOpacity
                                onPress={() => {
                                    this.FuncBoxNewContacts();
                                }}
                                name="Box_New_Contacts"
                                style={styles.box_new_contacts}>
                                <Text style={styles.text_new_contacts}>مخاطب جدید</Text>

                                <Box name="Box_Image_New_Contacts" style={styles.box_image_new_contacts}>
                                    <Image alt="Image" source={require("./../../../../../../../Assets/Images/ImageAddProfile.png")} style={styles.image_new_contacts} />
                                </Box>
                            </TouchableOpacity>

                            <Box name="Box_Flat_List" style={styles.box_flat_list}>
                                <FlatList data={this.state.data} renderItem={({ item }) => (
                                    <SingleContacts UserName={item.UserName} BioUser={item.BioUser} ImageProfile={item.ImageProfile} navigation={this.props.navigation} />
                                )}
                                />
                            </Box>
                        </Box>
                        {/* End Section Content */}

                        {/* Start Section Footer */}
                        <Box name="Footer" style={styles.footer}>
                            <TouchableOpacity
                                onPress={() => {
                                    this.FuncInviteFriends();
                                }}
                                name="Box_One_Footer"
                                style={styles.box_one_footer}>
                                <AntDesign name="sharealt" style={styles.icon_invite_friends} />

                                <Text style={styles.text_invite_friends}>دعوت کردن دوستان</Text>
                            </TouchableOpacity>

                            <TouchableOpacity
                                onPress={() => {
                                    this.FuncHelpForContacts();
                                }}
                                name="Box_Two_Footer"
                                style={styles.box_two_footer}>
                                <Entypo name="help-with-circle" style={styles.icon_help_fot_contacts} />

                                <Text style={styles.text_help_fot_contacts}>کمک برای مخاطب</Text>
                            </TouchableOpacity>
                        </Box>
                        {/* End Section Footer */}
                    </Box>
                </TouchableOpacity>
                {/* End Section App */}

                {/* Start Section Menu */}
                <Box name="Menu" style={styles.menu} left={this.state.PositionMenu}>
                    <TouchableOpacity onPress={() => {
                        this.FuncCloseMenu();
                        this.FuncInviteFriends();
                    }}>
                        <Box name="Menu_Item" style={styles.menu_item}>
                            <Text style={styles.text_menu_item}>دعوت یک دوست</Text>
                        </Box>
                    </TouchableOpacity>

                    <TouchableOpacity onPress={() => {
                        this.FuncCloseMenu();
                        this.FuncGoToContactsMobile();
                    }}>
                        <Box name="Menu_Item" style={styles.menu_item}>
                            <Text style={styles.text_menu_item}>مخاطبین</Text>
                        </Box>
                    </TouchableOpacity>

                    <TouchableOpacity onPress={() => {
                        this.FuncCloseMenu();
                        this.FuncRefreshContacts();
                    }}>
                        <Box name="Menu_Item" style={styles.menu_item}>
                            <Text style={styles.text_menu_item}>بازخوانی</Text>
                        </Box>
                    </TouchableOpacity>

                    <TouchableOpacity onPress={() => {
                        this.FuncCloseMenu();
                        this.FuncGoToPageHelpForContacts();
                    }}>
                        <Box name="Menu_Item" style={styles.menu_item}>
                            <Text style={styles.text_menu_item}>راهنمایی</Text>
                        </Box>
                    </TouchableOpacity>
                </Box>
                {/* End Section Menu */}

                {/* Start Section Header Search */}
                <Box name="Header_Search" style={styles.header_search} left={this.state.PositionSearchBox}>
                    <TouchableOpacity onPress={() => {
                        this.FuncCloseSearchBox();
                    }}>
                        <AntDesign name="arrowright" style={styles.icon_back} />
                    </TouchableOpacity>

                    <Input
                        placeholder="جستجو ..."
                        variant="ghost"
                        width="80%"
                        height="100%"
                        fontWeight="bold"
                        value={this.state.ValueInputSearch}
                        onChangeText={(text) => {
                            this.FuncSetValueInputSearch(text);
                        }}
                    />

                    <TouchableOpacity onPress={() => {
                        this.FuncRemoveValue();
                    }}>
                        <FontAwesome name="remove" style={styles.icon_delete} />
                    </TouchableOpacity>
                </Box>
                {/* End Section Header Search */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class