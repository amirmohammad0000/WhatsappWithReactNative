//////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import AppSelectContactsPage from "./Pages/AppSelectContactsPage/AppSelectContactsPage";
import HelpForContacts from "./Pages/HelpForContacts/HelpForContacts";
import SettingsInviteFriend from "./../Settings/Pages/SettingsInviteFriend/SettingsInviteFriend";
//////////////////////////////////////////////////////////////////////// End Section Import

const Stack = createNativeStackNavigator();

//////////////////////////////////////////////////////////////////////// Start Section Class
export default class SelectContacts extends React.Component {
    render() {
        return (
            <Stack.Navigator>
                {/* Start Section Stack */}
                <Stack.Screen
                    name="AppSelectContactsPage"
                    component={AppSelectContactsPage}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="HelpForContacts"
                    component={HelpForContacts}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="SettingsInviteFriend"
                    component={SettingsInviteFriend}
                    options={{
                        headerShown: false,
                    }}
                />
                {/* End Section Stack */}
            </Stack.Navigator>
        );
    }
}
//////////////////////////////////////////////////////////////////////// End Section Class