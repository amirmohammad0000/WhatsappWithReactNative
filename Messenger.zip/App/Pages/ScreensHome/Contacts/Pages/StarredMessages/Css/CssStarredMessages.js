/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import { StyleSheet } from "react-native";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Style
const styles = StyleSheet.create({
    //////////////////////////////// Start Style App
    app: {
        width: "100%",
        height: "100%",
    },
    //////////////////////////////// End Style App

    //////////////////////////////// Start Style Header
    header: {
        width: "100%",
        height: 60,
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "flex-end",
        backgroundColor: "#072",
    },

    box_menu: {
        width: "18%",
        height: "100%",
        flexDirection: "row-reverse",
        alignItems: "center",
    },

    button_menu: {
        width: "50%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    icon_menu: {
        color: "#eee",
        fontSize: 20,
    },

    button_search: {
        width: "50%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    icon_search: {
        color: "#eee",
        fontSize: 25,
    },

    box_center_header: {
        width: "72%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
    },

    text_header: {
        color: "#eee",
        fontSize: 20,
        paddingRight: 25,
    },

    button_back: {
        width: "10%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    icon_back: {
        color: "#eee",
        fontSize: 22,
    },
    //////////////////////////////// End Style Header

    //////////////////////////////// End Style Content
    content: {
        width: "100%",
        height: "92%",
    },

    box_star: {
        width: "100%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    image_star_center_page: {
        width: 170,
        height: 170,
        borderRadius: 1000,
    },

    text_star_center_page: {
        color: "#222",
        fontSize: 18,
        padding: 40,
        textAlign: "center",
    },
    //////////////////////////////// End Style Content

    //////////////////////////////// Start Style Header Search
    header_section_search: {
        width: "100%",
        height: 60,
        position: "absolute",
        top: 0,
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "flex-end",
        backgroundColor: "#072",
    },

    box_menu_section_search: {
        width: "20%",
        height: "100%",
        flexDirection: "row-reverse",
    },

    button_menu_section_search: {
        width: "50%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    icon_menu_section_search: {
        color: "#eee",
        fontSize: 20,
    },

    button_delete_section_search: {
        width: "50%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
    },

    icon_delete_section_search: {
        color: "#eee",
        fontSize: 20,
    },

    box_center_header_section_search: {
        width: "70%",
        height: "100%",
    },

    button_back_section_search: {
        width: "10%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    icon_back_section_search: {
        color: "#eee",
        fontSize: 20,
    },
    //////////////////////////////// End Style Header Search

    /////////////////////////////// Start Section Menu
    menu: {
        position: "absolute",
        top: 0,
        width: "45%",
        height: 55,
        backgroundColor: "#fff",
        borderRadius: 2,
    },

    menu_item: {
        width: "100%",
        height: 47,
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 20,
    },

    text_menu_item: {
        color: "#222",
        fontSize: 16,
    },
    /////////////////////////////// End Section Menu
});
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Style
export { styles };