﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity } from "react-native";
import { styles } from "./Css/CssStarredMessages";
import { NativeBaseProvider, Box, Input, Image, Text } from "native-base";
import { AntDesign, EvilIcons, Entypo } from "@expo/vector-icons";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class StarredMessages extends React.Component {
    state = {
        ValueInputSearch: "",
        StateStarredMessages: false,
        PositionMenu: "100%",
        PositionSearch: "100%",
    };

    FuncSetValueInputSearch = (text) => {
        this.setState({
            ValueInputSearch: text,
        });
    };

    FuncDeleteValueInputSearch = () => {
        this.setState({
            ValueInputSearch: "",
        });
    };

    FuncOpenMenu = () => {
        this.setState({
            PositionMenu: "55%",
        });
    };

    FuncCloseMenu = () => {
        this.setState({
            PositionMenu: "100%",
        });
    };

    FuncOpenSearchBox = () => {
        this.setState({
            PositionSearch: "0",
        });
    };

    FuncCloseSearchBox = () => {
        this.setState({
            PositionSearch: "100%",
        });
    };

    FuncSetDeleteStarredMessages = () => {

    };

    FuncGoToPageAppContactsPage = () => {
        this.props.navigation.goBack();
    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <TouchableOpacity
                    name="App"
                    style={styles.app}
                    activeOpacity={1}
                    onPress={() => {
                        this.FuncCloseMenu();
                    }}>
                    {/* Start Section Header */}
                    <Box name="Header" style={styles.header}>
                        <Box name="Box_Menu" style={styles.box_menu}>
                            <TouchableOpacity style={styles.button_menu} onPress={() => {
                                this.FuncOpenMenu();
                            }}>
                                <Entypo name="dots-three-vertical" style={styles.icon_menu} />
                            </TouchableOpacity>

                            <TouchableOpacity style={styles.button_search} onPress={() => {
                                this.FuncOpenSearchBox();
                            }}>
                                <EvilIcons name="search" style={styles.icon_search} />
                            </TouchableOpacity>
                        </Box>

                        <Box name="Box_Center_Header" style={styles.box_center_header} >
                            <Text style={styles.text_header}>پیام های ستاره دار</Text>
                        </Box>

                        <TouchableOpacity
                            onPress={() => {
                                this.FuncGoToPageAppContactsPage();
                            }}
                            name="Box_Right_Header"
                            style={styles.button_back}>
                            <AntDesign name="arrowright" style={styles.icon_back} />
                        </TouchableOpacity>
                    </Box>
                    {/* End Section Header */}

                    {/* Start Section Content */}
                    <Box name="Content" style={styles.content}>
                        {
                            this.state.StateStarredMessages === false ?
                                <Box name="Box_Star" style={styles.box_star}>
                                    <Image alt="Image Star" source={require("./../../../../../Assets/Images/Star.png")} style={styles.image_star_center_page} />

                                    <Text style={styles.text_star_center_page}>با زدن و نگه داشتن بر روی هر پیامی در داخل چت, این پیام را ستاره دار کنید.به این شکل شما میتوانید پیام های ستاره دار را راحت پیدا کنید</Text>
                                </Box>
                                :
                                <Box>

                                </Box>
                        }
                    </Box>
                    {/* End Section Content */}
                </TouchableOpacity>
                {/* End Section App */}

                {/* Start Section Header Search */}
                <Box name="Header_Section_Search" style={styles.header_section_search} left={this.state.PositionSearch}>
                    <Box name="Box_Menu_Section_Search" style={styles.box_menu_section_search}>
                        <TouchableOpacity
                            onPress={() => {
                                this.FuncOpenMenu();
                            }}
                            style={styles.button_menu_section_search}>
                            <Entypo name="dots-three-vertical" style={styles.icon_menu_section_search} />
                        </TouchableOpacity>

                        <TouchableOpacity
                            onPress={() => {
                                this.FuncDeleteValueInputSearch();
                            }}
                            style={styles.button_delete_section_search}>
                            <AntDesign name="close" style={styles.icon_delete_section_search} />
                        </TouchableOpacity>
                    </Box>

                    <Box name="Box_Center_Header_Section_Search" style={styles.box_center_header_section_search} >
                        <Input
                            placeholder="جستجو ..."
                            variant="ghost"
                            width="100%"
                            height="100%"
                            color="#eee"
                            value={this.state.ValueInputSearch}
                            onChangeText={(text) => {
                                this.FuncSetValueInputSearch(text);
                            }} />
                    </Box>

                    <TouchableOpacity
                        onPress={() => {
                            this.FuncCloseSearchBox();
                        }}
                        name="Box_Right_Header"
                        style={styles.button_back_section_search}>
                        <AntDesign name="arrowright" style={styles.icon_back_section_search} />
                    </TouchableOpacity>
                </Box>
                {/* End Section Header Search */}

                {/* Start Section Menu */}
                <Box name="Menu" style={styles.menu} left={this.state.PositionMenu}>
                    <TouchableOpacity onPress={() => {
                        this.FuncCloseMenu();
                        this.FuncSetDeleteStarredMessages();
                    }}>
                        <Box name="Menu_Item" style={styles.menu_item}>
                            <Text style={styles.text_menu_item}>برداشتن ستاره همه پیام ها</Text>
                        </Box>
                    </TouchableOpacity>
                </Box>
                {/* End Section Menu */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class