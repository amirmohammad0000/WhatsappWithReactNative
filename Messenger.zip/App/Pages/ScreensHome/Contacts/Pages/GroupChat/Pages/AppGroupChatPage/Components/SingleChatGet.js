﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity } from "react-native";
import { styles } from "./Css/CssSingleChatGet";
import { NativeBaseProvider, Box, Text } from "native-base";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class SingleChatGet extends React.Component {
    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <Box name="Box" style={styles.box}>

                </Box>
                {/* End Section App */}
            </NativeBaseProvider >
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class