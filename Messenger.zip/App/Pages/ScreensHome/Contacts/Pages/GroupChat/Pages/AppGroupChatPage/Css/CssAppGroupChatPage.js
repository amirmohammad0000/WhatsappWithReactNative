/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import { StyleSheet } from "react-native";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Style
const styles = StyleSheet.create({
    //////////////////////////////// Start Style App
    app: {
        width: "100%",
        height: "100%",
    },
    //////////////////////////////// End Style App

    //////////////////////////////// Start Style Header
    header: {
        width: "100%",
        height: 60,
        backgroundColor: "#082",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "space-between",
    },

    box_left_header: {
        width: "50%",
        height: "100%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "flex-start",
    },

    button_menu: {
        width: "20%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    icon_menu: {
        color: "#eee",
        fontSize: 18,
    },

    button_call: {
        width: "20%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    icon_call: {
        color: "#eee",
        fontSize: 18,
    },

    button_video: {
        width: "20%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    icon_video: {
        color: "#eee",
        fontSize: 18,
    },

    box_right_header: {
        width: "50%",
        height: "100%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "flex-end",
    },

    box_text_right: {
        width: "100%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
    },

    text_user_name: {
        color: "#eee",
        fontSize: 16,
    },

    text_user_time: {
        color: "#eee",
        fontSize: 14,
    },

    box_profile: {
        width: "30%",
        height: "100%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "center",
    },

    box_image: {
        width: "65%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
    },

    image_profile: {
        width: 40,
        height: 40,
        borderRadius: 1000,
    },

    button_back: {
        width: "35%",
        height: "100%",
        alignItems: "flex-end",
        justifyContent: "center",
    },

    icon_back: {
        color: "#eee",
        fontSize: 20,
    },
    //////////////////////////////// End Style Header

    //////////////////////////////// Start Style Content
    content: {
        width: "100%",
        height: "93%",
    },
    //////////////////////////////// End Style Content

    //////////////////////////////// Start Style Footer
    footer: {
        width: "100%",
        height: 60,
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "space-evenly",
        position: "absolute",
        bottom: 0,
    },

    button_send_message: {
        width: "11%",
        height: "80%",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "#092",
        borderRadius: 1000,
    },

    icon_send_message: {
        color: "#eee",
        fontSize: 20,
    },

    box_icon_input: {
        width: "86%",
        height: "80%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 1000,
        backgroundColor: "#fff",
    },

    box_icon: {
        width: "20%",
        height: "100%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "space-around",
    },

    button_camera: {
        width: "50%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 1000,
    },

    icon_cemera: {
        color: "#888",
        fontSize: 20,
    },

    button_more_options: {
        width: "50%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 1000,
    },

    icon_more_options: {
        color: "#888",
        fontSize: 20,
    },

    box_input: {
        width: "70%",
        height: "100%",
    },

    button_emoji: {
        width: "10%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 1000,
    },

    icon_emoji: {
        color: "#999",
        fontSize: 22,
    },
    //////////////////////////////// End Style Footer

    /////////////////////////////// Start Section Menu Calls
    menu_main: {
        position: "absolute",
        top: 0,
        width: "45%",
        height: "32%",
        backgroundColor: "#fff",
        borderRadius: 2,
    },

    menu_item_main: {
        width: "100%",
        height: 47,
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 20,
    },

    text_menu_item_main: {
        color: "#222",
        fontSize: 16,
    },

    under_menu: {
        position: "absolute",
        top: 0,
        width: "45%",
        height: "19%",
        backgroundColor: "#fff",
        borderRadius: 2,
    },

    under_menu_item: {
        width: "100%",
        height: 47,
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 20,
    },

    text_under_menu_item: {
        color: "#222",
        fontSize: 16,
    },
    /////////////////////////////// End Section Menu Calls
});
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Style
export { styles };