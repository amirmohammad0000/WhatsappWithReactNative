﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity, FlatList } from "react-native";
import { styles } from "./Css/CssAppGroupChatPage";
import { NativeBaseProvider, Box, Image, Input, Text } from "native-base";
import { Entypo, Ionicons, AntDesign, FontAwesome, FontAwesome5 } from "@expo/vector-icons";
import SingleChatGet from "./Components/SingleChatGet";
import SingleChatSend from "./Components/SingleChatSend";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class AppGroupChatPage extends React.Component {
    state = {
        DataMessageMe: [
            {
                id: "1",
                PhoneNumber: "+98 0913 765 4554",
                NameUser: "Amir Mohammad",
                TimeSendMessage: "19:53",
                Message: "سلام",
            },
            {
                id: "2",
                PhoneNumber: "+98 0913 534 4554",
                NameUser: "Amir ali",
                TimeSendMessage: "4:45",
                Message: "سلام به شما",
            },
        ],
        DataMessageFrinde: [
            {
                id: "1",
                PhoneNumber: "+98 0913 344 4554",
                NameUser: "Amir Hossein",
                TimeSendMessage: "15:50",
                Message: "خداحافظ",
            },
            {
                id: "2",
                PhoneNumber: "+98 0913 678 4554",
                NameUser: "Ali",
                TimeSendMessage: "16:23",
                Message: "سلام بچه ها",
            },
        ],
        UserName: "کامپیوتر",
        UserInformation: "AmirMohammad,AmirHossein",
        PositionMenu: "100%",
        PositionUnderMenu: "100%",
        NameIconSendMessage: "microphone",
        ValueInputMessage: "",
    };

    FuncOpenMenu = () => {
        this.setState({
            PositionMenu: "55%",
        });
    };

    FuncOpenUnderMenu = () => {
        this.setState({
            PositionUnderMenu: "55%",
        });
    };

    FuncCloseMenu = () => {
        this.setState({
            PositionMenu: "100%",
        });
    };

    FuncCloseUnderMenu = () => {
        this.setState({
            PositionUnderMenu: "100%",
        });
    };

    FuncViewInformationContacts = () => {
        this.props.navigation.navigate("GroupInformation");
    };

    FuncMediaLinkDocument = () => {

    };

    FuncMuteNotification = () => {

    };

    FuncWallpaper = () => {
        this.props.navigation.navigate("SettingsWallpaper");
    };

    FuncReport = () => {

    };

    Funcblock = () => {

    };

    FuncAddShortcut = () => {

    };

    FuncCall = () => {

    };

    FuncVideo = () => {

    };

    FuncGoToPageContacts = () => {
        this.props.navigation.goBack();
    };

    FuncSetValueInputMessage = (text) => {
        this.setState({
            ValueInputMessage: text,
        });

        if (this.state.ValueInputMessage !== "") {
            this.setState({
                NameIconSendMessage: "send",
            });
        } else {
            this.setState({
                NameIconSendMessage: "microphone",
            });
        }
    };

    FuncSendSound = () => {

    };

    FuncCamera = () => {

    };

    FuncMoreOptions = () => {

    };

    FuncEmoji = () => {

    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <TouchableOpacity
                    name="App"
                    style={styles.app}
                    activeOpacity={1}
                    onPress={() => {
                        this.FuncCloseMenu();
                        this.FuncCloseUnderMenu();
                    }}>
                    {/* Start Section Header */}
                    <Box name="Header" style={styles.header}>
                        <Box name="Box_Left" style={styles.box_left_header}>
                            <TouchableOpacity
                                name="Button_Menu"
                                style={styles.button_menu}
                                onPress={() => {
                                    this.FuncOpenMenu();
                                }}>
                                <Entypo name="dots-three-vertical" style={styles.icon_menu} />
                            </TouchableOpacity>

                            <TouchableOpacity
                                name="Button_Call"
                                style={styles.button_call}
                                onPress={() => {
                                    this.FuncCall();
                                }}>
                                <Ionicons name="call" style={styles.icon_call} />
                            </TouchableOpacity>

                            <TouchableOpacity
                                name="Button_Video"
                                style={styles.button_video}
                                onPress={() => {
                                    this.FuncVideo();
                                }}>
                                <FontAwesome5 name="video" style={styles.icon_video} />
                            </TouchableOpacity>
                        </Box>

                        <Box name="Box_Right" style={styles.box_right_header}>
                            <TouchableOpacity
                                name="Box_Text_Right"
                                style={styles.box_text_right}
                                onPress={() => {
                                    this.FuncViewInformationContacts();
                                }}>
                                <Text style={styles.text_user_name}>{this.state.UserName}</Text>
                                <Text style={styles.text_user_time}>{this.state.UserInformation}</Text>
                            </TouchableOpacity>

                            <Box name="Box_Profile" style={styles.box_profile}>
                                <Box name="Box_Image" style={styles.box_image}>
                                    <Image
                                        alt="Image profile"
                                        source={require("./../../../../../../../Assets/Images/ImageSingleProfile.png")}
                                        style={styles.image_profile} />
                                </Box>

                                <TouchableOpacity
                                    name="Button_Back"
                                    style={styles.button_back}
                                    onPress={() => {
                                        this.FuncGoToPageContacts();
                                    }}>
                                    <AntDesign name="arrowright" style={styles.icon_back} />
                                </TouchableOpacity>
                            </Box>
                        </Box>
                    </Box>
                    {/* End Section Header */}

                    {/* Start Section Content */}
                    <Box name="Content" style={styles.content}>
                        <FlatList data={this.state.DataMessageMe} renderItem={({ item }) => (
                            <SingleChatSend PhoneNumber={item.PhoneNumber} NameUser={item.NameUser} TimeSendMessage={item.TimeSendMessage} Message={item.Message} />
                        )} />

                        <FlatList data={this.state.DataMessageFrinde} renderItem={({ item }) => (
                            <SingleChatGet PhoneNumber={item.PhoneNumber} NameUser={item.NameUser} TimeSendMessage={item.TimeSendMessage} Message={item.Message} />
                        )} />
                    </Box>
                    {/* End Section Content */}

                    {/* Start Section Content */}
                    <Box name="Footer" style={styles.footer}>
                        <TouchableOpacity
                            name="Button_Send_Message"
                            style={styles.button_send_message}
                            onPress={() => {
                                this.FuncSendSound();
                            }}>
                            <FontAwesome name={this.state.NameIconSendMessage} style={styles.icon_send_message} />
                        </TouchableOpacity>

                        <Box name="Box_Icon_Input" style={styles.box_icon_input}>
                            <Box name="Box_Icon" style={styles.box_icon}>
                                <TouchableOpacity
                                    name="Button_Camera"
                                    style={styles.button_camera}
                                    onPress={() => {
                                        this.FuncCamera();
                                    }}>
                                    <Entypo name="camera" style={styles.icon_cemera} />
                                </TouchableOpacity>

                                <TouchableOpacity
                                    name="Button_More_Options"
                                    style={styles.button_more_options}
                                    onPress={() => {
                                        this.FuncMoreOptions();
                                    }}>
                                    <FontAwesome name="paperclip" style={styles.icon_more_options} />
                                </TouchableOpacity>
                            </Box>

                            <Box name="Box_Input" style={styles.box_input}>
                                <Input
                                    placeholder="پیام"
                                    variant="ghost"
                                    width="100%"
                                    height="100%"
                                    value={this.state.ValueInputMessage}
                                    onChangeText={(text) => {
                                        this.FuncSetValueInputMessage(text);
                                    }}
                                />
                            </Box>

                            <TouchableOpacity
                                name="Button_Emoji"
                                style={styles.button_emoji}
                                onPress={() => {
                                    this.FuncEmoji();
                                }}>
                                <Entypo name="emoji-happy" style={styles.icon_emoji} />
                            </TouchableOpacity>
                        </Box>
                    </Box>
                    {/* End Section Content */}
                </TouchableOpacity>
                {/* End Section App */}

                {/* Start Section Menu Main */}
                <Box name="Mene_Main" style={styles.menu_main} left={this.state.PositionMenu}>
                    <TouchableOpacity onPress={() => {
                        this.FuncCloseMenu();
                        this.FuncViewInformationContacts();
                    }}>
                        <Box name="Menu_Item" style={styles.menu_item_main}>
                            <Text style={styles.text_menu_main}>نمایش اطلاعات مخاطب</Text>
                        </Box>
                    </TouchableOpacity>

                    <TouchableOpacity onPress={() => {
                        this.FuncCloseMenu();
                        this.FuncMediaLinkDocument();
                    }}>
                        <Box name="Menu_Item" style={styles.menu_item_main}>
                            <Text style={styles.text_menu_main}>رسانه ها, پیوند ها و اسناد</Text>
                        </Box>
                    </TouchableOpacity>

                    <TouchableOpacity onPress={() => {
                        this.FuncCloseMenu();
                        this.FuncMuteNotification();
                    }}>
                        <Box name="Menu_Item" style={styles.menu_item_main}>
                            <Text style={styles.text_menu_main}>بی صدا کردن اعلان ها</Text>
                        </Box>
                    </TouchableOpacity>

                    <TouchableOpacity onPress={() => {
                        this.FuncCloseMenu();
                        this.FuncWallpaper();
                    }}>
                        <Box name="Menu_Item" style={styles.menu_item_main}>
                            <Text style={styles.text_menu_main}>کاغذ دیواری</Text>
                        </Box>
                    </TouchableOpacity>

                    <TouchableOpacity onPress={() => {
                        this.FuncCloseMenu();
                        this.FuncOpenUnderMenu();
                    }}>
                        <Box name="Menu_Item" style={styles.menu_item_main}>
                            <Text style={styles.text_menu_main}>بیشتر</Text>
                        </Box>
                    </TouchableOpacity>
                </Box>
                {/* End Section Menu Main */}

                {/* Start Section Under Menu */}
                <Box name="Under_Mene" style={styles.under_menu} left={this.state.PositionUnderMenu}>
                    <TouchableOpacity onPress={() => {
                        this.FuncCloseUnderMenu();
                        this.FuncReport();
                    }}>
                        <Box name="Menu_Item" style={styles.under_menu_item}>
                            <Text style={styles.text_under_menu_item}>گزارش دادن</Text>
                        </Box>
                    </TouchableOpacity>

                    <TouchableOpacity onPress={() => {
                        this.FuncCloseUnderMenu();
                        this.Funcblock();
                    }}>
                        <Box name="Menu_Item" style={styles.under_menu_item}>
                            <Text style={styles.text_under_menu_item}>مسدود کردن</Text>
                        </Box>
                    </TouchableOpacity>

                    <TouchableOpacity onPress={() => {
                        this.FuncCloseUnderMenu();
                        this.FuncAddShortcut();
                    }}>
                        <Box name="Menu_Item" style={styles.under_menu_item}>
                            <Text style={styles.text_under_menu_item}>اضافه کردن میان بر</Text>
                        </Box>
                    </TouchableOpacity>
                </Box>
                {/* End Section Under Menu */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class