//////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import AppGroupChatPage from "./Pages/AppGroupChatPage/AppGroupChatPage";
import GroupInformation from "./Pages/GroupInformation/GroupInformation";
import SettingsWallpaper from "./../Settings/Pages/SettingsConversation/Pages/SettingsWallpaper/SettingsWallpaper";
//////////////////////////////////////////////////////////////////////// End Section Import

const Stack = createNativeStackNavigator();

//////////////////////////////////////////////////////////////////////// Start Section Class
export default class GroupChat extends React.Component {
    render() {
        return (
            <Stack.Navigator>
                {/* Start Section Stack */}
                <Stack.Screen
                    name="AppGroupChatPage"
                    component={AppGroupChatPage}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="GroupInformation"
                    component={GroupInformation}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="SettingsWallpaper"
                    component={SettingsWallpaper}
                    options={{
                        headerShown: false,
                    }}
                />
                {/* End Section Stack */}
            </Stack.Navigator>
        );
    }
}
//////////////////////////////////////////////////////////////////////// End Section Class