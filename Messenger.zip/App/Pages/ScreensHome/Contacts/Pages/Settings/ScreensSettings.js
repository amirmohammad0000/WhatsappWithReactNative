//////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import AppSettingsPage from "./Pages/AppSettingsPage/AppSettingsPage";
import ScreensSettingsProfile from "./Pages/SettingsProfile/ScreensSettingsProfile";
import ScreensSettingsAccount from "./Pages/SettingsAccount/ScreensSettingsAccount";
import ScreensSettingsConversation from "./Pages/SettingsConversation/ScreensSettingsConversation";
import SettingsAnnouncement from "./Pages/SettingsAnnouncement/SettingsAnnouncement";
import ScreensSettingsStorageDataSpace from "./Pages/SettingsStorageDataSpace/ScreensSettingsStorageDataSpace";
import ScreensSettingsHelp from "./Pages/SettingsHelp/ScreensSettingsHelp";
import SettingsInviteFriend from "./Pages/SettingsInviteFriend/SettingsInviteFriend";
//////////////////////////////////////////////////////////////////////// End Section Import

const Stack = createNativeStackNavigator();

//////////////////////////////////////////////////////////////////////// Start Section Class
export default class ScreensSettings extends React.Component {
    render() {
        return (
            <Stack.Navigator>
                {/* Start Section Stack */}
                <Stack.Screen
                    name="AppSettingsPage"
                    component={AppSettingsPage}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="ScreensSettingsProfile"
                    component={ScreensSettingsProfile}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="ScreensSettingsAccount"
                    component={ScreensSettingsAccount}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="ScreensSettingsConversation"
                    component={ScreensSettingsConversation}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="SettingsAnnouncement"
                    component={SettingsAnnouncement}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="ScreensSettingsStorageDataSpace"
                    component={ScreensSettingsStorageDataSpace}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="ScreensSettingsHelp"
                    component={ScreensSettingsHelp}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="SettingsInviteFriend"
                    component={SettingsInviteFriend}
                    options={{
                        headerShown: false,
                    }}
                />
                {/* End Section Stack */}
            </Stack.Navigator>
        );
    }
}
//////////////////////////////////////////////////////////////////////// End Section Class