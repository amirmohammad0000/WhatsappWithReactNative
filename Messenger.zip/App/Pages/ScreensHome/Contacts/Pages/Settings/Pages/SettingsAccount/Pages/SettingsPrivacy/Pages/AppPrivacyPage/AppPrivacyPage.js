﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity } from "react-native";
import { styles } from "./Css/CssAppPrivacyPage";
import { NativeBaseProvider, Box, Switch, Text } from "native-base";
import { AntDesign } from "@expo/vector-icons";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class AppPrivacyPage extends React.Component {
    state = {
        CheckReceiptToRead: "",
    };

    FuncGoToPageSettingsPrivacy = () => {
        this.props.navigation.goBack();
    };

    FuncLastView = () => {

    };

    FuncImageProfile = () => {

    };

    FuncAbout = () => {

    };

    FuncStatus = () => {
        this.props.navigation.navigate("SettingsStatusSettings");
    };

    FuncSetReceiptToRead = () => {
        this.setState({
            CheckReceiptToRead: !this.state.CheckReceiptToRead,
        });
    };

    FuncGroup = () => {
        this.props.navigation.navigate("SettingsGroupsSettings");
    };

    FuncLivaPlace = () => {
        this.props.navigation.navigate("SettingsLivePlace");
    };

    FuncAudienceBlocked = () => {
        this.props.navigation.navigate("SettingsAudienceBlocked");
    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <Box name="App" style={styles.app}>
                    {/* Start Section Header */}
                    <Box name="Header" style={styles.header}>
                        <Box />

                        <Box name="Box_Center_Header" style={styles.box_center_header} >
                            <Text style={styles.text_header}>حریم خصوصی</Text>
                        </Box>

                        <TouchableOpacity
                            onPress={() => {
                                this.FuncGoToPageSettingsPrivacy();
                            }}
                            name="Box_Right_Header"
                            style={styles.button_back}>
                            <AntDesign name="arrowright" style={styles.icon_back} />
                        </TouchableOpacity>
                    </Box>
                    {/* End Section Header */}

                    {/* Start Section Content */}
                    <Box name="Content" style={styles.content}>
                        <Box name="Box_Header_Content" style={styles.box_header_content}>
                            <Text style={styles.text_one_header_content}>چه کسانی میتوانند اطلاعات شخصی من را مشاهده کنند.</Text>

                            <Text style={styles.text_two_header_content}>اگر اخرین بازدید خود را به اشتراک نگذارید. قادر به دیدن اخرین بازدید افراد دیگر نیز نخواهید بود</Text>
                        </Box>

                        <TouchableOpacity
                            name="Button_Last_View"
                            style={styles.button_last_view}
                            onPress={() => {
                                this.FuncLastView();
                            }}>
                            <Text style={styles.text_one_button_last_view}>اخرین بازدید</Text>

                            <Text style={styles.text_two_button_last_view}>همه</Text>
                        </TouchableOpacity>

                        <TouchableOpacity
                            name="Button_Image_Profile"
                            style={styles.button_image_profile}
                            onPress={() => {
                                this.FuncImageProfile();
                            }}>
                            <Text style={styles.text_one_button_image_profile}>تصویر نمایه</Text>

                            <Text style={styles.text_two_button_image_profile}>همه</Text>
                        </TouchableOpacity>

                        <TouchableOpacity
                            name="Button_about"
                            style={styles.button_about}
                            onPress={() => {
                                this.FuncAbout();
                            }}>
                            <Text style={styles.text_one_button_about}>درباره</Text>

                            <Text style={styles.text_two_button_about}>همه</Text>
                        </TouchableOpacity>

                        <TouchableOpacity
                            name="Button_Status"
                            style={styles.button_status}
                            onPress={() => {
                                this.FuncStatus();
                            }}>
                            <Text style={styles.text_one_button_status}>وضعیت</Text>

                            <Text style={styles.text_two_button_status}>مخاطبین من</Text>
                        </TouchableOpacity>

                        <TouchableOpacity
                            name="Button_Receipt_To_Read"
                            style={styles.button_receipt_to_read}
                            onPress={() => {
                                this.FuncSetReceiptToRead();
                            }}>
                            <Switch
                                isChecked={this.state.CheckReceiptToRead}
                                onChange={() => {
                                    this.FuncSetReceiptToRead();
                                }}
                            />

                            <Box>
                                <Text style={styles.text_one_button_receipt_to_read}>رسید خواندن</Text>

                                <Text style={styles.text_two_button_receipt_to_read}>اگر خاموش باشد, رسید های خواندن را ارسال یا دریافت نخواهید کرد.رسید ها برای گفتگو های گروهی همیشه فرستاده میشوند.</Text>
                            </Box>
                        </TouchableOpacity>

                        <TouchableOpacity
                            name="Button_Group"
                            style={styles.button_group}
                            onPress={() => {
                                this.FuncGroup();
                            }}>
                            <Text style={styles.text_one_button_group}>گروه ها</Text>

                            <Text style={styles.text_two_button_group}>همه</Text>
                        </TouchableOpacity>

                        <TouchableOpacity
                            name="Button_Liva_Place"
                            style={styles.button_live_place}
                            onPress={() => {
                                this.FuncLivaPlace();
                            }}>
                            <Text style={styles.text_one_button_live_place}>مکان زنده</Text>

                            <Text style={styles.text_two_button_live_place}>هیچکدام</Text>
                        </TouchableOpacity>

                        <TouchableOpacity
                            name="Button_Audience_Blocked"
                            style={styles.button_audience_blocked}
                            onPress={() => {
                                this.FuncAudienceBlocked();
                            }}>
                            <Text style={styles.text_one_button_audience_blocked}>مخاطبان مسدود شده</Text>

                            <Text style={styles.text_two_button_audience_blocked}>هیچکدام</Text>
                        </TouchableOpacity>
                    </Box>
                    {/* End Section Content */}
                </Box>
                {/* End Section App */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class