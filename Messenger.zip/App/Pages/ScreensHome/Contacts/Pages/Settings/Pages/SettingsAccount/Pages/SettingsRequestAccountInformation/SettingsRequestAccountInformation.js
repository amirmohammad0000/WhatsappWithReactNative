﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity } from "react-native";
import { styles } from "./Css/CssRequestAccountInformation";
import { NativeBaseProvider, Box, Image, Text } from "native-base";
import { AntDesign, MaterialCommunityIcons } from "@expo/vector-icons";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class SettingsRequestAccountInformation extends React.Component {
    FuncGoToPageSettingsAccount = () => {
        this.props.navigation.goBack();
    };

    FuncSetRequestAccountInformation = () => {

    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <Box name="App" style={styles.app}>
                    {/* Start Section Header */}
                    <Box name="Header" style={styles.header}>
                        <Box />

                        <Box name="Box_Center_Header" style={styles.box_center_header}>
                            <Text style={styles.text_header}>درخواست اطلاعات حساب</Text>
                        </Box>

                        <TouchableOpacity
                            onPress={() => {
                                this.FuncGoToPageSettingsAccount();
                            }}
                            name="Box_Right_Header"
                            style={styles.button_back}>
                            <AntDesign name="arrowright" style={styles.icon_back} />
                        </TouchableOpacity>
                    </Box>
                    {/* End Section Header */}

                    {/* Start Section Content */}
                    <Box name="Content" style={styles.content}>
                        <Box name="Box_Image" style={styles.box_image}>
                            <Image alt="Image" source={require("./../../../../../../../../../Assets/Images/ImageDocument.png")} style={styles.image_document} />
                        </Box>

                        <Box name="Box_Text" style={styles.box_text}>
                            <Text style={styles.text_box_text}>
                                گزارشی از تنظیمات و اطلاعات حساب واتساپ خود تهیه کنید; میتوانید این گزارش را در گوشی خود ببینید و با یه برنامه دیگر بفرستید.
                                این گزارش شمال پیام های شما نیست.بیشتر بدانید
                            </Text>
                        </Box>

                        <TouchableOpacity
                            name="Button_Request_Account_Information"
                            style={styles.button_request_account_information}
                            onPress={() => {
                                this.FuncSetRequestAccountInformation();
                            }}>
                            <MaterialCommunityIcons name="file-document" style={styles.icon_document} />

                            <Text style={styles.text_button_request_account_information}>درخواست گزارش</Text>
                        </TouchableOpacity>
                    </Box>
                    {/* End Section Content */}
                </Box>
                {/* End Section App */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class