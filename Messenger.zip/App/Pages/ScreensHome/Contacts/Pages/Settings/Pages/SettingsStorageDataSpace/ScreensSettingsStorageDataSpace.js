//////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import AppStorageDataSpacePage from "./Pages/AppStorageDataSpacePage/AppStorageDataSpacePage";
import SettingsMemoryManagement from "./Pages/SettingsMemoryManagement/SettingsMemoryManagement";
import SettingsNetworkConsumption from "./Pages/SettingsNetworkConsumption/SettingsNetworkConsumption";
//////////////////////////////////////////////////////////////////////// End Section Import

const Stack = createNativeStackNavigator();

//////////////////////////////////////////////////////////////////////// Start Section Class
export default class SettingsStorageDataSpace extends React.Component {
    render() {
        return (<Stack.Navigator>
            {/* Start Section Stack */}
            <Stack.Screen
                name="AppStorageDataSpacePage"
                component={AppStorageDataSpacePage}
                options={{
                    headerShown: false,
                }}
            />
            <Stack.Screen
                name="SettingsMemoryManagement"
                component={SettingsMemoryManagement}
                options={{
                    headerShown: false,
                }}
            />
            <Stack.Screen
                name="SettingsNetworkConsumption"
                component={SettingsNetworkConsumption}
                options={{
                    headerShown: false,
                }}
            />
            {/* End Section Stack */}
        </Stack.Navigator>
        );
    }
}
//////////////////////////////////////////////////////////////////////// End Section Class