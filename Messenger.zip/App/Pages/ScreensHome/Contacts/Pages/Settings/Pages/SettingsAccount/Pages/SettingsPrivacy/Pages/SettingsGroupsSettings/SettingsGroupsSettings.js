﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity } from "react-native";
import { styles } from "./Css/CssSettingsGroupsSettings";
import { NativeBaseProvider, Box, Text } from "native-base";
import { AntDesign } from "@expo/vector-icons";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class SettingsGroupsSettings extends React.Component {
    FuncGoToPageSettingsPrivacy = () => {
        this.props.navigation.goBack();
    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <Box name="App" style={styles.app}>
                    {/* Start Section Header */}
                    <Box name="Header" style={styles.header}>
                        <Box />

                        <Box name="Box_Center_Header" style={styles.box_center_header} >
                            <Text style={styles.text_header}>گروه ها</Text>
                        </Box>

                        <TouchableOpacity
                            onPress={() => {
                                this.FuncGoToPageSettingsPrivacy();
                            }}
                            name="Box_Right_Header"
                            style={styles.button_back}>
                            <AntDesign name="arrowright" style={styles.icon_back} />
                        </TouchableOpacity>
                    </Box>
                    {/* End Section Header */}

                    {/* Start Section Content */}
                    <Box name="Content" style={styles.content}>

                    </Box>
                    {/* End Section Content */}
                </Box>
                {/* End Section App */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class