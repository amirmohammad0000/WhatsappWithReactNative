/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import { StyleSheet } from "react-native";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Style
const styles = StyleSheet.create({
    //////////////////////////////// Start Style App
    app: {
        width: "100%",
        height: "100%",
    },
    //////////////////////////////// End Style App

    //////////////////////////////// Start Style Header
    header: {
        width: "100%",
        height: 60,
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "flex-end",
        backgroundColor: "#072",
    },

    box_center_header: {
        width: "90%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 30,
    },

    text_header: {
        color: "#eee",
        fontSize: 20,
    },

    button_back: {
        width: "10%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    icon_back: {
        color: "#eee",
        fontSize: 22,
    },
    //////////////////////////////// End Style Header

    //////////////////////////////// Start Style Content
    content: {
        width: "100%",
        height: "92%",
    },

    box_header_content: {
        width: "100%",
        height: 130,
        borderBottomColor: "#ddd",
        borderBottomWidth: 1,
        marginLeft: 70,
    },

    text_one_header_content: {
        color: "#f55",
        fontSize: 16,
        paddingTop: 20,
        paddingBottom: 10,
    },

    text_two_header_content: {
        color: "#666",
        fontSize: 14,
    },

    text_three_header_content: {
        color: "#666",
        fontSize: 14,
    },

    text_four_header_content: {
        color: "#666",
        fontSize: 14,
    },

    box_change_number_phone_content: {
        width: "100%",
        height: 140,
        borderBottomColor: "#ddd",
        borderBottomWidth: 1,
    },

    box_top_change_number_phone_content: {
        width: "100%",
        height: "50%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "flex-end",
    },

    text_change_number_phone_content: {
        color: "#222",
        fontSize: 18,
        paddingRight: 25,
    },

    icon_change_number_phone_content: {
        color: "#888",
        fontSize: 20,
        paddingRight: 25,
    },

    button_change_number_phone: {
        width: "20%",
        height: 40,
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "#082",
        marginLeft: 75,
    },

    text_button_change_number_phone: {
        color: "#eee",
        fontSize: 14,
    },

    box_select_coutry_phone_number: {
        width: "100%",
        height: 300,
        paddingLeft: 70,
        paddingRight: 10,
    },

    text_select_coutry_phone_number: {
        color: "#222",
        fontSize: 14,
        marginTop: 10,
    },

    text_country_top_input: {
        color: "#666",
        fontSize: 12,
        marginTop: 25,
    },

    box_select_country: {
        width: "97%",
        height: "25%",
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        borderBottomColor: "#000",
        borderBottomWidth: 2,
        marginTop: 2,
    },

    text_select_country: {
        color: "#000",
        fontSize: 15,
    },

    icon_down_content: {
        color: "#555",
        fontSize: 12,
    },

    box_input_content: {
        width: "96%",
        height: 80,
        alignItems: "flex-start",
        justifyContent: "flex-end",
    },

    text_number_top_input: {
        color: "#666",
        fontSize: 13,
    },

    box_inner_input_content: {
        width: "100%",
        height: "100%",
        flexDirection: "row-reverse",
        alignItems: "flex-start",
        justifyContent: "space-between",
    },

    box_input_code_phone_number: {
        width: "18%",
        height: "50%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "center",
        borderBottomColor: "#082",
        borderBottomWidth: 1,
    },

    text_input_code_phone_number: {
        color: "#888",
        fontSize: 15,
        marginRight: 10,
    },

    box_input_phone_number: {
        width: "78%",
        height: "50%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "center",
        borderBottomColor: "#082",
        borderBottomWidth: 1,
    },

    button_delete_acount: {
        width: "32%",
        height: 40,
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "#f11",
        borderRadius: 2,
    },

    text_delete_acount: {
        color: "#eee",
        fontSize: 15,
    },
    //////////////////////////////// End Style Content

    //////////////////////////////// Start Style Select Code Number
    box_select_code_number: {
        width: "100%",
        height: "100%",
        backgroundColor: "#fff",
        position: "absolute",
    },

    box_header_select_code_number: {
        width: "100%",
        height: 62,
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "space-between",
        borderBottomColor: "#99999999",
        borderBottomWidth: 1,
    },

    icon_search_select_code_number: {
        color: "#aaa",
        fontSize: 22,
        marginRight: 20,
    },

    box_icon_text_select_code_number: {
        width: "35%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "space-between",
    },

    text_header_select_code_number: {
        color: "#096",
    },

    icon_arrow_select_code_number: {
        color: "#aaa",
        fontSize: 24,
        marginLeft: 20,
    },

    box_country: {
        width: "100%",
        height: "92%",
    },

    box_search_select_code_number: {
        position: "absolute",
        width: "100%",
        height: 62,
        backgroundColor: "#fff",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "space-evenly",
    },

    icon_delete_search_select_code_number: {
        color: "#aaa",
        fontSize: 24,
    },

    box_input_search_select_code_number: {
        width: "80%",
        height: "100%",
    },

    icon_arrow_search_select_code_number: {
        color: "#aaa",
        fontSize: 25,
    },
    //////////////////////////////// End Style Select Code Number
});
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Style
export { styles };