﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity } from "react-native";
import { styles } from "./Css/CssSettingsSecurity";
import { NativeBaseProvider, Box, Image, Text } from "native-base";
import { AntDesign } from "@expo/vector-icons";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class SettingsSecurity extends React.Component {
    FuncGoToPageSettingsAccount = () => {
        this.props.navigation.goBack();
    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <Box name="App" style={styles.app}>
                    {/* Start Section Header */}
                    <Box name="Header" style={styles.header}>
                        <Box />

                        <Box name="Box_Center_Header" style={styles.box_center_header} >
                            <Text style={styles.text_header}>امنیت</Text>
                        </Box>

                        <TouchableOpacity
                            onPress={() => {
                                this.FuncGoToPageSettingsAccount();
                            }}
                            name="Box_Right_Header"
                            style={styles.button_back}>
                            <AntDesign name="arrowright" style={styles.icon_back} />
                        </TouchableOpacity>
                    </Box>
                    {/* End Section Header */}

                    {/* Start Section Content */}
                    <Box name="Content" style={styles.content}>
                        <Box name="Box_Image" style={styles.box_image}>
                            <Image alt="Image Security" source={require("./../../../../../../../../../Assets/Images/ImageSecurity.png")} style={styles.image_security} />
                        </Box>

                        <Box name="Box_Text" style={styles.box_text}>
                            <Text style={styles.text_security}>
                                واتساپ مکالمات را با رمزگذاری سرتاسری محافظت میکند. معنای ان این است که پیام,
                                تماس ها و بروزرسانی های وضعیت بین شما و افرادی که انتخاب میکنید,
                                محفوظ باقی می ماند. حتی واتساپ هم نمی تواند ان ها را بخواند یا بشنود. بیشتر بدانید
                            </Text>
                        </Box>
                    </Box>
                    {/* End Section Content */}
                </Box>
                {/* End Section App */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class