/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import { StyleSheet } from "react-native";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Style
const styles = StyleSheet.create({
    //////////////////////////////// Start Style App
    app: {
        width: "100%",
        height: "100%",
    },
    //////////////////////////////// End Style App

    //////////////////////////////// Start Style Header
    header: {
        width: "100%",
        height: "8%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "flex-end",
        backgroundColor: "#072",
    },

    box_menu_header: {
        width: "10%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    icon_menu: {
        color: "#eee",
        fontSize: 18,
    },

    box_text_header: {
        width: "80%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 30,
    },

    text_header: {
        color: "#eee",
        fontSize: 18,
    },

    box_icon_header: {
        width: "10%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 20,
    },

    icon_back: {
        color: "#eee",
        fontSize: 22,
    },
    //////////////////////////////// End Style Header

    //////////////////////////////// Start Style Content
    content: {
        width: "100%",
        height: "92%",
    },

    button_conversation_ring: {
        width: "100%",
        height: 80,
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "space-between",
        paddingRight: 25,
        paddingLeft: 15,
        borderBottomColor: "#ddd",
        borderBottomWidth: 1,
    },

    text_top_conversation_ring: {
        color: "#222",
        fontSize: 16,
    },

    text_bottom_conversation_ring: {
        color: "#666",
        fontSize: 14,
    },

    box_message: {
        width: "100%",
        height: 420,
        borderBottomColor: "#ddd",
        borderBottomWidth: 1,
    },

    text_header_message: {
        color: "#666",
        fontSize: 14,
        paddingTop: 25,
        paddingRight: 25,
    },

    button_ring_announcement_message: {
        width: "100%",
        height: "18%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 25,
    },

    text_top_ring_announcement_message: {
        color: "#222",
        fontSize: 16,
    },

    text_bottom_ring_announcement_message: {
        color: "#666",
        fontSize: 14,
    },

    button_tremor_message: {
        width: "100%",
        height: "18%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 25,
    },

    text_top_tremor_message: {
        color: "#222",
        fontSize: 16,
    },

    text_bottom_tremor_message: {
        color: "#666",
        fontSize: 14,
    },

    button_opening_notification_message: {
        width: "100%",
        height: "18%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 25,
    },

    text_top_opening_notification_message: {
        color: "#222",
        fontSize: 16,
    },

    text_bottom_opening_notification_message: {
        color: "#666",
        fontSize: 14,
    },

    button_light_message: {
        width: "100%",
        height: "18%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 25,
    },

    text_top_light_message: {
        color: "#222",
        fontSize: 16,
    },

    text_bottom_light_message: {
        color: "#666",
        fontSize: 14,
    },

    button_high_priority_announcement_message: {
        width: "100%",
        height: "18%",
        flexDirection: "row-reverse",
        alignItems: "flex-start",
        justifyContent: "space-between",
        paddingLeft: 20,
        paddingRight: 25,
    },

    text_top_high_priority_announcement_message: {
        color: "#222",
        fontSize: 16,
    },

    text_bottom_high_priority_announcement_message: {
        color: "#666",
        fontSize: 14,
    },

    box_calls: {
        width: "100%",
        height: 220,
    },

    text_header_calls: {
        color: "#666",
        fontSize: 14,
        paddingTop: 25,
        paddingRight: 25,
    },

    button_bell_calls: {
        width: "100%",
        height: 90,
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 25,
    },

    text_top_bell_calls: {
        color: "#222",
        fontSize: 16,
    },

    text_bottom_bell_calls: {
        color: "#666",
        fontSize: 14,
    },

    button_trembling_calls: {
        width: "100%",
        height: 90,
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 25,
    },

    text_top_trembling_calls: {
        color: "#222",
        fontSize: 16,
    },

    text_bottom_trembling_calls: {
        color: "#666",
        fontSize: 14,
    },
    //////////////////////////////// End Style Content

    /////////////////////////////// Start Section Menu
    menu: {
        position: "absolute",
        top: 0,
        width: "45%",
        height: "7%",
        backgroundColor: "#fff",
        borderRadius: 2,
    },

    menu_item: {
        width: "100%",
        height: 47,
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 20,
    },

    text_menu_item: {
        color: "#222",
        fontSize: 16,
    },
    /////////////////////////////// End Section Menu
});
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Style
export { styles };