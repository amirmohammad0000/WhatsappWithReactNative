﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity } from "react-native";
import { styles } from "./Css/CssAppStorageDataSpacePage";
import { NativeBaseProvider, Box, Switch, Text } from "native-base";
import { AntDesign, FontAwesome, MaterialIcons } from "@expo/vector-icons";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class AppStorageDataSpacePage extends React.Component {
    state = {
        CheckUseingDataForCall: true,
    };

    FuncGoToPageSettingsStorageDataSpace = () => {
        this.props.navigation.goBack();
    };

    FuncGoToPageSettingsMemoryManagement = () => {
        this.props.navigation.navigate("SettingsMemoryManagement");
    };

    FuncGoToPageSettingsNetworkConsumption = () => {
        this.props.navigation.navigate("SettingsNetworkConsumption");
    };

    FuncSwitchUseingDataForCall = () => {
        this.setState({
            CheckUseingDataForCall: !this.state.CheckUseingDataForCall,
        });
    };

    FuncSetInternetPhone = () => {

    };

    FuncSetWiFi = () => {

    };

    FuncSetRoaming = () => {

    };

    FuncSetQualityUploadImage = () => {

    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <Box name="App" style={styles.app}>
                    {/* Start Sectino Header*/}
                    <Box name="Header" style={styles.header}>
                        <Box />

                        <Box name="Box_Text_Header" style={styles.box_text_header}>
                            <Text style={styles.text_header}>فضای ذخیره سازی و داده</Text>
                        </Box>

                        <TouchableOpacity
                            name="Box_Icon_Header"
                            style={styles.box_icon_header}
                            onPress={() => {
                                this.FuncGoToPageSettingsStorageDataSpace();
                            }}>
                            <AntDesign name="arrowright" style={styles.icon_back} />
                        </TouchableOpacity>
                    </Box>
                    {/* End Sectino Header*/}

                    {/* Start Sectino Content */}
                    <Box name="Content" style={styles.content}>
                        <TouchableOpacity
                            name="Button_Manage_Storange"
                            style={styles.button_manage_storange}
                            onPress={() => {
                                this.FuncGoToPageSettingsMemoryManagement();
                            }}>
                            <FontAwesome name="folder" style={styles.icon_manage_storange} />

                            <Box>
                                <Text style={styles.text_top_manage_storange}>مدیریت حافظه ذخیره سازی</Text>
                                <Text style={styles.text_bottom_manage_storange}>0 کیلوبایت</Text>
                            </Box>
                        </TouchableOpacity>

                        <TouchableOpacity
                            name="Button_Network_Consumption"
                            style={styles.button_network_consumption}
                            onPress={() => {
                                this.FuncGoToPageSettingsNetworkConsumption();
                            }}>
                            <MaterialIcons name="data-usage" style={styles.icon_network_consumption} />

                            <Box>
                                <Text style={styles.text_top_network_consumption}>مصرف شبکه</Text>
                                <Text style={styles.text_bottom_network_consumption}>"39 کیلوبایت" ارسال شده -- "16/8 مگابایت" دریافت شده</Text>
                            </Box>
                        </TouchableOpacity>

                        <TouchableOpacity
                            name="Button_Useing_Data_For_Call"
                            style={styles.button_useing_data_for_call}
                            onPress={() => {
                                this.FuncSwitchUseingDataForCall();
                            }}>
                            <Switch
                                isChecked={this.state.CheckUseingDataForCall}
                                onChange={() => {
                                    this.FuncSwitchUseingDataForCall();
                                }} />

                            <Text>استفاده از میزان داده کمتری برای تماس</Text>
                        </TouchableOpacity>

                        <Box name="Box_Download_Auto_Media" style={styles.box_download_auto_media}>
                            <Text style={styles.text_header_one_download_auto_media}>بارگیری خودکار رسانه</Text>

                            <Text style={styles.text_header_two_download_auto_media}>پیام های صوتی همیشه به طور خودکار دانلود میشود</Text>

                            <TouchableOpacity
                                name="Button_Internet_Phone"
                                style={styles.button_internet_phone}
                                onPress={() => {
                                    this.FuncSetInternetPhone();
                                }}>
                                <Text style={styles.text_one_internet_phone}>هنگام استفاده از اینترنت تلفن همراه</Text>

                                <Text style={styles.text_two_internet_phone}>بدون رسانه</Text>
                            </TouchableOpacity>

                            <TouchableOpacity
                                name="Button_Wifi"
                                style={styles.button_wifi}
                                onPress={() => {
                                    this.FuncSetWiFi();
                                }}>
                                <Text style={styles.text_one_Wifi}>هنگام اتصال به وای فای</Text>

                                <Text style={styles.text_two_Wifi}>بدون رسانه</Text>
                            </TouchableOpacity>

                            <TouchableOpacity
                                name="Button_Roaming"
                                style={styles.button_roaming}
                                onPress={() => {
                                    this.FuncSetRoaming();
                                }}>
                                <Text style={styles.text_one_roaming}>هنگام رومینگ</Text>

                                <Text style={styles.text_two_roaming}>بدون رسانه</Text>
                            </TouchableOpacity>
                        </Box>

                        <Box name="Box_Quality_Upload_Image" style={styles.box_quality_upload_image}>
                            <Text style={styles.text_one_header_quality_upload_image}>کیفیت اپلود رسانه</Text>

                            <Text style={styles.text_two_header_quality_upload_image}>کیفیت فایل های رسانه ارسالی را انتخاب کنید</Text>

                            <TouchableOpacity
                                name="Button_Quality_Upload_Image"
                                style={styles.button_quality_upload_image}
                                onPress={() => {
                                    this.FuncSetQualityUploadImage();
                                }}>
                                <Text style={styles.text_one_quality_upload_image}>کیفیت اپلود رسانه</Text>

                                <Text style={styles.text_two_quality_upload_image}>خودکار (توصیه میشود)</Text>
                            </TouchableOpacity>
                        </Box>
                    </Box>
                    {/* End Sectino Content */}
                </Box>
                {/* End Section App */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class