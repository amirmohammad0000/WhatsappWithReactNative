/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import { StyleSheet } from "react-native";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Style
const styles = StyleSheet.create({
    //////////////////////////////// Start Style App
    app: {
        width: "100%",
        height: "100%",
    },
    //////////////////////////////// End Style App

    //////////////////////////////// Start Style Header
    header: {
        width: "100%",
        height: 60,
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "flex-end",
        backgroundColor: "#072",
    },

    box_center_header: {
        width: "90%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 30,
    },

    text_header: {
        color: "#eee",
        fontSize: 20,
    },

    button_back: {
        width: "10%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    icon_back: {
        color: "#eee",
        fontSize: 22,
    },
    //////////////////////////////// End Style Header

    //////////////////////////////// Start Style Content
    content: {
        width: "100%",
        height: "92%",
    },

    box_header_content: {
        width: "100%",
        height: "12%",
        paddingTop: 15,
        paddingLeft: 25,
        paddingRight: 25,
    },

    text_one_header_content: {
        color: "#666",
        fontSize: 13,
    },

    text_two_header_content: {
        color: "#666",
        fontSize: 13,
    },

    button_last_view: {
        width: "100%",
        height: "10%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 25,
    },

    text_one_button_last_view: {
        color: "#222",
        fontSize: 16,
    },

    text_two_button_last_view: {
        color: "#666",
        fontSize: 14,
    },

    button_image_profile: {
        width: "100%",
        height: "10%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 25,
    },

    text_one_button_image_profile: {
        color: "#222",
        fontSize: 16,
    },

    text_two_button_image_profile: {
        color: "#666",
        fontSize: 14,
    },

    button_about: {
        width: "100%",
        height: "10%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 25,
    },

    text_one_button_about: {
        color: "#222",
        fontSize: 16,
    },

    text_two_button_about: {
        color: "#666",
        fontSize: 14,
    },

    button_status: {
        width: "100%",
        height: "10%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 25,
    },

    text_one_button_status: {
        color: "#222",
        fontSize: 16,
    },

    text_two_button_status: {
        color: "#666",
        fontSize: 14,
    },

    button_receipt_to_read: {
        width: "100%",
        height: "15%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "flex-end",
        borderBottomColor: "#ddd",
        borderBottomWidth: 1,
        paddingLeft: 80,
        paddingRight: 25,
    },

    text_one_button_receipt_to_read: {
        color: "#222",
        fontSize: 16,
    },

    text_two_button_receipt_to_read: {
        color: "#666",
        fontSize: 13,
    },

    button_group: {
        width: "100%",
        height: "10%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 25,
    },

    text_one_button_group: {
        color: "#222",
        fontSize: 16,
    },

    text_two_button_group: {
        color: "#666",
        fontSize: 14,
    },

    button_live_place: {
        width: "100%",
        height: "10%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 25,
    },

    text_one_button_live_place: {
        color: "#222",
        fontSize: 16,
    },

    text_two_button_live_place: {
        color: "#666",
        fontSize: 14,
    },

    button_audience_blocked: {
        width: "100%",
        height: "10%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 25,
    },

    text_one_button_audience_blocked: {
        color: "#222",
        fontSize: 16,
    },

    text_two_button_audience_blocked: {
        color: "#666",
        fontSize: 14,
    },
    //////////////////////////////// End Style Content
});
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Style
export { styles };