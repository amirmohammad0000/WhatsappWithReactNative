//////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import AppConversationPage from "./Pages/AppConversationPage/AppConversationPage";
import SettingsConversationBackup from "./Pages/SettingsConversationBackup/SettingsConversationBackup";
import SettingsConversationHistory from "./Pages/SettingsConversationHistory/SettingsConversationHistory";
import SettingsWallpaper from "./Pages/SettingsWallpaper/SettingsWallpaper";
//////////////////////////////////////////////////////////////////////// End Section Import

const Stack = createNativeStackNavigator();

//////////////////////////////////////////////////////////////////////// Start Section Class
export default class ScreensSettingsConversation extends React.Component {
    render() {
        return (
            <Stack.Navigator>
                {/* Start Section Stack */}
                <Stack.Screen
                    name="AppConversationPage"
                    component={AppConversationPage}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="SettingsConversationBackup"
                    component={SettingsConversationBackup}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="SettingsConversationHistory"
                    component={SettingsConversationHistory}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="SettingsWallpaper"
                    component={SettingsWallpaper}
                    options={{
                        headerShown: false,
                    }}
                />
                {/* End Section Stack */}
            </Stack.Navigator>
        );
    }
}
//////////////////////////////////////////////////////////////////////// End Section Class