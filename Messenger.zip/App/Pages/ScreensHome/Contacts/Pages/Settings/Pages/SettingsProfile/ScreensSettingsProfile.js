//////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import AppProfilePage from "./Pages/AppProfilePage/AppProfilePage";
import SettingsAbout from "./Pages/SettingsAbout/SettingsAbout";
import SettingsChangeNumber from "./../SettingsAccount/Pages/SettingsChangeNumber/SettingsChangeNumber";
//////////////////////////////////////////////////////////////////////// End Section Import

const Stack = createNativeStackNavigator();

//////////////////////////////////////////////////////////////////////// Start Section Class
export default class ScreensSettingsProfile extends React.Component {
    render() {
        return (
            <Stack.Navigator>
                {/* Start Section Stack */}
                <Stack.Screen
                    name="AppProfilePage"
                    component={AppProfilePage}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="SettingsAbout"
                    component={SettingsAbout}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="SettingsChangeNumber"
                    component={SettingsChangeNumber}
                    options={{
                        headerShown: false,
                    }}
                />
                {/* End Section Stack */}
            </Stack.Navigator>
        );
    }
}
//////////////////////////////////////////////////////////////////////// End Section Class