/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import { StyleSheet } from "react-native";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Style
const styles = StyleSheet.create({
    //////////////////////////////// Start Style App
    app: {
        width: "100%",
        height: "100%",
        backgroundColor: "#097",
    },
    //////////////////////////////// End Style App

    //////////////////////////////// Start Style Content
    content: {
        width: "100%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    text_one_ontent: {
        color: "#eee",
        fontSize: 20,
    },

    text_two_ontent: {
        color: "#aaa",
        fontSize: 20,
    },

    image_logo_app: {
        width: 150,
        height: 150,
        marginTop: 20,
        marginBottom: 50,
    },

    text_three_content: {
        fontSize: 16,
        borderBottomColor: "#009",
        borderBottomWidth: 1,
    },
    //////////////////////////////// End Style Content
});
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Style
export { styles };