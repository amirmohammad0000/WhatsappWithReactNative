/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import { StyleSheet } from "react-native";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Style
const styles = StyleSheet.create({
    //////////////////////////////// Start Style App
    app: {
        width: "100%",
        height: "100%",
    },
    //////////////////////////////// End Style App

    //////////////////////////////// Start Style Header
    header: {
        width: "100%",
        height: "8%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "flex-end",
        backgroundColor: "#072",
    },

    box_text_header: {
        width: "90%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 30,
    },

    text_header: {
        color: "#eee",
        fontSize: 18,
    },

    box_icon_header: {
        width: "10%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 20,
    },

    icon_back: {
        color: "#eee",
        fontSize: 22,
    },
    //////////////////////////////// End Style Header

    //////////////////////////////// Start Style Content
    content: {
        width: "100%",
        height: "92%",
    },

    box_current_about: {
        width: "100%",
        height: "15%",
        borderBottomColor: "#ddd",
        borderBottomWidth: 1,
    },

    text_current_about: {
        color: "#666",
        fontSize: 14,
        paddingTop: 15,
        paddingRight: 25,
    },

    box_inner_current_box: {
        width: "100%",
        height: "70%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "space-between",
        paddingLeft: 25,
        paddingRight: 25,
    },

    icon_current_box: {
        color: "#082",
        fontSize: 16,
    },

    text_state_about: {
        color: "#222",
        fontSize: 16,
    },

    box_select_about: {
        width: "100%",
        height: "85%",
    },

    text_select_about: {
        color: "#666",
        fontSize: 14,
        paddingTop: 20,
        paddingRight: 25,
        paddingBottom: 20,
    },

    button_item_select_about: {
        width: "100%",
        height: "8%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 25,
    },

    text_item_select_about: {
        color: "#222",
        fontSize: 16,
    },
    //////////////////////////////// End Style Content
});
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Style
export { styles };