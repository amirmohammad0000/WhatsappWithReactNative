/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import { StyleSheet } from "react-native";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Style
const styles = StyleSheet.create({
    //////////////////////////////// Start Style App
    app: {
        width: "100%",
        height: "100%",
    },
    //////////////////////////////// End Style App

    //////////////////////////////// Start Style Header
    header: {
        width: "100%",
        height: 60,
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "flex-end",
        backgroundColor: "#072",
    },

    box_center_header: {
        width: "90%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 30,
    },

    text_header: {
        color: "#eee",
        fontSize: 20,
    },

    button_back: {
        width: "10%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    icon_back: {
        color: "#eee",
        fontSize: 22,
    },
    //////////////////////////////// End Style Header

    //////////////////////////////// Start Style Content
    content: {
        width: "100%",
        height: "92%",
    },

    box_false_state_Live_place: {
        width: "100%",
        height: "100%",
    },

    box_image: {
        width: "100%",
        height: "20%",
        alignItems: "center",
        justifyContent: "center",
    },

    image_live_place: {
        width: 120,
        height: 120,
    },

    box_bottom_image: {
        width: "100%",
        height: "7%",
        alignItems: "center",
        justifyContent: "center",
        borderBottomColor: "#ddd",
        borderBottomWidth: 1,
    },

    text_bottom_image: {
        color: "#222",
        fontSize: 16,
    },

    box_footer_content: {
        width: "100%",
        height: "10%",
        alignItems: "center",
        justifyContent: "center",
        paddingRight: 20,
        paddingLeft: 25,
    },

    text_footer: {
        color: "#666",
        fontSize: 13,
    },
    //////////////////////////////// End Style Content
});
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Style
export { styles };