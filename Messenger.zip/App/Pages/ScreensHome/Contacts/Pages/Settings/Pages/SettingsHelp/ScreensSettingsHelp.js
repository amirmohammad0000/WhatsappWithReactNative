//////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import AppHelpPage from "./Pages/AppHelpPage/AppHelpPage";
import SettingsContactUs from "./Pages/SettingsContactUs/SettingsContactUs";
import SettingsProgramInformation from "./Pages/SettingsProgramInformation/SettingsProgramInformation";
//////////////////////////////////////////////////////////////////////// End Section Import

const Stack = createNativeStackNavigator();

//////////////////////////////////////////////////////////////////////// Start Section Class
export default class ScreensSettingsHelp extends React.Component {
    render() {
        return (
            <Stack.Navigator>
                {/* Start Section Stack */}
                <Stack.Screen
                    name="AppHelpPage"
                    component={AppHelpPage}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="SettingsContactUs"
                    component={SettingsContactUs}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="SettingsProgramInformation"
                    component={SettingsProgramInformation}
                    options={{
                        headerShown: false,
                    }}
                />
                {/* End Section Stack */}
            </Stack.Navigator>
        );
    }
}
//////////////////////////////////////////////////////////////////////// End Section Class