﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity } from "react-native";
import { styles } from "./Css/CssSettingsWallpaper";
import { NativeBaseProvider, Box, Image, Text } from "native-base";
import { AntDesign } from "@expo/vector-icons";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class SettingsWallpaper extends React.Component {
    FuncGoToPageSettingsConversation = () => {
        this.props.navigation.goBack();
    };

    FuncSetWallPaper = () => {

    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <Box name="App" style={styles.app}>
                    {/* Start Sectino Header*/}
                    <Box name="Header" style={styles.header}>
                        <Box />

                        <Box name="Box_Text_Header" style={styles.box_text_header}>
                            <Text style={styles.text_header}>کاغذ دیواری طرح زمینه</Text>
                        </Box>

                        <TouchableOpacity
                            name="Box_Icon_Header"
                            style={styles.box_icon_header}
                            onPress={() => {
                                this.FuncGoToPageSettingsConversation();
                            }}>
                            <AntDesign name="arrowright" style={styles.icon_back} />
                        </TouchableOpacity>
                    </Box>
                    {/* End Sectino Header*/}

                    {/* Start Sectino Content */}
                    <Box name="Content" style={styles.content}>
                        <TouchableOpacity
                            name="Button_Image"
                            style={styles.button_image}
                            onPress={() => {
                                this.FuncSetWallPaper();
                            }}>
                            <Image alt="Image Wall Paper" source={require("./../../../../../../../../../Assets/Images/ImageWallPaper.png")} style={styles.image_wall_paper} />
                        </TouchableOpacity>

                        <TouchableOpacity
                            name="Button_Change"
                            style={styles.button_change}
                            onPress={() => {
                                this.FuncSetWallPaper();
                            }}>
                            <Text style={styles.text_change}>تغییر</Text>
                        </TouchableOpacity>

                        <Text style={styles.text_footer}>برای تعغیر کاغذ دیواری حالت تیره, از تنظیمات گفتگو  طرح های زمینه, حالت تیره را فعال کنید</Text>
                    </Box>
                    {/* End Sectino Content */}
                </Box>
                {/* End Section App */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class