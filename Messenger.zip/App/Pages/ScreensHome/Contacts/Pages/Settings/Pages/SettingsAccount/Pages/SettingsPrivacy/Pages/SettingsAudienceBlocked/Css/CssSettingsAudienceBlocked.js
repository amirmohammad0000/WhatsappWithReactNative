/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import { StyleSheet } from "react-native";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Style
const styles = StyleSheet.create({
    //////////////////////////////// Start Style App
    app: {
        width: "100%",
        height: "100%",
    },
    //////////////////////////////// End Style App

    //////////////////////////////// Start Style Header
    header: {
        width: "100%",
        height: 60,
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "flex-end",
        backgroundColor: "#072",
    },

    box_left_header: {
        width: "10%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    icon_add_contacts: {
        color: "#eee",
        fontSize: 20,
    },

    box_center_header: {
        width: "80%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 30,
    },

    text_header: {
        color: "#eee",
        fontSize: 20,
    },

    button_back: {
        width: "10%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    icon_back: {
        color: "#eee",
        fontSize: 22,
    },
    //////////////////////////////// End Style Header

    //////////////////////////////// Start Style Content
    content: {
        width: "100%",
        height: "92%",
    },

    box_image: {
        width: "100%",
        height: "20%",
        alignItems: "center",
        justifyContent: "center",
    },

    image_audience_blocked: {
        width: 120,
        height: 120,
    },

    box_text: {
        width: "100%",
        height: "17%",
        alignItems: "center",
        borderBottomColor: "#ddd",
        borderBottomWidth: 1,
    },

    text_one: {
        color: "#222",
        fontSize: 16,
        paddingTop: 20,
    },

    text_two: {
        color: "#222",
        fontSize: 16,
        paddingTop: 20,
        paddingRight: 50,
        paddingLeft: 50,
        textAlign: "center",
    },

    box_footer: {
        width: "100%",
        height: "10%",
        alignItems: "center",
        justifyContent: "center",
    },

    text_footer: {
        color: "#666",
        fontSize: 13,
    },
    //////////////////////////////// End Style Content
});
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Style
export { styles };