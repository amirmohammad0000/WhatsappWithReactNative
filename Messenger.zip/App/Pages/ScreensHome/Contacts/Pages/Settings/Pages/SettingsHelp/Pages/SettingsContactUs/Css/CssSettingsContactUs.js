/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import { StyleSheet } from "react-native";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Style
const styles = StyleSheet.create({
    //////////////////////////////// Start Style App
    app: {
        width: "100%",
        height: "100%",
    },
    //////////////////////////////// End Style App

    //////////////////////////////// Start Style Header
    header: {
        width: "100%",
        height: 60,
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "flex-end",
        backgroundColor: "#072",
    },

    box_text_header: {
        width: "90%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 30,
    },

    text_header: {
        color: "#eee",
        fontSize: 18,
    },

    box_icon_header: {
        width: "10%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 20,
    },

    icon_back: {
        color: "#eee",
        fontSize: 22,
    },
    //////////////////////////////// End Style Header

    //////////////////////////////// Start Style Content
    content: {
        width: "100%",
        height: "52%",
    },

    box_text_area: {
        width: "100%",
        height: 120,
        alignItems: "center",
        justifyContent: "flex-end",
    },

    box_add_image: {
        width: "100%",
        height: 200,
    },

    text_add_image: {
        color: "#082",
        fontSize: 14,
        paddingRight: 25,
        paddingTop: 25,
    },

    box_add_image_inner: {
        width: "100%",
        height: "78%",
        flexDirection: "row",
        marginLeft: 25,
        marginTop: 25,
    },

    button_add_image_inner: {
        width: "22%",
        height: "64%",
        marginRight: 5,
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "#88888811",
    },

    icon_add_image_inner: {
        color: "#999",
        fontSize: 25,
    },

    box_footer: {
        width: "100%",
        height: 80,
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "space-between",
        position: "absolute",
        bottom: 0,
        paddingHorizontal: 25,
    },

    button_next_footer: {
        width: "20%",
        height: "50%",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "#082",
    },

    text_next_footer: {
        color: "#eee",
        fontSize: 14,
    },

    text_footer: {
        color: "#099",
        fontSize: 15,
    },
    //////////////////////////////// End Style Content
});
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Style
export { styles };