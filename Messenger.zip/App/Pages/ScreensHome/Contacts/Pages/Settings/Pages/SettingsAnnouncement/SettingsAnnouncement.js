﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity, ScrollView } from "react-native";
import { styles } from "./Css/CssSettingsAnnouncement";
import { NativeBaseProvider, Box, Switch, Text } from "native-base";
import { Entypo, AntDesign } from "@expo/vector-icons";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class SettingsAnnouncement extends React.Component {
    state = {
        CheckConversationRing: true,
        CheckHighPriorityAnnouncementMessage: true,
        CheckHighPriorityAnnouncementGroup: true,
        PositionMenu: "100%",
    };

    FuncGoToPageAppSettingsPage = () => {
        this.props.navigation.goBack();
    };

    FuncOpenMenu = () => {
        this.setState({
            PositionMenu: "55%",
        });
    };

    FuncCloseMenu = () => {
        this.setState({
            PositionMenu: "100%",
        });
    };

    FuncSwitchConversationRing = () => {
        this.setState({
            CheckConversationRing: !this.state.CheckConversationRing,
        });
    };

    FuncSetRingAnnouncementMessage = () => {

    };

    FuncSetTremorMessage = () => {

    };

    FuncSetOpeningNotificationMessage = () => {

    };

    FuncSetlightMessage = () => {

    };

    FuncSwitchHighPriorityAnnouncementMessage = () => {
        this.setState({
            CheckHighPriorityAnnouncementMessage: !this.state.CheckHighPriorityAnnouncementMessage,
        });
    };

    FuncSetRingAnnouncementGroup = () => {

    };

    FuncSetTremorGroup = () => {

    };

    FuncSetOpeningNotificationGroup = () => {

    };

    FuncSetlightGroup = () => {

    };

    FuncSwitchHighPriorityAnnouncementGroup = () => {
        this.setState({
            CheckHighPriorityAnnouncementGroup: !this.state.CheckHighPriorityAnnouncementGroup,
        });
    };

    FuncSetBellCalls = () => {

    };

    FuncSetTremblingCalls = () => {

    };

    FuncSetDefaultSettingsAnnouncement = () => {

    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <TouchableOpacity activeOpacity={1} onPress={() => {
                    this.FuncCloseMenu();
                }}>
                    <Box name="App" style={styles.app}>
                        {/* Start Sectino Header*/}
                        <Box name="Header" style={styles.header}>
                            <TouchableOpacity
                                name="Box_Menu_Header"
                                style={styles.box_menu_header}
                                onPress={() => {
                                    this.FuncOpenMenu();
                                }}>
                                <Entypo name="dots-three-vertical" style={styles.icon_menu} />
                            </TouchableOpacity>

                            <Box name="Box_Text_Header" style={styles.box_text_header}>
                                <Text style={styles.text_header}>اعلان ها</Text>
                            </Box>

                            <TouchableOpacity
                                name="Box_Icon_Header"
                                style={styles.box_icon_header}
                                onPress={() => {
                                    this.FuncGoToPageAppSettingsPage();
                                }}>
                                <AntDesign name="arrowright" style={styles.icon_back} />
                            </TouchableOpacity>
                        </Box>
                        {/* End Sectino Header*/}

                        {/* Start Section Content */}
                        <ScrollView>
                            <Box name="Content" style={styles.content}>
                                <TouchableOpacity
                                    name="Button_Conversation_Ring"
                                    style={styles.button_conversation_ring}
                                    onPress={() => {
                                        this.FuncSwitchConversationRing();
                                    }}>
                                    <Switch
                                        isChecked={this.state.CheckConversationRing}
                                        onChange={() => {
                                            this.FuncSwitchConversationRing();
                                        }} />

                                    <Box>
                                        <Text style={styles.text_top_conversation_ring}>زنگ های مکالمه</Text>
                                        <Text style={styles.text_bottom_conversation_ring}>صدای دریافت و ارسال پیام</Text>
                                    </Box>
                                </TouchableOpacity>

                                <Box name="Box_Message" style={styles.box_message}>
                                    <Text style={styles.text_header_message}>پیام ها</Text>

                                    <TouchableOpacity
                                        name="Button_Ring_Announcement_Message"
                                        style={styles.button_ring_announcement_message}
                                        onPress={() => {
                                            this.FuncSetRingAnnouncementMessage();
                                        }}>
                                        <Text style={styles.text_top_ring_announcement_message}>زنگ اعلان</Text>
                                        <Text style={styles.text_bottom_ring_announcement_message}>اهنگ زنگ پیش فرض (Skyline)</Text>
                                    </TouchableOpacity>

                                    <TouchableOpacity
                                        name="Button_Tremor_Message"
                                        style={styles.button_tremor_message}
                                        onPress={() => {
                                            this.FuncSetTremorMessage();
                                        }}>
                                        <Text style={styles.text_top_tremor_message}>لرزش</Text>
                                        <Text style={styles.text_bottom_tremor_message}>پیش فرض</Text>
                                    </TouchableOpacity>

                                    <TouchableOpacity
                                        name="Button_Opening_Notification_Message"
                                        style={styles.button_opening_notification_message}
                                        onPress={() => {
                                            this.FuncSetOpeningNotificationMessage();
                                        }}>
                                        <Text style={styles.text_top_opening_notification_message}>اعلان بازشونده</Text>
                                        <Text style={styles.text_bottom_opening_notification_message}>بدون پنجره</Text>
                                    </TouchableOpacity>

                                    <TouchableOpacity
                                        name="Button_light_Message"
                                        style={styles.button_light_message}
                                        onPress={() => {
                                            this.FuncSetlightMessage();
                                        }}>
                                        <Text style={styles.text_top_light_message}>نور</Text>
                                        <Text style={styles.text_bottom_light_message}>سفید</Text>
                                    </TouchableOpacity>

                                    <TouchableOpacity
                                        name="Button_High_Priority_Announcement_Message"
                                        style={styles.button_high_priority_announcement_message}
                                        onPress={() => {
                                            this.FuncSwitchHighPriorityAnnouncementMessage();
                                        }}>
                                        <Switch
                                            isChecked={this.state.CheckHighPriorityAnnouncementMessage}
                                            onChange={() => {
                                                this.FuncSwitchHighPriorityAnnouncementMessage();
                                            }} />

                                        <Box>
                                            <Text style={styles.text_top_high_priority_announcement_message}>استفاده از اعلان های اولویت بالا</Text>
                                            <Text style={styles.text_bottom_high_priority_announcement_message}>نمایش پیش دید اعلان ها در بالای صفحه</Text>
                                        </Box>
                                    </TouchableOpacity>
                                </Box>

                                <Box name="Box_Group" style={styles.box_message}>
                                    <Text style={styles.text_header_message}>گروه ها</Text>

                                    <TouchableOpacity
                                        name="Button_Ring_Announcement_Group"
                                        style={styles.button_ring_announcement_message}
                                        onPress={() => {
                                            this.FuncSetRingAnnouncementGroup();
                                        }}>
                                        <Text style={styles.text_top_ring_announcement_message}>زنگ اعلان</Text>
                                        <Text style={styles.text_bottom_ring_announcement_message}>اهنگ زنگ پیش فرض (Skyline)</Text>
                                    </TouchableOpacity>

                                    <TouchableOpacity
                                        name="Button_Tremor_Group"
                                        style={styles.button_tremor_message}
                                        onPress={() => {
                                            this.FuncSetTremorGroup();
                                        }}>
                                        <Text style={styles.text_top_tremor_message}>لرزش</Text>
                                        <Text style={styles.text_bottom_tremor_message}>پیش فرض</Text>
                                    </TouchableOpacity>

                                    <TouchableOpacity
                                        name="Button_Opening_Notification_Group"
                                        style={styles.button_opening_notification_message}
                                        onPress={() => {
                                            this.FuncSetOpeningNotificationGroup();
                                        }}>
                                        <Text style={styles.text_top_opening_notification_message}>اعلان بازشونده</Text>
                                        <Text style={styles.text_bottom_opening_notification_message}>بدون پنجره</Text>
                                    </TouchableOpacity>

                                    <TouchableOpacity
                                        name="Button_light_Group"
                                        style={styles.button_light_message}
                                        onPress={() => {
                                            this.FuncSetlightGroup();
                                        }}>
                                        <Text style={styles.text_top_light_message}>نور</Text>
                                        <Text style={styles.text_bottom_light_message}>سفید</Text>
                                    </TouchableOpacity>

                                    <TouchableOpacity
                                        name="Button_High_Priority_Announcement_Group"
                                        style={styles.button_high_priority_announcement_message}
                                        onPress={() => {
                                            this.FuncSwitchHighPriorityAnnouncementGroup();
                                        }}>
                                        <Switch
                                            isChecked={this.state.CheckHighPriorityAnnouncementGroup}
                                            onChange={() => {
                                                this.FuncSwitchHighPriorityAnnouncementGroup();
                                            }} />

                                        <Box>
                                            <Text style={styles.text_top_high_priority_announcement_message}>استفاده از اعلان های اولویت بالا</Text>
                                            <Text style={styles.text_bottom_high_priority_announcement_message}>نمایش پیش دید اعلان ها در بالای صفحه</Text>
                                        </Box>
                                    </TouchableOpacity>
                                </Box>

                                <Box name="Box_Calls" style={styles.box_calls}>
                                    <Text style={styles.text_header_calls}>تماس ها</Text>

                                    <TouchableOpacity name="Button_Bell_Calls" style={styles.button_bell_calls} onPress={() => {
                                        this.FuncSetBellCalls();
                                    }}>
                                        <Text style={styles.text_top_bell_calls}>زنگ</Text>
                                        <Text style={styles.text_bottom_bell_calls}>آهنگ زنگ پیش فرض (Skyline)</Text>
                                    </TouchableOpacity>

                                    <TouchableOpacity name="Button_Trembling_Calls" style={styles.button_trembling_calls} onPress={() => {
                                        this.FuncSetTremblingCalls();
                                    }}>
                                        <Text style={styles.text_top_trembling_calls}>لرزش</Text>
                                        <Text style={styles.text_bottom_trembling_calls}>پیش فرض</Text>
                                    </TouchableOpacity>
                                </Box>
                            </Box>
                        </ScrollView>
                        {/* End Section Content */}
                    </Box>
                </TouchableOpacity>
                {/* End Section App */}

                {/* Start Section Menu */}
                <Box name="Menu" style={styles.menu} left={this.state.PositionMenu}>
                    <TouchableOpacity onPress={() => {
                        this.FuncCloseMenu();
                        this.FuncSetDefaultSettingsAnnouncement();
                    }}>
                        <Box name="Menu_Item" style={styles.menu_item}>
                            <Text style={styles.text_menu_item}>تنظیم دوباره تنظیمات اعلان</Text>
                        </Box>
                    </TouchableOpacity>
                </Box>
                {/* End Section Menu */}
                {/* End Section App */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class