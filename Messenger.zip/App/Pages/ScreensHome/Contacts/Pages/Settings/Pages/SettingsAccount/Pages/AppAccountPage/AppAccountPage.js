﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity } from "react-native";
import { styles } from "./Css/CssAppAccountPage";
import { NativeBaseProvider, Box, Text } from "native-base";
import { AntDesign, MaterialIcons, Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class AppAccountPage extends React.Component {
    FuncGoToPageSettingsAccount = () => {
        this.props.navigation.goBack();
    };

    FuncGoToPageScreensSettingsPrivacy = () => {
        this.props.navigation.navigate("ScreensSettingsPrivacy");
    };

    FuncGoToPageSettingsSecurity = () => {
        this.props.navigation.navigate("SettingsSecurity");
    };

    FuncGoToPageSettingsTwoStepVerificationNumber = () => {
        this.props.navigation.navigate("SettingsTwoStepVerificationNumber");
    };

    FuncGoToPageSettingsChangeNumber = () => {
        this.props.navigation.navigate("SettingsChangeNumber");
    };

    FuncGoToPageSettingsRequestAccountInformation = () => {
        this.props.navigation.navigate("SettingsRequestAccountInformation");
    };

    FuncGoToPageSettingsDeleteAcount = () => {
        this.props.navigation.navigate("SettingsDeleteAcount");
    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <Box name="App" style={styles.app}>
                    {/* Start Section Header */}
                    <Box name="Header" style={styles.header}>
                        <Box />

                        <Box name="Box_Center_Header" style={styles.box_center_header} >
                            <Text style={styles.text_header}>حساب کاربری</Text>
                        </Box>

                        <TouchableOpacity
                            onPress={() => {
                                this.FuncGoToPageSettingsAccount();
                            }}
                            name="Box_Right_Header"
                            style={styles.button_back}>
                            <AntDesign name="arrowright" style={styles.icon_back} />
                        </TouchableOpacity>
                    </Box>
                    {/* End Section Header */}

                    {/* Start Section Content */}
                    <Box name="Content" style={styles.content}>
                        <TouchableOpacity
                            name="Box_Item_One"
                            style={styles.box_item}
                            onPress={() => {
                                this.FuncGoToPageScreensSettingsPrivacy();
                            }}>
                            <MaterialIcons name="lock" style={styles.icon_box_item} />

                            <Text style={styles.text_box_item}>حریم خصوصی</Text>
                        </TouchableOpacity>

                        <TouchableOpacity
                            name="Box_Item_Two"
                            style={styles.box_item}
                            onPress={() => {
                                this.FuncGoToPageSettingsSecurity();
                            }}>
                            <MaterialIcons name="security" style={styles.icon_box_item} />

                            <Text style={styles.text_box_item}>امنیت</Text>
                        </TouchableOpacity>

                        <TouchableOpacity
                            name="Box_Item_Two"
                            style={styles.box_item}
                            onPress={() => {
                                this.FuncGoToPageSettingsTwoStepVerificationNumber();
                            }}>
                            <MaterialCommunityIcons name="dots-horizontal-circle" style={styles.icon_box_item} />

                            <Text style={styles.text_box_item}>تایید شماره دو مرحله ای</Text>
                        </TouchableOpacity>

                        <TouchableOpacity
                            name="Box_Item_Two"
                            style={styles.box_item}
                            onPress={() => {
                                this.FuncGoToPageSettingsChangeNumber();
                            }}>
                            <Ionicons name="exit-outline" style={styles.icon_box_item} />

                            <Text style={styles.text_box_item}>تعغیر شماره</Text>
                        </TouchableOpacity>

                        <TouchableOpacity
                            name="Box_Item_Two"
                            style={styles.box_item}
                            onPress={() => {
                                this.FuncGoToPageSettingsRequestAccountInformation();
                            }}>
                            <Ionicons name="document-text" style={styles.icon_box_item} />

                            <Text style={styles.text_box_item}>درخواست اطلاعات حساب</Text>
                        </TouchableOpacity>

                        <TouchableOpacity
                            name="Box_Item_Two"
                            style={styles.box_item}
                            onPress={() => {
                                this.FuncGoToPageSettingsDeleteAcount();
                            }}>
                            <MaterialIcons name="delete" style={styles.icon_box_item} />

                            <Text style={styles.text_box_item}>حذف حساب من</Text>
                        </TouchableOpacity>
                    </Box>
                    {/* End Section Content */}
                </Box>
                {/* End Section App */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class