﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity } from "react-native";
import { styles } from "./Css/CssAppConversationPage";
import { NativeBaseProvider, Box, Text, Switch } from "native-base";
import { AntDesign, MaterialIcons, MaterialCommunityIcons } from "@expo/vector-icons";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class AppConversationPage extends React.Component {
    state = {
        CheckLoginForSend: false,
        CheckViewMedia: true,
        CheckConversationInArchive: true,
    };

    FuncGoToPageSettingsConversation = () => {
        this.props.navigation.goBack();
    };

    FuncSetThemeApp = () => {

    };

    FuncGoToPageSettingsWallpaper = () => {
        this.props.navigation.navigate("SettingsWallpaper");
    };

    FuncGoToPageSettingsConversationBackup = () => {
        this.props.navigation.navigate("SettingsConversationBackup");
    };

    FuncGoToPageSettingsConversationHistory = () => {
        this.props.navigation.navigate("SettingsConversationHistory");
    };

    FuncSetSizePen = () => {

    };

    FuncSwitchLoginForSend = () => {
        this.setState({
            CheckLoginForSend: !this.state.CheckLoginForSend,
        });
    };

    FuncSwitchViewMedia = () => {
        this.setState({
            CheckViewMedia: !this.state.CheckViewMedia,
        });
    };

    FuncSwitchConversationInArchive = () => {
        this.setState({
            CheckConversationInArchive: !this.state.CheckConversationInArchive,
        });
    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <Box name="App" style={styles.app}>
                    {/* Start Sectino Header*/}
                    <Box name="Header" style={styles.header}>
                        <Box />

                        <Box name="Box_Text_Header" style={styles.box_text_header}>
                            <Text style={styles.text_header}>گفتگوها</Text>
                        </Box>

                        <TouchableOpacity
                            name="Box_Icon_Header"
                            style={styles.box_icon_header}
                            onPress={() => {
                                this.FuncGoToPageSettingsConversation();
                            }}>
                            <AntDesign name="arrowright" style={styles.icon_back} />
                        </TouchableOpacity>
                    </Box>
                    {/* End Sectino Header*/}

                    {/* Start Sectino Content */}
                    <Box name="Content" style={styles.content}>
                        <Box name="Box_View" style={styles.box_view}>
                            <Text style={styles.text_header_view}>نمایش</Text>

                            <TouchableOpacity
                                name="Button_Theme_View"
                                style={styles.button_theme_view}
                                onPress={() => {
                                    this.FuncSetThemeApp();
                                }}>
                                <MaterialCommunityIcons name="theme-light-dark" style={styles.icon_theme_view} />

                                <Box>
                                    <Text style={styles.text_theme_view_top}>طرح زمینه</Text>

                                    <Text style={styles.text_theme_view_bottom}>روشن</Text>
                                </Box>
                            </TouchableOpacity>

                            <TouchableOpacity
                                name="Button_Wallpaper_View"
                                style={styles.button_wallpaper_view}
                                onPress={() => {
                                    this.FuncGoToPageSettingsWallpaper();
                                }}>
                                <MaterialIcons name="now-wallpaper" style={styles.icon_wallpaper_view} />

                                <Text style={styles.text_wallpaper_view}>کاغذ دیواری</Text>
                            </TouchableOpacity>
                        </Box>

                        <Box name="Box_Settings_Conversation" style={styles.box_settings_conversation}>
                            <Text style={styles.text_settings_conversation}>تنظیمات گفتگو</Text>

                            <TouchableOpacity
                                name="Button_Login_For_Send"
                                style={styles.button_login_for_send}
                                onPress={() => {
                                    this.FuncSwitchLoginForSend();
                                }}>
                                <Switch
                                    isChecked={this.state.CheckLoginForSend}
                                    onChange={() => {
                                        this.FuncSwitchLoginForSend();
                                    }} />

                                <Box>
                                    <Text style={styles.text_top_login_for_send}>کلید "ورود" برای ارسال</Text>

                                    <Text style={styles.text_bottom_login_for_send}>زدن کلید "ورود" برای ارسال پیام شماست</Text>
                                </Box>
                            </TouchableOpacity>

                            <TouchableOpacity
                                name="Button_Settings_View_Media"
                                style={styles.button_settings_view_media}
                                onPress={() => {
                                    this.FuncSwitchViewMedia();
                                }}>
                                <Switch
                                    isChecked={this.state.CheckViewMedia}
                                    onChange={() => {
                                        this.FuncSwitchViewMedia();
                                    }} />

                                <Box>
                                    <Text style={styles.text_top_settings_view_media}>قابلیت دید رسانه</Text>

                                    <Text style={styles.text_bottom_settings_view_media}>نمایش رسانه های تازه دانلود شده در گالری گوشی</Text>
                                </Box>
                            </TouchableOpacity>

                            <TouchableOpacity
                                name="Button_Size_Pen"
                                style={styles.button_size_pen}
                                onPress={() => {
                                    this.FuncSetSizePen();
                                }}>
                                <Text style={styles.text_top_size_pen}>اندازه قلم</Text>

                                <Text style={styles.text_bottom_size_pen}>متوسط</Text>
                            </TouchableOpacity>
                        </Box>

                        <Box name="Box_Contacts_Archive" style={styles.box_contacts_archive}>
                            <Text style={styles.text_header_contacts_archive}>گفتگوهای بایگانی شده</Text>

                            <TouchableOpacity
                                name="Button_Save_Conversation_In_Archive"
                                style={styles.button_save_conversation_in_archive}
                                onPress={() => {
                                    this.FuncSwitchConversationInArchive();
                                }}>
                                <Switch
                                    isChecked={this.state.CheckConversationInArchive}
                                    onChange={() => {
                                        this.FuncSwitchConversationInArchive();
                                    }} />

                                <Box>
                                    <Text style={styles.text_top_save_conversation_in_archive}>نگه داشتن گفتگوها در بایگانی</Text>

                                    <Text style={styles.text_bottom_save_conversation_in_archive}>
                                        وقتی پیام جدیدی دریافت کنید, گفتگوهای بایگانی شده همچنان در بایگانی باقی میمانند
                                    </Text>
                                </Box>
                            </TouchableOpacity>
                        </Box>

                        <TouchableOpacity
                            name="Button_Backup_Conversation"
                            style={styles.button_backup_conversation}
                            onPress={() => {
                                this.FuncGoToPageSettingsConversationBackup();
                            }}>
                            <MaterialIcons name="backup" style={styles.icon_backup_conversation} />

                            <Text style={styles.text_backup_conversation}>پشتیبان گیری گفتگو</Text>
                        </TouchableOpacity>

                        <TouchableOpacity
                            name="Button_History_Conversation"
                            style={styles.button_history_conversation}
                            onPress={() => {
                                this.FuncGoToPageSettingsConversationHistory();
                            }}>
                            <MaterialIcons name="history" style={styles.icon_history_conversation} />

                            <Text style={styles.text_history_conversation}>تاریخچه گفتگو</Text>
                        </TouchableOpacity>
                    </Box>
                    {/* End Sectino Content */}
                </Box>
                {/* End Section App */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class