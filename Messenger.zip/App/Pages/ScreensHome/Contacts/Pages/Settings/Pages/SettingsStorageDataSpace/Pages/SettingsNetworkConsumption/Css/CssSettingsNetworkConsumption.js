/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import { StyleSheet } from "react-native";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Style
const styles = StyleSheet.create({
    //////////////////////////////// Start Style App
    app: {
        width: "100%",
        height: "100%",
    },
    //////////////////////////////// End Style App

    //////////////////////////////// Start Style Header
    header: {
        width: "100%",
        height: "8%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "flex-end",
        backgroundColor: "#072",
    },

    box_text_header: {
        width: "90%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 30,
    },

    text_header: {
        color: "#eee",
        fontSize: 18,
    },

    box_icon_header: {
        width: "10%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 20,
    },

    icon_back: {
        color: "#eee",
        fontSize: 22,
    },
    //////////////////////////////// End Style Header

    //////////////////////////////// Start Style Content
    content: {
        width: "100%",
        height: "92%",
    },

    box_consumption: {
        width: "100%",
        height: 50,
        marginTop: 20,
        marginBottom: 10,
        marginLeft: 70,
    },

    text_top_consumption: {
        color: "#222",
        fontSize: 15,
    },

    text_bottom_consumption: {
        color: "#666",
        fontSize: 12,
    },

    box_consumption_kilobytes: {
        width: "100%",
        height: 30,
        marginLeft: 70,
    },

    text_consumption_kilobytes: {
        color: "#555",
        fontSize: 18,
    },

    box_receive_and_send: {
        width: "100%",
        height: 90,
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "flex-end",
        marginRight: 70,
        borderBottomColor: "#ddd",
        borderBottomWidth: 1,
    },

    box_receive: {
        width: "42%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
    },

    text_top_receive: {
        color: "#666",
        fontSize: 16,
    },

    text_bottom_receive: {
        color: "#333",
        fontSize: 15,
        fontWeight: "bold",
    },

    box_send: {
        width: "42%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
    },

    text_top_send: {
        color: "#666",
        fontSize: 16,
    },

    text_bottom_send: {
        color: "#333",
        fontSize: 15,
        fontWeight: "bold",
    },

    box_consumption_chart: {
        width: "100%",
        height: 470,
        borderBottomColor: "#ddd",
        borderBottomWidth: 1,
        marginBottom: 10,
    },

    box_item_consumption_chart: {
        width: "100%",
        height: 75,
    },

    box_top_item_consumption_chart: {
        width: "100%",
        height: "50%",
        flexDirection: "row-reverse",
        justifyContent: "flex-end",
        alignItems: "center",
    },

    box_receive_top_item_consumption_chart: {
        width: "20%",
        height: "100%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "center",
    },

    text_receive_top_item_consumption_chart: {
        color: "#666",
        fontSize: 14,
    },

    icon_arrow_down: {
        color: "#444",
        fontSize: 14,
    },

    box_send_top_item_consumption_chart: {
        width: "20%",
        height: "100%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "center",
        marginRight: "30%",
    },

    text_send_top_item_consumption_chart: {
        color: "#666",
        fontSize: 14,
    },

    icon_up_down: {
        color: "#444",
        fontSize: 14,
    },

    text_call_top_item_consumption_chart: {
        color: "#222",
        fontSize: 16,
        paddingRight: 25,
    },

    icon_item_consumption_chart: {
        color: "#666",
        fontSize: 20,
        paddingRight: 25,
    },

    box_bottom_item_consumption_chart: {
        width: "100%",
        height: "50%",
        alignItems: "flex-start",
        justifyContent: "center",
    },

    box_Progress: {
        width: "80%",
        height: "10%",
        backgroundColor: "#aaaaaa44",
        marginLeft: 70,
    },

    box_progress_inner: {
        width: "50%",
        height: "100%",
        backgroundColor: "#082",
    },

    box_text_bottom_item_consumption_chart: {
        width: "100%",
        height: "90%",
        flexDirection: "row",
        marginLeft: 70,
        alignItems: "center",
    },

    text_exit: {
        color: "#666",
        fontSize: 12,
    },

    text_entrance: {
        color: "#666",
        fontSize: 12,
    },

    button_reset_statistics: {
        width: "100%",
        height: 100,
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 70,
    },

    text_top_reset_statistics: {
        color: "#222",
        fontSize: 16,
    },

    text_bottom_reset_statistics: {
        color: "#666",
        fontSize: 14,
    },
    //////////////////////////////// End Style Content
});
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Style
export { styles };