﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { styles } from "./Css/CssSettingsProgramInformation";
import { NativeBaseProvider, Box, Image, Text, Link } from "native-base";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class SettingsProgramInformation extends React.Component {
    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <Box name="App" style={styles.app}>
                    <Box name="Content" style={styles.content}>
                        <Text style={styles.text_one_ontent}>پیام رسان</Text>
                        <Text style={styles.text_two_ontent}>نسخه 1.0.0</Text>

                        <Image alt="Image Logo" source={require("./../../../../../../../../../Assets/Images/icon.png")} style={styles.image_logo_app} />

                        <Text style={styles.text_three_content}>
                            <Link href="https://google.com">مجوزها</Link>
                        </Text>
                    </Box>
                </Box>
                {/* End Section App */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class