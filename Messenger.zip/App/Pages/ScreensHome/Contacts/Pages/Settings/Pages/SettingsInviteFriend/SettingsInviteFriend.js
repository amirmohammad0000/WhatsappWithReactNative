﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity } from "react-native";
import { styles } from "./Css/CssSettingsInviteFriend";
import { NativeBaseProvider, Box, Text } from "native-base";
import { AntDesign, Ionicons } from "@expo/vector-icons";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class SettingsInviteFriend extends React.Component {
    state = {
        Contacts: "",
    };

    FuncGoToPageAppSettingsPage = () => {
        this.props.navigation.goBack();
    };

    FuncInviteFriend = () => {

    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <Box name="App" style={styles.app}>
                    {/* Start Section Header */}
                    <Box name="Header" style={styles.header}>
                        <Box />

                        <Box name="Box_Center_Header" style={styles.box_center_header} >
                            <Text style={styles.text_header}>دعوت یک دوست</Text>
                        </Box>

                        <TouchableOpacity
                            onPress={() => {
                                this.FuncGoToPageAppSettingsPage();
                            }}
                            name="Box_Right_Header"
                            style={styles.button_back}>
                            <AntDesign name="arrowright" style={styles.icon_back} />
                        </TouchableOpacity>
                    </Box>
                    {/* End Section Header */}

                    {/* Start Section Content */}
                    <Box name="Content" style={styles.content}>
                        <TouchableOpacity
                            name="Box_Invite_Friend"
                            style={styles.button_invite_friend}
                            onPress={() => {
                                this.FuncInviteFriend();
                            }}>
                            <Ionicons name="share-social" style={styles.icon_invite_friend} />

                            <Text style={styles.text_invite_friend}>اشتراک گذاری پیوند</Text>
                        </TouchableOpacity>

                        <Box name="Box_Contacts" style={styles.box_contacts}>
                            <Text style={styles.text_from_contacts}>From Contacts</Text>

                            {
                                this.state.Contacts !== "" ?
                                    <Box name="Box_Contacts_Center_Page" style={styles.box_contacts_center_page}>

                                    </Box>
                                    :
                                    <Box name="Box_Contacts_Center_Page" style={styles.box_contacts_center_page}>
                                        <Text style={styles.text_contacts_center_page}>مخاطبی موجود نیست</Text>
                                    </Box>
                            }
                        </Box>
                    </Box>
                    {/* End Section Content */}
                </Box>
                {/* End Section App */}
            </NativeBaseProvider >
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class