﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity } from "react-native";
import { styles } from "./Css/CssAppSettingsPage";
import { NativeBaseProvider, Box, Text, Image } from "native-base";
import { AntDesign, FontAwesome5, FontAwesome, Ionicons, MaterialIcons, Feather } from "@expo/vector-icons";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class AppSettingsPage extends React.Component {
    state = {
        ImageProfileUser: require("./../../../../../../../Assets/Images/ImageSingleProfile.png"),
        NameUser: "AmirMohammad",
        BioUser: ".",
    };

    FuncGoToPageContacts = () => {
        this.props.navigation.goBack();
    };

    FuncSetQRCode = () => {

    };

    FuncGoToPageScreensSettingsProfile = () => {
        this.props.navigation.navigate("ScreensSettingsProfile");
    };

    FuncGoToPageScreensSettingsAccount = () => {
        this.props.navigation.navigate("ScreensSettingsAccount");
    };

    FuncGoToPageScreensSettingsConversation = () => {
        this.props.navigation.navigate("ScreensSettingsConversation");
    };

    FuncGoToPageSettingsAnnouncement = () => {
        this.props.navigation.navigate("SettingsAnnouncement");
    };

    FuncGoToPageScreensSettingsStorageDataSpace = () => {
        this.props.navigation.navigate("ScreensSettingsStorageDataSpace");
    };

    FuncGoToPageScreensSettingsHelp = () => {
        this.props.navigation.navigate("ScreensSettingsHelp");
    };

    FuncGoToPageSettingsInviteFriend = () => {
        this.props.navigation.navigate("SettingsInviteFriend");
    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <Box name="App" style={styles.app}>
                    {/* Start Sectino Header*/}
                    <Box name="Header" style={styles.header}>
                        <Box />

                        <Box name="Box_Text_Header" style={styles.box_text_header}>
                            <Text style={styles.text_header}>تنظیمات</Text>
                        </Box>

                        <TouchableOpacity
                            name="Box_Icon_Header"
                            style={styles.box_icon_header}
                            onPress={() => {
                                this.FuncGoToPageContacts();
                            }}>
                            <AntDesign name="arrowright" style={styles.icon_back} />
                        </TouchableOpacity>
                    </Box>
                    {/* End Sectino Header*/}

                    {/* Start Sectino Content */}
                    <Box name="Content" style={styles.content}>
                        <TouchableOpacity
                            name="Box_Profile"
                            style={styles.box_profile}
                            onPress={() => {
                                this.FuncGoToPageScreensSettingsProfile();
                            }}>
                            <Box name="Box_Image_Profile" style={styles.box_image_profile}>
                                <Image alt="Image Profile" source={this.state.ImageProfileUser} style={styles.image_profile_user} />
                            </Box>

                            <Box name="Box_Text_Profile" style={styles.box_text_profile}>
                                <Text style={styles.text_name_user}>{this.state.NameUser}</Text>

                                <Text style={styles.text_bio_user}>{this.state.BioUser}</Text>
                            </Box>

                            <TouchableOpacity
                                name="Box_QR_Code"
                                style={styles.box_qr_code}
                                onPress={() => {
                                    this.FuncSetQRCode();
                                }}>
                                <Ionicons name="md-qr-code-sharp" style={styles.icon_qr_code} />
                            </TouchableOpacity>
                        </TouchableOpacity>

                        <TouchableOpacity
                            name="Box_Account"
                            style={styles.box_settings}
                            onPress={() => {
                                this.FuncGoToPageScreensSettingsAccount();
                            }}>
                            <FontAwesome5 name="key" style={styles.icon_box_settings} />

                            <Box name="Box_Text_Settings" style={styles.box_text_settings}>
                                <Text style={styles.text_box_top_settings}>حساب کاربری</Text>

                                <Text style={styles.text_box_bottom_settings}>حریم خصوصی, امنیت, تعغیر شماره</Text>
                            </Box>
                        </TouchableOpacity>

                        <TouchableOpacity
                            name="Box_Conversation"
                            style={styles.box_settings}
                            onPress={() => {
                                this.FuncGoToPageScreensSettingsConversation();
                            }}>
                            <MaterialIcons name="chat" style={styles.icon_box_settings} />

                            <Box name="Box_Text_Settings" style={styles.box_text_settings}>
                                <Text style={styles.text_box_top_settings}>گفتگوها</Text>

                                <Text style={styles.text_box_bottom_settings}>طرح زمینه, کاغذ دیواری, تاریخچه گفتگو</Text>
                            </Box>
                        </TouchableOpacity>

                        <TouchableOpacity
                            name="Box_Announcement"
                            style={styles.box_settings}
                            onPress={() => {
                                this.FuncGoToPageSettingsAnnouncement();
                            }}>
                            <FontAwesome name="bell" style={styles.icon_box_settings} />

                            <Box name="Box_Text_Settings" style={styles.box_text_settings}>
                                <Text style={styles.text_box_top_settings}>اعلان</Text>

                                <Text style={styles.text_box_bottom_settings}>زنگ تماس, گروه و پیام ها</Text>
                            </Box>
                        </TouchableOpacity>

                        <TouchableOpacity
                            name="Box_Storage_Data_Space"
                            style={styles.box_settings}
                            onPress={() => {
                                this.FuncGoToPageScreensSettingsStorageDataSpace();
                            }}>
                            <MaterialIcons name="data-usage" style={styles.icon_box_settings} />

                            <Box name="Box_Text_Settings" style={styles.box_text_settings}>
                                <Text style={styles.text_box_top_settings}>فضای ذخیره سازی و داده</Text>

                                <Text style={styles.text_box_bottom_settings}>مصرف شبکه, دانلود خودکار</Text>
                            </Box>
                        </TouchableOpacity>

                        <TouchableOpacity
                            name="Box_Help"
                            style={styles.box_settings}
                            onPress={() => {
                                this.FuncGoToPageScreensSettingsHelp();
                            }}>
                            <Feather name="help-circle" style={styles.icon_box_settings} />

                            <Box name="Box_Text_Settings" style={styles.box_text_settings}>
                                <Text style={styles.text_box_top_settings}>راهنمایی</Text>

                                <Text style={styles.text_box_bottom_settings}>بخش راهنما, تماس با ما, شیوه نامه حریم خصوصی</Text>
                            </Box>
                        </TouchableOpacity>

                        <TouchableOpacity
                            name="Box_Invite_Friend"
                            style={styles.box_invite_friend}
                            onPress={() => {
                                this.FuncGoToPageSettingsInviteFriend();
                            }}>
                            <FontAwesome5 name="user-friends" style={styles.icon_invite_friend} />

                            <Text style={styles.text_invite_friend}>دعوت یک دوست</Text>
                        </TouchableOpacity>
                    </Box>
                    {/* End Sectino Content */}
                </Box>
                {/* End Section App */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class