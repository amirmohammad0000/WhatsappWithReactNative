﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity } from "react-native";
import { styles } from "./Css/CssSettingsAudienceBlocked";
import { NativeBaseProvider, Box, Image, Text } from "native-base";
import { AntDesign, Ionicons } from "@expo/vector-icons";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class SettingsAudienceBlocked extends React.Component {
    FuncSetAddContacts = () => {

    };

    FuncGoToPageSettingsPrivacy = () => {
        this.props.navigation.goBack();
    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <Box name="App" style={styles.app}>
                    {/* Start Section Header */}
                    <Box name="Header" style={styles.header}>
                        <TouchableOpacity
                            name="Box_Left_Header"
                            style={styles.box_left_header}
                            onPress={() => {
                                this.FuncSetAddContacts();
                            }}>
                            <Ionicons name="ios-person-add-sharp" style={styles.icon_add_contacts} />
                        </TouchableOpacity>

                        <Box name="Box_Center_Header" style={styles.box_center_header} >
                            <Text style={styles.text_header}>مخاطبان مسدود شده</Text>
                        </Box>

                        <TouchableOpacity
                            onPress={() => {
                                this.FuncGoToPageSettingsPrivacy();
                            }}
                            name="Box_Right_Header"
                            style={styles.button_back}>
                            <AntDesign name="arrowright" style={styles.icon_back} />
                        </TouchableOpacity>
                    </Box>
                    {/* End Section Header */}

                    {/* Start Section Content */}
                    <Box name="Content" style={styles.content}>
                        <Box name="Box_Image" style={styles.box_image}>
                            <Image alt="Image Audience Blocked" source={require("./../../../../../../../../../../../Assets/Images/ImageContactsAudienceBlocked.png")} style={styles.image_audience_blocked} />
                        </Box>

                        <Box name="Box_Text" style={styles.box_text}>
                            <Text style={styles.text_one}>هیچ مخاطبی مسدود نیست</Text>

                            <Text style={styles.text_two}>روی ایکون بالا بزنید تا مخاطبی را برای مسدود کردن انتخاب کنید.</Text>
                        </Box>

                        <Box name="Box_Footer" style={styles.box_footer}>
                            <Text style={styles.text_footer}>مخاطبان مسدود شده دیگر نمیتوانند با شما تماس بگیرند یا به شما پیام بفرستند.</Text>
                        </Box>
                    </Box>
                    {/* End Section Content */}
                </Box>
                {/* End Section App */}
            </NativeBaseProvider >
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class