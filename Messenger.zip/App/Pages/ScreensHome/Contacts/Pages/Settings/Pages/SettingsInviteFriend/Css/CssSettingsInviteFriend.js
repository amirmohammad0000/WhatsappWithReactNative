/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import { StyleSheet } from "react-native";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Style
const styles = StyleSheet.create({
    //////////////////////////////// Start Style App
    app: {
        width: "100%",
        height: "100%",
    },
    //////////////////////////////// End Style App

    //////////////////////////////// Start Style Header
    header: {
        width: "100%",
        height: "8%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "flex-end",
        backgroundColor: "#072",
    },

    box_center_header: {
        width: "90%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 30,
    },

    text_header: {
        color: "#eee",
        fontSize: 20,
    },

    button_back: {
        width: "10%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    icon_back: {
        color: "#eee",
        fontSize: 22,
    },
    //////////////////////////////// End Style Header

    //////////////////////////////// End Style Content
    content: {
        width: "100%",
        height: "92%",
    },

    button_invite_friend: {
        width: "100%",
        height: "9%",
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "flex-start",
    },

    icon_invite_friend: {
        color: "#eee",
        fontSize: 20,
        backgroundColor: "#285",
        padding: 10,
        borderRadius: 1000,
        marginLeft: 15,
    },

    text_invite_friend: {
        color: "#000",
        fontWeight: "bold",
        fontSize: 16,
        marginLeft: 15,
    },

    box_contacts: {
        width: "100%",
        height: "91%",
    },

    text_from_contacts: {
        color: "#888",
        fontSize: 14,
        textAlign: "left",
    },

    box_contacts_center_page: {
        width: "100%",
        height: "100%",
    },

    text_contacts_center_page: {
        color: "#888",
        fontSize: 15,
        textAlign: "center",
        padding: 80,
    },
    //////////////////////////////// End Style Content
});
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Style
export { styles };