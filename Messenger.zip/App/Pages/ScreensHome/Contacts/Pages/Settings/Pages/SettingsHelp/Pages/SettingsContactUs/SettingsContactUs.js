﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity } from "react-native";
import { styles } from "./Css/CssSettingsContactUs";
import { NativeBaseProvider, Box, Text, TextArea } from "native-base";
import { AntDesign } from "@expo/vector-icons";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class SettingsContactUs extends React.Component {
    FuncGoToPageSettingsHelp = () => {
        this.props.navigation.goBack();
    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <Box name="App" style={styles.app}>
                    {/* Start Sectino Header*/}
                    <Box name="Header" style={styles.header}>
                        <Box />

                        <Box name="Box_Text_Header" style={styles.box_text_header}>
                            <Text style={styles.text_header}>تماس با ما</Text>
                        </Box>

                        <TouchableOpacity
                            name="Box_Icon_Header"
                            style={styles.box_icon_header}
                            onPress={() => {
                                this.FuncGoToPageSettingsHelp();
                            }}>
                            <AntDesign name="arrowright" style={styles.icon_back} />
                        </TouchableOpacity>
                    </Box>
                    {/* End Sectino Header*/}

                    {/* Start Sectino Content */}
                    <Box name="Content" style={styles.content}>
                        <Box name="Box_Text_Area" style={styles.box_text_area}>
                            <TextArea width="90%" height="80%" backgroundColor="#99999922" borderBottomColor="#444" placeholder="مشکل خود را شرح دهید" variant="underlined" />
                        </Box>

                        <Box name="Box_Add_Image" style={styles.box_add_image}>
                            <Text style={styles.text_add_image}>افزودن عکس از صفحه (اختیاری)</Text>

                            <Box name="Box_Add_Image_Inner" style={styles.box_add_image_inner}>
                                <TouchableOpacity style={styles.button_add_image_inner}>
                                    <AntDesign name="pluscircle" style={styles.icon_add_image_inner} />
                                </TouchableOpacity>

                                <TouchableOpacity style={styles.button_add_image_inner}>
                                    <AntDesign name="pluscircle" style={styles.icon_add_image_inner} />
                                </TouchableOpacity>

                                <TouchableOpacity style={styles.button_add_image_inner}>
                                    <AntDesign name="pluscircle" style={styles.icon_add_image_inner} />
                                </TouchableOpacity>
                            </Box>
                        </Box>
                    </Box>
                    {/* Start Sectino Content */}

                    {/* Start Sectino Footer */}
                    <Box name="Box_Footer" style={styles.box_footer}>
                        <TouchableOpacity style={styles.button_next_footer}>
                            <Text style={styles.text_next_footer}>بعدی</Text>
                        </TouchableOpacity>

                        <Text style={styles.text_footer}>بخش راهنمای ما را بازدید کنید</Text>
                    </Box>
                    {/* End Sectino Footer */}
                </Box>
                {/* End Section App */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class