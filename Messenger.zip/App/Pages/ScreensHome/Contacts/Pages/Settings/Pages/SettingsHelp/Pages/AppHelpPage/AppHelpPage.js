﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity } from "react-native";
import { styles } from "./Css/CssAppHelpPage";
import { NativeBaseProvider, Box, Link, Text } from "native-base";
import { Feather, AntDesign, Ionicons, FontAwesome5 } from "@expo/vector-icons";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class AppHelpPage extends React.Component {
    FuncGoToPageSettingsHelp = () => {
        this.props.navigation.goBack();
    };

    FuncGoToPageSettingsContactUs = () => {
        this.props.navigation.navigate("SettingsContactUs");
    };

    FuncGoToPageSettingsProgramInformation = () => {
        this.props.navigation.navigate("SettingsProgramInformation");
    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <Box name="App" style={styles.app}>
                    {/* Start Section Header */}
                    <Box name="Header" style={styles.header}>
                        <Box />

                        <Box name="Box_Center_Header" style={styles.box_center_header} >
                            <Text style={styles.text_header}>راهنمایی</Text>
                        </Box>

                        <TouchableOpacity
                            onPress={() => {
                                this.FuncGoToPageSettingsHelp();
                            }}
                            name="Box_Right_Header"
                            style={styles.button_back}>
                            <AntDesign name="arrowright" style={styles.icon_back} />
                        </TouchableOpacity>
                    </Box>
                    {/* End Section Header */}

                    {/* Start Section Content */}
                    <Box name="Content" style={styles.content}>
                        <TouchableOpacity name="Box_Item_One" style={styles.box_item}>
                            <Link href="https://google.com">
                                <Feather name="help-circle" style={styles.icon_box_item} />

                                <Text style={styles.text_box_item}>بخش راهنما</Text>
                            </Link>
                        </TouchableOpacity>

                        <TouchableOpacity
                            name="Box_Item_Two"
                            style={styles.box_item_two}
                            onPress={() => {
                                this.FuncGoToPageSettingsContactUs();
                            }}>
                            <FontAwesome5 name="user-friends" style={styles.icon_box_item_two} />

                            <Box>
                                <Text style={styles.text_box_item_two}>تماس با ما</Text>

                                <Text style={styles.text_bottom_box_item_two}>پرسشی دارید؟کمکی میخواهید؟</Text>
                            </Box>
                        </TouchableOpacity>

                        <TouchableOpacity name="Box_Item_Three" style={styles.box_item}>
                            <Link href="https://google.com">
                                <Ionicons name="document-text-sharp" style={styles.icon_box_item} />

                                <Text style={styles.text_box_item}>شرایط و شیوه نامه حریم خصوصی</Text>
                            </Link>
                        </TouchableOpacity>

                        <TouchableOpacity
                            name="Box_Item_Four"
                            style={styles.box_item}
                            onPress={() => {
                                this.FuncGoToPageSettingsProgramInformation();
                            }}>
                            <Feather name="alert-circle" style={styles.icon_box_item} />

                            <Text style={styles.text_box_item}>اطلاعات برنامه</Text>
                        </TouchableOpacity>
                    </Box>
                    {/* End Section Content */}
                </Box>
                {/* End Section App */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class