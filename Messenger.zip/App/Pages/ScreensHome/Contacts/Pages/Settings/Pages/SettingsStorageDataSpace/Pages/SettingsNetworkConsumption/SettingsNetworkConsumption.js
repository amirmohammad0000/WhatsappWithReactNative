﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity, ScrollView } from "react-native";
import { styles } from "./Css/CssSettingsNetworkConsumption";
import { NativeBaseProvider, Box, Text } from "native-base";
import { AntDesign, Ionicons, MaterialIcons, Entypo, FontAwesome5 } from "@expo/vector-icons";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class SettingsNetworkConsumption extends React.Component {
    FuncGoToPageSettingsStorageDataSpace = () => {
        this.props.navigation.goBack();
    };

    FuncResetStatistics = () => {

    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <Box name="App" style={styles.app}>
                    {/* Start Sectino Header*/}
                    <Box name="Header" style={styles.header}>
                        <Box />

                        <Box name="Box_Text_Header" style={styles.box_text_header}>
                            <Text style={styles.text_header}>مصرف شبکه</Text>
                        </Box>

                        <TouchableOpacity
                            name="Box_Icon_Header"
                            style={styles.box_icon_header}
                            onPress={() => {
                                this.FuncGoToPageSettingsStorageDataSpace();
                            }}>
                            <AntDesign name="arrowright" style={styles.icon_back} />
                        </TouchableOpacity>
                    </Box>
                    {/* End Sectino Header*/}

                    {/* Start Sectino Content */}
                    <ScrollView>
                        <Box name="Content" style={styles.content}>
                            <Box name="Box_Consumption" style={styles.box_consumption}>
                                <Text style={styles.text_top_consumption}>میزان مصرف</Text>

                                <Text style={styles.text_bottom_consumption}>از "2021/10/28"</Text>
                            </Box>

                            <Box name="Box_Consumption_Kilobytes" style={styles.box_consumption_kilobytes}>
                                <Text style={styles.text_consumption_kilobytes}>0 کیلوبایت</Text>
                            </Box>

                            <Box name="Box_Receive_And_Send" style={styles.box_receive_and_send}>
                                <Box name="Box_Receive" style={styles.box_receive}>
                                    <Text style={styles.text_top_receive}>دریافت شده</Text>

                                    <Text style={styles.text_bottom_receive}>0 کیلوبایت</Text>
                                </Box>

                                <Box name="Box_Send" style={styles.box_send}>
                                    <Text style={styles.text_top_send}>ارسال شده</Text>

                                    <Text style={styles.text_bottom_send}>0 کیلوبایت</Text>
                                </Box>
                            </Box>

                            <Box name="Box_Consumption_Chart" style={styles.box_consumption_chart}>
                                <Box name="Box_Item_Consumption_Chart" style={styles.box_item_consumption_chart}>
                                    <Box name="Box_Top_Item_Consumption_Chart" style={styles.box_top_item_consumption_chart}>
                                        <Box name="Box_Receive_Top_Item_Consumption_Chart" style={styles.box_receive_top_item_consumption_chart}>
                                            <Text style={styles.text_receive_top_item_consumption_chart}>0 کیلوبایت</Text>

                                            <AntDesign name="arrowdown" style={styles.icon_arrow_down} />
                                        </Box>

                                        <Box name="Box_Send_Top_Item_Consumption_Chart" style={styles.box_send_top_item_consumption_chart}>
                                            <Text style={styles.text_send_top_item_consumption_chart}>0 کیلوبایت</Text>

                                            <AntDesign name="arrowup" style={styles.icon_up_down} />
                                        </Box>

                                        <Text style={styles.text_call_top_item_consumption_chart}>تماس ها</Text>

                                        <Ionicons name="call" style={styles.icon_item_consumption_chart} />
                                    </Box>

                                    <Box name="Box_Top_Item_Consumption_Chart" style={styles.box_bottom_item_consumption_chart}>
                                        <Box name="Box_Progress" style={styles.box_Progress}>
                                            <Box name="Box_Progress_Inner" style={styles.box_progress_inner} />
                                        </Box>

                                        <Box name="Box_Text_Bottom_Item_Consumption_Chart" style={styles.box_text_bottom_item_consumption_chart}>
                                            <Text style={styles.text_exit}>0 خروجی</Text>
                                            --
                                            <Text style={styles.text_entrance}>0 ورودی</Text>
                                        </Box>
                                    </Box>
                                </Box>

                                <Box name="Box_Item_Consumption_Chart" style={styles.box_item_consumption_chart}>
                                    <Box name="Box_Top_Item_Consumption_Chart" style={styles.box_top_item_consumption_chart}>
                                        <Box name="Box_Receive_Top_Item_Consumption_Chart" style={styles.box_receive_top_item_consumption_chart}>
                                            <Text style={styles.text_receive_top_item_consumption_chart}>0 کیلوبایت</Text>

                                            <AntDesign name="arrowdown" style={styles.icon_arrow_down} />
                                        </Box>

                                        <Box name="Box_Send_Top_Item_Consumption_Chart" style={styles.box_send_top_item_consumption_chart}>
                                            <Text style={styles.text_send_top_item_consumption_chart}>0 کیلوبایت</Text>

                                            <AntDesign name="arrowup" style={styles.icon_up_down} />
                                        </Box>

                                        <Text style={styles.text_call_top_item_consumption_chart}>رسانه ها</Text>

                                        <MaterialIcons name="perm-media" style={styles.icon_item_consumption_chart} />
                                    </Box>

                                    <Box name="Box_Top_Item_Consumption_Chart" style={styles.box_bottom_item_consumption_chart}>
                                        <Box name="Box_Progress" style={styles.box_Progress}>
                                            <Box name="Box_Progress_Inner" style={styles.box_progress_inner} />
                                        </Box>
                                    </Box>
                                </Box>

                                <Box name="Box_Item_Consumption_Chart" style={styles.box_item_consumption_chart}>
                                    <Box name="Box_Top_Item_Consumption_Chart" style={styles.box_top_item_consumption_chart}>
                                        <Box name="Box_Receive_Top_Item_Consumption_Chart" style={styles.box_receive_top_item_consumption_chart}>
                                            <Text style={styles.text_receive_top_item_consumption_chart}>0 کیلوبایت</Text>

                                            <AntDesign name="arrowdown" style={styles.icon_arrow_down} />
                                        </Box>

                                        <Box name="Box_Send_Top_Item_Consumption_Chart" style={styles.box_send_top_item_consumption_chart}>
                                            <Text style={styles.text_send_top_item_consumption_chart}>0 کیلوبایت</Text>

                                            <AntDesign name="arrowup" style={styles.icon_up_down} />
                                        </Box>

                                        <Text style={styles.text_call_top_item_consumption_chart}>گوگل درایو</Text>

                                        <FontAwesome5 name="google-drive" style={styles.icon_item_consumption_chart} />
                                    </Box>

                                    <Box name="Box_Top_Item_Consumption_Chart" style={styles.box_bottom_item_consumption_chart}>
                                        <Box name="Box_Progress" style={styles.box_Progress}>
                                            <Box name="Box_Progress_Inner" style={styles.box_progress_inner} />
                                        </Box>
                                    </Box>
                                </Box>

                                <Box name="Box_Item_Consumption_Chart" style={styles.box_item_consumption_chart}>
                                    <Box name="Box_Top_Item_Consumption_Chart" style={styles.box_top_item_consumption_chart}>
                                        <Box name="Box_Receive_Top_Item_Consumption_Chart" style={styles.box_receive_top_item_consumption_chart}>
                                            <Text style={styles.text_receive_top_item_consumption_chart}>0 کیلوبایت</Text>

                                            <AntDesign name="arrowdown" style={styles.icon_arrow_down} />
                                        </Box>

                                        <Box name="Box_Send_Top_Item_Consumption_Chart" style={styles.box_send_top_item_consumption_chart}>
                                            <Text style={styles.text_send_top_item_consumption_chart}>0 کیلوبایت</Text>

                                            <AntDesign name="arrowup" style={styles.icon_up_down} />
                                        </Box>

                                        <Text style={styles.text_call_top_item_consumption_chart}>پیام ها</Text>

                                        <MaterialIcons name="chat" style={styles.icon_item_consumption_chart} />
                                    </Box>

                                    <Box name="Box_Top_Item_Consumption_Chart" style={styles.box_bottom_item_consumption_chart}>
                                        <Box name="Box_Progress" style={styles.box_Progress}>
                                            <Box name="Box_Progress_Inner" style={styles.box_progress_inner} />
                                        </Box>

                                        <Box name="Box_Text_Bottom_Item_Consumption_Chart" style={styles.box_text_bottom_item_consumption_chart}>
                                            <Text style={styles.text_exit}>0 ارسال شده</Text>
                                            --
                                            <Text style={styles.text_entrance}>0 دریافت شده</Text>
                                        </Box>
                                    </Box>
                                </Box>

                                <Box name="Box_Item_Consumption_Chart" style={styles.box_item_consumption_chart}>
                                    <Box name="Box_Top_Item_Consumption_Chart" style={styles.box_top_item_consumption_chart}>
                                        <Box name="Box_Receive_Top_Item_Consumption_Chart" style={styles.box_receive_top_item_consumption_chart}>
                                            <Text style={styles.text_receive_top_item_consumption_chart}>0 کیلوبایت</Text>

                                            <AntDesign name="arrowdown" style={styles.icon_arrow_down} />
                                        </Box>

                                        <Box name="Box_Send_Top_Item_Consumption_Chart" style={styles.box_send_top_item_consumption_chart}>
                                            <Text style={styles.text_send_top_item_consumption_chart}>0 کیلوبایت</Text>

                                            <AntDesign name="arrowup" style={styles.icon_up_down} />
                                        </Box>

                                        <Text style={styles.text_call_top_item_consumption_chart}>وضعیت</Text>

                                        <MaterialIcons name="data-usage" style={styles.icon_item_consumption_chart} />
                                    </Box>

                                    <Box name="Box_Top_Item_Consumption_Chart" style={styles.box_bottom_item_consumption_chart}>
                                        <Box name="Box_Progress" style={styles.box_Progress}>
                                            <Box name="Box_Progress_Inner" style={styles.box_progress_inner} />
                                        </Box>

                                        <Box name="Box_Text_Bottom_Item_Consumption_Chart" style={styles.box_text_bottom_item_consumption_chart}>
                                            <Text style={styles.text_exit}>0 ارسال شده</Text>
                                            --
                                            <Text style={styles.text_entrance}>0 دریافت شده</Text>
                                        </Box>
                                    </Box>
                                </Box>

                                <Box name="Box_Item_Consumption_Chart" style={styles.box_item_consumption_chart}>
                                    <Box name="Box_Top_Item_Consumption_Chart" style={styles.box_top_item_consumption_chart}>
                                        <Box name="Box_Receive_Top_Item_Consumption_Chart" style={styles.box_receive_top_item_consumption_chart}>
                                            <Text style={styles.text_receive_top_item_consumption_chart}>0 کیلوبایت</Text>

                                            <AntDesign name="arrowdown" style={styles.icon_arrow_down} />
                                        </Box>

                                        <Box name="Box_Send_Top_Item_Consumption_Chart" style={styles.box_send_top_item_consumption_chart}>
                                            <Text style={styles.text_send_top_item_consumption_chart}>0 کیلوبایت</Text>

                                            <AntDesign name="arrowup" style={styles.icon_up_down} />
                                        </Box>

                                        <Text style={styles.text_call_top_item_consumption_chart}>رومینگ</Text>

                                        <Entypo name="network" style={styles.icon_item_consumption_chart} />
                                    </Box>

                                    <Box name="Box_Top_Item_Consumption_Chart" style={styles.box_bottom_item_consumption_chart}>
                                        <Box name="Box_Progress" style={styles.box_Progress}>
                                            <Box name="Box_Progress_Inner" style={styles.box_progress_inner} />
                                        </Box>
                                    </Box>
                                </Box>
                            </Box>

                            <TouchableOpacity
                                name="Button_Reset_Statistics"
                                style={styles.button_reset_statistics}
                                onPress={() => {
                                    this.FuncResetStatistics();
                                }}>
                                <Text style={styles.text_top_reset_statistics}>بازنشانی آمار</Text>

                                <Text style={styles.text_bottom_reset_statistics}>زمان اخرین بازنشانی : 28/10/2021, 16:23</Text>
                            </TouchableOpacity>
                        </Box>
                    </ScrollView>
                    {/* End Sectino Content */}
                </Box>
                {/* End Section App */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class