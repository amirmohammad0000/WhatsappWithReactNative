//////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import AppAccountPage from "./Pages/AppAccountPage/AppAccountPage";
import SettingsChangeNumber from "./Pages/SettingsChangeNumber/SettingsChangeNumber";
import SettingsDeleteAcount from "./Pages/SettingsDeleteAcount/SettingsDeleteAcount";
import ScreensSettingsPrivacy from "./Pages/SettingsPrivacy/ScreensSettingsPrivacy";
import SettingsRequestAccountInformation from "./Pages/SettingsRequestAccountInformation/SettingsRequestAccountInformation";
import SettingsSecurity from "./Pages/SettingsSecurity/SettingsSecurity";
import SettingsTwoStepVerificationNumber from "./Pages/SettingsTwoStepVerificationNumber/SettingsTwoStepVerificationNumber";
//////////////////////////////////////////////////////////////////////// End Section Import

const Stack = createNativeStackNavigator();

//////////////////////////////////////////////////////////////////////// Start Section Class
export default class ScreensSettingsAccount extends React.Component {
    render() {
        return (
            <Stack.Navigator>
                {/* Start Section Stack */}
                <Stack.Screen
                    name="AppAccountPage"
                    component={AppAccountPage}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="SettingsChangeNumber"
                    component={SettingsChangeNumber}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="SettingsDeleteAcount"
                    component={SettingsDeleteAcount}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="ScreensSettingsPrivacy"
                    component={ScreensSettingsPrivacy}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="SettingsRequestAccountInformation"
                    component={SettingsRequestAccountInformation}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="SettingsSecurity"
                    component={SettingsSecurity}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="SettingsTwoStepVerificationNumber"
                    component={SettingsTwoStepVerificationNumber}
                    options={{
                        headerShown: false,
                    }}
                />
                {/* End Section Stack */}
            </Stack.Navigator>
        );
    }
}
//////////////////////////////////////////////////////////////////////// End Section Class