﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity } from "react-native";
import { styles } from "./Css/CssSettingsConversationHistory";
import { NativeBaseProvider, Box, Text } from "native-base";
import { AntDesign, Foundation, Feather, MaterialIcons } from "@expo/vector-icons";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class SettingsConversationHistory extends React.Component {
    FuncGoToPageSettingsConversation = () => {
        this.props.navigation.goBack();
    };

    FuncIssueConversation = () => {

    };

    FuncArchiveConversations = () => {

    };

    FuncClearConversation = () => {

    };

    FuncDeleteConversations = () => {

    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <Box name="App" style={styles.app}>
                    {/* Start Sectino Header*/}
                    <Box name="Header" style={styles.header}>
                        <Box />

                        <Box name="Box_Text_Header" style={styles.box_text_header}>
                            <Text style={styles.text_header}>تاریخچه گفتگو</Text>
                        </Box>

                        <TouchableOpacity
                            name="Box_Icon_Header"
                            style={styles.box_icon_header}
                            onPress={() => {
                                this.FuncGoToPageSettingsConversation();
                            }}>
                            <AntDesign name="arrowright" style={styles.icon_back} />
                        </TouchableOpacity>
                    </Box>
                    {/* End Sectino Header*/}

                    {/* Start Sectino Content */}
                    <Box name="Content" style={styles.content}>
                        <TouchableOpacity
                            name="Button_Item_Conversation_History"
                            style={styles.button_item_conversation_history}
                            onPress={() => {
                                this.FuncIssueConversation();
                            }}>
                            <MaterialIcons name="unarchive" style={styles.icon_conversation_history} />

                            <Text style={styles.text_item_conversation_history}>صدور گفتگو</Text>
                        </TouchableOpacity>

                        <TouchableOpacity
                            name="Button_Item"
                            style={styles.button_item_conversation_history}
                            onPress={() => {
                                this.FuncArchiveConversations();
                            }}>
                            <Foundation name="archive" style={styles.icon_conversation_history} />

                            <Text style={styles.text_item_conversation_history}>بایگانی تمام گفتگو ها</Text>
                        </TouchableOpacity>

                        <TouchableOpacity
                            name="Button_Item"
                            style={styles.button_item_conversation_history}
                            onPress={() => {
                                this.FuncClearConversation();
                            }}>
                            <Feather name="minus-circle" style={styles.icon_conversation_history} />

                            <Text style={styles.text_item_conversation_history}>پاک کردن تمام گفتگوها</Text>
                        </TouchableOpacity>

                        <TouchableOpacity
                            name="Button_Item"
                            style={styles.button_item_conversation_history}
                            onPress={() => {
                                this.FuncDeleteConversations();
                            }}>
                            <MaterialIcons name="delete" style={styles.icon_conversation_history} />

                            <Text style={styles.text_item_conversation_history}>حذف همه گفتگوها</Text>
                        </TouchableOpacity>
                    </Box>
                    {/* End Sectino Content */}
                </Box>
                {/* End Section App */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class