/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import { StyleSheet } from "react-native";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Style
const styles = StyleSheet.create({
    //////////////////////////////// Start Style App
    app: {
        width: "100%",
        height: "100%",
    },
    //////////////////////////////// End Style App

    //////////////////////////////// Start Style Header
    header: {
        width: "100%",
        height: "8%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "flex-end",
        backgroundColor: "#072",
    },

    box_text_header: {
        width: "90%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 30,
    },

    text_header: {
        color: "#eee",
        fontSize: 18,
    },

    box_icon_header: {
        width: "10%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 20,
    },

    icon_back: {
        color: "#eee",
        fontSize: 22,
    },
    //////////////////////////////// End Style Header

    //////////////////////////////// Start Style Content
    content: {
        width: "100%",
        height: "92%",
    },

    box_view: {
        width: "100%",
        height: "25%",
        borderBottomColor: "#ddd",
        borderBottomWidth: 1,
    },

    text_header_view: {
        color: "#666",
        fontSize: 14,
        paddingRight: 25,
        paddingTop: 15,
    },

    button_theme_view: {
        width: "100%",
        height: "40%",
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "flex-start",
    },

    icon_theme_view: {
        color: "#666",
        fontSize: 20,
        paddingRight: 25,
    },

    text_theme_view_top: {
        color: "#222",
        fontSize: 18,
        paddingRight: 25,
    },

    text_theme_view_bottom: {
        color: "#666",
        fontSize: 14,
        paddingRight: 25,
    },

    button_wallpaper_view: {
        width: "100%",
        height: "40%",
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "flex-start",
    },

    icon_wallpaper_view: {
        color: "#666",
        fontSize: 20,
        paddingRight: 25,
    },

    text_wallpaper_view: {
        color: "#222",
        fontSize: 18,
        paddingRight: 25,
    },

    box_settings_conversation: {
        width: "100%",
        height: "37%",
        borderBottomColor: "#ddd",
        borderBottomWidth: 1,
    },

    text_settings_conversation: {
        color: "#666",
        fontSize: 14,
        paddingRight: 25,
        paddingTop: 20,
    },

    button_login_for_send: {
        width: "100%",
        height: "25%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "space-between",
        paddingLeft: 10,
    },

    text_top_login_for_send: {
        color: "#222",
        fontSize: 16,
        paddingRight: 70,
    },

    text_bottom_login_for_send: {
        color: "#666",
        fontSize: 12,
        paddingRight: 70,
    },

    button_settings_view_media: {
        width: "100%",
        height: "25%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "space-between",
        paddingLeft: 10,
    },

    text_top_settings_view_media: {
        color: "#222",
        fontSize: 16,
        paddingRight: 70,
    },

    text_bottom_settings_view_media: {
        color: "#666",
        fontSize: 12,
        paddingRight: 70,
    },

    button_size_pen: {
        width: "100%",
        height: "25%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 70,
    },

    text_top_size_pen: {
        color: "#222",
        fontSize: 16,
    },

    text_bottom_size_pen: {
        color: "#666",
        fontSize: 14,
    },

    box_contacts_archive: {
        width: "100%",
        height: "18%",
        borderBottomColor: "#ddd",
        borderBottomWidth: 1,
    },

    text_header_contacts_archive: {
        color: "#666",
        fontSize: 14,
        paddingRight: 25,
        paddingTop: 15,
    },

    button_save_conversation_in_archive: {
        width: "100%",
        height: "80%",
        flexDirection: "row-reverse",
        alignItems: "flex-start",
        paddingTop: 15,
        paddingLeft: 10,
        paddingRight: 120,
    },

    text_top_save_conversation_in_archive: {
        color: "#222",
        fontSize: 16,
    },

    text_bottom_save_conversation_in_archive: {
        color: "#666",
        fontSize: 12,
    },

    button_backup_conversation: {
        marginTop: 10,
        width: "100%",
        height: "8%",
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "flex-start",
    },

    icon_backup_conversation: {
        color: "#888",
        fontSize: 20,
        paddingRight: 25,
    },

    text_backup_conversation: {
        color: "#222",
        fontSize: 16,
        paddingRight: 25,
    },

    button_history_conversation: {
        width: "100%",
        height: "8%",
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "flex-start",
    },

    icon_history_conversation: {
        color: "#888",
        fontSize: 20,
        paddingRight: 25,
    },

    text_history_conversation: {
        color: "#222",
        fontSize: 16,
        paddingRight: 25,
    },
    //////////////////////////////// End Style Content
});
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Style
export { styles };