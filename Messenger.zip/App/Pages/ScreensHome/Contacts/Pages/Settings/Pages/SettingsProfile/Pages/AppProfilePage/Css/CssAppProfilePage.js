/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import { StyleSheet } from "react-native";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Style
const styles = StyleSheet.create({
    //////////////////////////////// Start Style App
    app: {
        width: "100%",
        height: "100%",
    },
    //////////////////////////////// End Style App

    //////////////////////////////// Start Style Header
    header: {
        width: "100%",
        height: "8%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "flex-end",
        backgroundColor: "#072",
    },

    box_text_header: {
        width: "90%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 30,
    },

    text_header: {
        color: "#eee",
        fontSize: 18,
    },

    box_icon_header: {
        width: "10%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 20,
    },

    icon_back: {
        color: "#eee",
        fontSize: 22,
    },
    //////////////////////////////// End Style Header

    //////////////////////////////// Start Style Content
    content: {
        width: "100%",
        height: "92%",
    },

    box_image_profile: {
        width: "100%",
        height: "28%",
        alignItems: "center",
        justifyContent: "flex-end",
    },

    box_button_image_profile: {
        width: "100%",
        height: "70%",
        alignItems: "center",
        justifyContent: "flex-end",
    },

    image_profile: {
        width: "34%",
        height: "100%",
        top: 20,
        borderRadius: 1000,
    },

    button_camera: {
        width: "100%",
        height: "30%",
        alignItems: "center",
        justifyContent: "center",
    },

    icon_camera: {
        color: "#eee",
        fontSize: 20,
        backgroundColor: "#082",
        borderRadius: 1000,
        padding: 15,
        top: -40,
        left: 60,
    },

    box_name_user: {
        width: "100%",
        height: "15%",
    },

    box_text_name_user_top: {
        width: "100%",
        height: "50%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "flex-end",
    },

    icon_edit_user: {
        color: "#092",
        fontSize: 20,
        marginLeft: "45%",
    },

    text_name_user_box_top_top: {
        color: "#888",
        fontSize: 14,
        marginLeft: 25,
    },

    text_name_user_box_bottom_top: {
        color: "#222",
        fontSize: 18,
        marginLeft: 25,
    },

    icon_user: {
        color: "#888",
        fontSize: 20,
        marginLeft: 25,
    },

    box_text_name_user_bottom: {
        width: "100%",
        height: "50%",
        alignItems: "center",
        justifyContent: "center",
        paddingLeft: 65,
        paddingRight: 25,
    },

    text_name_user_bottom: {
        color: "#888",
        fontSize: 13,
    },

    box_about: {
        width: "100%",
        height: "11%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "flex-end",
    },

    icon_edit_about: {
        color: "#092",
        fontSize: 20,
        marginLeft: "55%",
    },

    text_about_top: {
        color: "#888",
        fontSize: 15,
        marginLeft: 25,
    },

    text_about_bottom: {
        color: "#222",
        fontSize: 17,
        marginLeft: 25,
    },

    icon_circle: {
        color: "#888",
        fontSize: 20,
        marginLeft: 25,
    },

    box_call: {
        width: "100%",
        height: "11%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "flex-end",
    },

    text_call_top: {
        color: "#888",
        fontSize: 15,
        marginLeft: 25,
    },

    text_call_bottom: {
        color: "#222",
        fontSize: 17,
        marginLeft: 25,
    },

    icon_call: {
        color: "#888",
        fontSize: 20,
        marginLeft: 25,
    },
    //////////////////////////////// End Style Content

    //////////////////////////////// Start Style Select Box Image
    box_select_box_image: {
        position: "absolute",
        bottom: 0,
        width: "100%",
        height: 100,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "flex-start",
        backgroundColor: "#fff",
    },

    box_gallery: {
        width: 120,
        height: 100,
        alignItems: "center",
        justifyContent: "center",
        paddingLeft: 10,
        paddingRight: 10,
    },

    image_gallery: {
        width: "60%",
        height: "60%",
    },

    text_gallery: {
        color: "#444",
        fontSize: 20,
    },

    box_camera: {
        width: 120,
        height: 100,
        alignItems: "center",
        justifyContent: "center",
        paddingLeft: 10,
        paddingRight: 10,
        borderLeftColor: "#aaa",
        borderLeftWidth: 1,
    },

    image_camera: {
        width: "60%",
        height: "60%",
    },

    text_camera: {
        color: "#444",
        fontSize: 20,
    },
    //////////////////////////////// End Style Select Box Image
});
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Style
export { styles };