/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { styles } from "./Css/CssSingleItemCountry";
import { NativeBaseProvider, Box, Image, Text } from "native-base";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class SingleItemCountry extends React.Component {
    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <Box name="App" style={styles.app}>
                    <Box name="Box_Single_Item_Country" style={styles.box_single_item_country}>
                        <Box style={styles.box_text_image}>
                            <Image style={styles.image_flag} source={this.props.Flag} alt="Image Flag" />

                            <Text style={styles.text_name_country}>{this.props.NameCountry}</Text>
                        </Box>

                        <Text style={styles.text_number_code}>{this.props.NumberCode}</Text>
                    </Box>
                </Box>
                {/* End Section App */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class