/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import { StyleSheet } from "react-native";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Style
const styles = StyleSheet.create({
    //////////////////////////////// Start Style App
    app: {
        width: "100%",
        height: "100%",
    },
    //////////////////////////////// End Style App

    //////////////////////////////// Start Style Header
    header: {
        width: "100%",
        height: "8%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "flex-end",
        backgroundColor: "#072",
    },

    box_text_header: {
        width: "90%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 30,
    },

    text_header: {
        color: "#eee",
        fontSize: 18,
    },

    box_icon_header: {
        width: "10%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 20,
    },

    icon_back: {
        color: "#eee",
        fontSize: 22,
    },
    //////////////////////////////// End Style Header

    //////////////////////////////// Start Style Content
    content: {
        width: "100%",
        height: "92%",
    },

    button_manage_storange: {
        width: "100%",
        height: "12%",
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "flex-start",
        borderBottomColor: "#ddd",
        borderBottomWidth: 1,
    },

    icon_manage_storange: {
        color: "#777",
        fontSize: 20,
        paddingRight: 25,
    },

    text_top_manage_storange: {
        color: "#222",
        fontSize: 16,
        paddingRight: 25,
    },

    text_bottom_manage_storange: {
        color: "#777",
        fontSize: 13,
        paddingRight: 25,
    },

    button_network_consumption: {
        width: "100%",
        height: "10%",
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "flex-start",
    },

    icon_network_consumption: {
        color: "#222",
        fontSize: 16,
        paddingRight: 25,
    },

    text_top_network_consumption: {
        color: "#222",
        fontSize: 16,
        paddingRight: 25,
    },

    text_bottom_network_consumption: {
        color: "#777",
        fontSize: 13,
        paddingRight: 25,
    },

    button_useing_data_for_call: {
        width: "100%",
        height: "10%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "space-between",
        paddingRight: 70,
        paddingLeft: 20,
        borderBottomColor: "#ddd",
        borderBottomWidth: 1,
    },

    box_download_auto_media: {
        width: "100%",
        height: "42%",
        borderBottomColor: "#ddd",
        borderBottomWidth: 1,
    },

    text_header_one_download_auto_media: {
        color: "#666",
        fontSize: 14,
        paddingTop: 25,
        paddingRight: 25,
    },

    text_header_two_download_auto_media: {
        color: "#666",
        fontSize: 14,
        paddingTop: 5,
        paddingRight: 25,
    },

    button_internet_phone: {
        width: "100%",
        height: "20%",
        marginTop: 25,
        paddingLeft: 70,
    },

    text_one_internet_phone: {
        color: "#222",
        fontSize: 16,
    },

    text_two_internet_phone: {
        color: "#666",
        fontSize: 14,
    },

    button_wifi: {
        width: "100%",
        height: "20%",
        marginTop: 10,
        paddingLeft: 70,
    },

    text_one_Wifi: {
        color: "#222",
        fontSize: 16,
    },

    text_two_Wifi: {
        color: "#666",
        fontSize: 14,
    },

    button_roaming: {
        width: "100%",
        height: "20%",
        marginTop: 10,
        paddingLeft: 70,
    },

    text_one_roaming: {
        color: "#222",
        fontSize: 16,
    },

    text_two_roaming: {
        color: "#666",
        fontSize: 14,
    },

    box_quality_upload_image: {
        width: "100%",
        height: "21%",
    },

    text_one_header_quality_upload_image: {
        color: "#666",
        fontSize: 14,
        paddingTop: 25,
        paddingRight: 25,
    },

    text_two_header_quality_upload_image: {
        color: "#666",
        fontSize: 14,
        paddingTop: 5,
        paddingRight: 25,
    },

    button_quality_upload_image: {
        width: "100%",
        height: "50%",
        alignItems: "flex-start",
        justifyContent: "center",
        marginTop: 10,
        paddingLeft: 70,
    },

    text_one_quality_upload_image: {
        color: "#222",
        fontSize: 16,
    },

    text_two_quality_upload_image: {
        color: "#666",
        fontSize: 14,
    },
    //////////////////////////////// End Style Content
});
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Style
export { styles };