﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity } from "react-native";
import { styles } from "./Css/CssSettingsLivePlace";
import { NativeBaseProvider, Box, Image, Text } from "native-base";
import { AntDesign } from "@expo/vector-icons";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class SettingsLivePlace extends React.Component {
    state = {
        StateLivePlace: false,
    };

    FuncGoToPageSettingsPrivacy = () => {
        this.props.navigation.goBack();
    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <Box name="App" style={styles.app}>
                    {/* Start Section Header */}
                    <Box name="Header" style={styles.header}>
                        <Box />

                        <Box name="Box_Center_Header" style={styles.box_center_header} >
                            <Text style={styles.text_header}>مکان زنده</Text>
                        </Box>

                        <TouchableOpacity
                            onPress={() => {
                                this.FuncGoToPageSettingsPrivacy();
                            }}
                            name="Box_Right_Header"
                            style={styles.button_back}>
                            <AntDesign name="arrowright" style={styles.icon_back} />
                        </TouchableOpacity>
                    </Box>
                    {/* End Section Header */}

                    {/* Start Section Content */}
                    <Box name="Content" style={styles.content}>
                        {
                            this.state.StateLivePlace === true ?
                                <Text />
                                :
                                <Box name="Box_False_State_Live_Place" style={styles.box_false_state_Live_place}>
                                    <Box name="Box_Image" style={styles.box_image}>
                                        <Image alt="Image Live Place" source={require("./../../../../../../../../../../../Assets/Images/ImageLivePlace.png")} style={styles.image_live_place} />
                                    </Box>

                                    <Box name="Box_Bottom_Image" style={styles.box_bottom_image}>
                                        <Text style={styles.text_bottom_image}>شما در حال اشتراک مکان زنده در هیچ گفتگویی نیستند</Text>
                                    </Box>

                                    <Box name="Box_Footer_Content" style={styles.box_footer_content}>
                                        <Text style={styles.text_footer}>مکان زنده به دسترسی به مکان در پس زمینه نیاز دارد. این مورد را میتوانید در تنظیمات دستگاه خود تنظیم کنید.</Text>
                                    </Box>
                                </Box>
                        }
                    </Box>
                    {/* End Section Content */}
                </Box>
                {/* End Section App */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class