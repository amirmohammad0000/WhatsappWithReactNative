﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity } from "react-native";
import { styles } from "./Css/CssSettingsChangeNumber";
import { NativeBaseProvider, Box, Image, Text } from "native-base";
import { AntDesign } from "@expo/vector-icons";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class SettingsChangeNumber extends React.Component {
    FuncGoToPageSettingsAccount = () => {
        this.props.navigation.goBack();
    };

    FuncGoToPageChangeNumber = () => {

    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <Box name="App" style={styles.app}>
                    {/* Start Section Header */}
                    <Box name="Header" style={styles.header}>
                        <Box />

                        <Box name="Box_Center_Header" style={styles.box_center_header} >
                            <Text style={styles.text_header}>تعغیر شماره</Text>
                        </Box>

                        <TouchableOpacity
                            onPress={() => {
                                this.FuncGoToPageSettingsAccount();
                            }}
                            name="Box_Right_Header"
                            style={styles.button_back}>
                            <AntDesign name="arrowright" style={styles.icon_back} />
                        </TouchableOpacity>
                    </Box>
                    {/* End Section Header */}

                    {/* Start Section Content */}
                    <Box name="Content" style={styles.content}>
                        <Box name="Box_Image" style={styles.box_image}>
                            <Image alt="Image Change Number" source={require("./../../../../../../../../../Assets/Images/ChangeNumber.png")} style={styles.image_change_number} />
                        </Box>

                        <Box name="Box_Text" style={styles.box_text}>
                            <Text style={styles.text_one_change_number}>تغییر شماره تلفن, اطلاعات حساب کاربری, گروه ها و تنظیمات شما را منتقل میکند.</Text>

                            <Text style={styles.text_two_change_number}>قبل از ادامه لطفا تایید کنید روی شماره جدید میتوانید پیامک یا تماس صوتی دریافت کنید.</Text>

                            <Text style={styles.text_three_change_number}>اگر علاوه بر شماره تلفن جدید, گوشی تلفن جدید نیز گرفته اید, نخست شماره خود را روی گوشی قدیمی تان عوض کنید.</Text>
                        </Box>

                        <TouchableOpacity
                            name="Button_Next"
                            style={styles.button_next}
                            onPress={() => {
                                this.FuncGoToPageChangeNumber();
                            }}>
                            <Text style={styles.text_next}>بعدی</Text>
                        </TouchableOpacity>
                    </Box>
                    {/* End Section Content */}
                </Box>
                {/* End Section App */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class