//////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import AppPrivacyPage from "./Pages/AppPrivacyPage/AppPrivacyPage";
import SettingsAudienceBlocked from "./Pages/SettingsAudienceBlocked/SettingsAudienceBlocked";
import SettingsGroupsSettings from "./Pages/SettingsGroupsSettings/SettingsGroupsSettings";
import SettingsLivePlace from "./Pages/SettingsLivePlace/SettingsLivePlace";
import SettingsStatusSettings from "./Pages/SettingsStatusSettings/SettingsStatusSettings";
//////////////////////////////////////////////////////////////////////// End Section Import

const Stack = createNativeStackNavigator();

//////////////////////////////////////////////////////////////////////// Start Section Class
export default class ScreensSettingsPrivacy extends React.Component {
    render() {
        return (
            <Stack.Navigator>
                <Stack.Screen
                    name="AppPrivacyPage"
                    component={AppPrivacyPage}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="SettingsAudienceBlocked"
                    component={SettingsAudienceBlocked}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="SettingsGroupsSettings"
                    component={SettingsGroupsSettings}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="SettingsLivePlace"
                    component={SettingsLivePlace}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="SettingsStatusSettings"
                    component={SettingsStatusSettings}
                    options={{
                        headerShown: false,
                    }}
                />
            </Stack.Navigator>
        );
    }
}
//////////////////////////////////////////////////////////////////////// End Section Class