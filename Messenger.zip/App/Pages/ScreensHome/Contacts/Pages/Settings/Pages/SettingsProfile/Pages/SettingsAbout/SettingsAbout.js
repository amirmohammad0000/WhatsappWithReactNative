﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity } from "react-native";
import { styles } from "./Css/CssSettingsAbout";
import { NativeBaseProvider, Box, Text } from "native-base";
import { AntDesign, FontAwesome5 } from "@expo/vector-icons";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class SettingsAbout extends React.Component {
    state = {
        StateAbout: "Hello World",
    };

    FuncGoToPageSettingsProfile = () => {
        this.props.navigation.goBack();
    };

    FuncSetCurrentAbout = () => {

    };

    FuncSetAboutOne = () => {
        this.setState({
            StateAbout: "در دسترس",
        });
    };

    FuncSetAboutTwo = () => {
        this.setState({
            StateAbout: "مشغول",
        });
    };

    FuncSetAboutThree = () => {
        this.setState({
            StateAbout: "سر کلاس",
        });
    };

    FuncSetAboutFour = () => {
        this.setState({
            StateAbout: "در سینما",
        });
    };

    FuncSetAboutFive = () => {
        this.setState({
            StateAbout: "سر کار",
        });
    };

    FuncSetAboutSix = () => {
        this.setState({
            StateAbout: "شارژ باتری رو به اتمام",
        });
    };

    FuncSetAboutSeven = () => {
        this.setState({
            StateAbout: "نمیتوانم صحبت کنم, فقط واتساپ",
        });
    };

    FuncSetAboutEight = () => {
        this.setState({
            StateAbout: "در جلسه",
        });
    };

    FuncSetAboutNine = () => {
        this.setState({
            StateAbout: "در باشگاه ورزشی",
        });
    };

    FuncSetAboutTen = () => {
        this.setState({
            StateAbout: "در حال خواب",
        });
    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <Box name="App" style={styles.app}>
                    {/* Start Sectino Header*/}
                    <Box name="Header" style={styles.header}>
                        <Box />

                        <Box name="Box_Text_Header" style={styles.box_text_header}>
                            <Text style={styles.text_header}>درباره</Text>
                        </Box>

                        <TouchableOpacity
                            name="Box_Icon_Header"
                            style={styles.box_icon_header}
                            onPress={() => {
                                this.FuncGoToPageSettingsProfile();
                            }}>
                            <AntDesign name="arrowright" style={styles.icon_back} />
                        </TouchableOpacity>
                    </Box>
                    {/* End Sectino Header*/}

                    {/* Start Sectino Content */}
                    <Box name="Content" style={styles.content}>
                        <Box name="Box_Current_About" style={styles.box_current_about}>
                            <Text style={styles.text_current_about}>در حال حاضر تنظیم شده است به</Text>

                            <TouchableOpacity
                                name="Box_Inner_Current_Box"
                                style={styles.box_inner_current_box}
                                onPress={() => {
                                    this.FuncSetCurrentAbout();
                                }}>
                                <FontAwesome5 name="pen" style={styles.icon_current_box} />

                                <Text style={styles.text_state_about}>{this.state.StateAbout}</Text>
                            </TouchableOpacity>
                        </Box>

                        <Box name="Box_Select_About" style={styles.box_select_about}>
                            <Text style={styles.text_select_about}>درباره خود را انتخاب کنید</Text>

                            <TouchableOpacity
                                name="Button_Item_Select_About"
                                style={styles.button_item_select_about}
                                onPress={() => {
                                    this.FuncSetAboutOne();
                                }}>
                                <Text style={styles.text_item_select_about}>در دسترس</Text>
                            </TouchableOpacity>

                            <TouchableOpacity
                                name="Button_Item_Select_About"
                                style={styles.button_item_select_about}
                                onPress={() => {
                                    this.FuncSetAboutTwo();
                                }}>
                                <Text style={styles.text_item_select_about}>مشغول</Text>
                            </TouchableOpacity>

                            <TouchableOpacity
                                name="Button_Item_Select_About"
                                style={styles.button_item_select_about}
                                onPress={() => {
                                    this.FuncSetAboutThree();
                                }}>
                                <Text style={styles.text_item_select_about}>سر کلاس</Text>
                            </TouchableOpacity>

                            <TouchableOpacity
                                name="Button_Item_Select_About"
                                style={styles.button_item_select_about}
                                onPress={() => {
                                    this.FuncSetAboutFour();
                                }}>
                                <Text style={styles.text_item_select_about}>در سینما</Text>
                            </TouchableOpacity>

                            <TouchableOpacity
                                name="Button_Item_Select_About"
                                style={styles.button_item_select_about}
                                onPress={() => {
                                    this.FuncSetAboutFive();
                                }}>
                                <Text style={styles.text_item_select_about}>سر کار</Text>
                            </TouchableOpacity>

                            <TouchableOpacity
                                name="Button_Item_Select_About"
                                style={styles.button_item_select_about}
                                onPress={() => {
                                    this.FuncSetAboutSix();
                                }}>
                                <Text style={styles.text_item_select_about}>شارژ باتری رو به اتمام</Text>
                            </TouchableOpacity>

                            <TouchableOpacity
                                name="Button_Item_Select_About"
                                style={styles.button_item_select_about}
                                onPress={() => {
                                    this.FuncSetAboutSeven();
                                }}>
                                <Text style={styles.text_item_select_about}>نمیتوانم صحبت کنم, فقط واتساپ</Text>
                            </TouchableOpacity>

                            <TouchableOpacity
                                name="Button_Item_Select_About"
                                style={styles.button_item_select_about}
                                onPress={() => {
                                    this.FuncSetAboutEight();
                                }}>
                                <Text style={styles.text_item_select_about}>در جلسه</Text>
                            </TouchableOpacity>

                            <TouchableOpacity
                                name="Button_Item_Select_About"
                                style={styles.button_item_select_about}
                                onPress={() => {
                                    this.FuncSetAboutNine();
                                }}>
                                <Text style={styles.text_item_select_about}>در باشگاه ورزشی</Text>
                            </TouchableOpacity>

                            <TouchableOpacity
                                name="Button_Item_Select_About"
                                style={styles.button_item_select_about}
                                onPress={() => {
                                    this.FuncSetAboutTen();
                                }}>
                                <Text style={styles.text_item_select_about}>در حال خواب</Text>
                            </TouchableOpacity>
                        </Box>
                    </Box>
                    {/* End Sectino Content */}
                </Box>
                {/* End Section App */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class