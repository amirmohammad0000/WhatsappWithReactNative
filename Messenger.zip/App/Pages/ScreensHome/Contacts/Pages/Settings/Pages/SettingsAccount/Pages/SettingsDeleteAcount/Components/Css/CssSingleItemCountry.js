/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import { StyleSheet } from "react-native";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Style
const styles = StyleSheet.create({
    //////////////////////////////// Start Style App
    app: {
        width: "100%",
        height: "100%",
    },

    box_single_item_country: {
        width: "100%",
        height: 50,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
    },

    box_text_image: {
        width: "25%",
        height: "100%",
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-evenly",
    },

    image_flag: {
        width: "30%",
        height: "70%",
        borderRadius: 1000,
    },

    text_name_country: {
        color: "#222",
        fontSize: 18,
    },

    text_number_code: {
        color: "#555",
        fontSize: 18,
        marginRight: 50,
    },
    //////////////////////////////// End Style App
});
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Style
export { styles };