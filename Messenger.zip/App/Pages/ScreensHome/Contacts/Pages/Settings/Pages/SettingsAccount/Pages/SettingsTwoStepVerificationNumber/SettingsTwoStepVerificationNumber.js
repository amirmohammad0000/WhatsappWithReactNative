﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity } from "react-native";
import { styles } from "./Css/CssSettingsTwoStepVerificationNumber";
import { NativeBaseProvider, Box, Image, Text } from "native-base";
import { AntDesign } from "@expo/vector-icons";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class SettingsTwoStepVerificationNumber extends React.Component {
    FuncGoToPageSettingsAccount = () => {
        this.props.navigation.goBack();
    };

    FuncActivateTwoStepVerificationNumber = () => {

    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <Box name="App" style={styles.app}>
                    {/* Start Section Header */}
                    <Box name="Header" style={styles.header}>
                        <Box />

                        <Box name="Box_Center_Header" style={styles.box_center_header} >
                            <Text style={styles.text_header}>تایید شماره دو مرحله ای</Text>
                        </Box>

                        <TouchableOpacity
                            onPress={() => {
                                this.FuncGoToPageSettingsAccount();
                            }}
                            name="Box_Right_Header"
                            style={styles.button_back}>
                            <AntDesign name="arrowright" style={styles.icon_back} />
                        </TouchableOpacity>
                    </Box>
                    {/* End Section Header */}

                    {/* Start Section Content */}
                    <Box name="Content" style={styles.content}>
                        <Box name="Box_Image" style={styles.box_image}>
                            <Image alt="Image Two Step Verification Number" source={require("./../../../../../../../../../Assets/Images/ImageTwoStepVerificationNumber.png")} style={styles.image_two_step_verificationn_number} />
                        </Box>

                        <Box name="Box_Text" style={styles.box_text}>
                            <Text style={styles.text_two_step_verificationn_number}>تایید شماره دو مرحله ای را برای امنیت بیشتر فعال کنید, که باعث میشود هنگام ثبت دوباره شماره تلفنتان در واتساپ, به شماره رمز نیاز باشد.</Text>
                        </Box>

                        <TouchableOpacity
                            name="Button_Activate"
                            style={styles.button_activate}
                            onPress={() => {
                                this.FuncActivateTwoStepVerificationNumber();
                            }}>
                            <Text style={styles.text_button}>فعال سازی</Text>
                        </TouchableOpacity>
                    </Box>
                    {/* End Section Content */}
                </Box>
                {/* End Section App */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class