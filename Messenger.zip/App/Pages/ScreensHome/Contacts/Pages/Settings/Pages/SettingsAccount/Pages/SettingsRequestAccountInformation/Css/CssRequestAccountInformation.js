/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import { StyleSheet } from "react-native";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Style
const styles = StyleSheet.create({
    //////////////////////////////// Start Style App
    app: {
        width: "100%",
        height: "100%",
    },
    //////////////////////////////// End Style App

    //////////////////////////////// Start Style Header
    header: {
        width: "100%",
        height: "8%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "flex-end",
        backgroundColor: "#072",
    },

    box_center_header: {
        width: "90%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 30,
    },

    text_header: {
        color: "#eee",
        fontSize: 20,
    },

    button_back: {
        width: "10%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    icon_back: {
        color: "#eee",
        fontSize: 22,
    },
    //////////////////////////////// End Style Header

    //////////////////////////////// Start Style Content
    content: {
        width: "100%",
        height: "92%",
    },

    box_image: {
        width: "100%",
        height: "20%",
        alignItems: "center",
        justifyContent: "center",
    },

    image_document: {
        width: 120,
        height: 120,
    },

    box_text: {
        width: "100%",
        height: "15%",
        paddingLeft: 25,
        paddingRight: 30,
    },

    text_box_text: {
        color: "#222",
        fontSize: 17,
    },

    button_request_account_information: {
        width: "100%",
        height: "11%",
        flexDirection: "row",
        alignItems: "center",
        borderBottomColor: "#ddd",
        borderBottomWidth: 1,
        borderTopColor: "#ddd",
        borderTopWidth: 1,
    },

    icon_document: {
        color: "#666",
        fontSize: 22,
        paddingRight: 25,
    },

    text_button_request_account_information: {
        color: "#222",
        fontSize: 16,
        paddingRight: 25,
    },
    //////////////////////////////// End Style Content
});
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Style
export { styles };