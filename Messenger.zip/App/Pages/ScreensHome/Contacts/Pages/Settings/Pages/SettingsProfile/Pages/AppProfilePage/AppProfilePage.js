﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity } from "react-native";
import { styles } from "./Css/CssAppProfilePage";
import { NativeBaseProvider, Image, Box, Text } from "native-base";
import { launchCamera, launchImageLibrary } from "react-native-image-picker";
import { AntDesign, Ionicons, FontAwesome, Feather, Entypo } from "@expo/vector-icons";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class AppProfilePage extends React.Component {
    state = {
        PositionSelectBoxImage: "100%",
        PathImageProfile: "",
    };

    FuncGoToPageSettingsProfile = () => {
        this.props.navigation.goBack();
    };

    FuncImageProfile = () => {

    };

    FuncOpenSelectBoxImage = () => {
        this.setState({
            PositionSelectBoxImage: "0",
        });
    };

    FuncCloseSelectBoxImage = () => {
        this.setState({
            PositionSelectBoxImage: "100%",
        });
    };

    FuncSetBoxChangeNameUser = () => {

    };

    FuncGoToPageSettingsAbout = () => {
        this.props.navigation.navigate("SettingsAbout");
    };

    FuncGoToPageSettingsPhone = () => {
        this.props.navigation.navigate("SettingsChangeNumber");
    };

    FuncGetImageFromGallery = () => {
        launchImageLibrary({}, (response) => {
            response.assets.forEach((item) => {
                if (item.uri !== "") {
                    this.setState({
                        PathImageProfile: item.uri,
                    });
                }
            });
        });
    };

    FuncGetImageFromCamera = () => {
        launchCamera({}, (response) => {
            response.assets.forEach((item) => {
                if (item.uri !== "") {
                    this.setState({
                        PathImageProfile: item.uri,
                    });
                }
            });
        });
    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <TouchableOpacity
                    activeOpacity={1}
                    onPress={() => {
                        this.FuncCloseSelectBoxImage();
                    }}>
                    <Box name="App" style={styles.app}>
                        {/* Start Sectino Header*/}
                        <Box name="Header" style={styles.header}>
                            <Box />

                            <Box name="Box_Text_Header" style={styles.box_text_header}>
                                <Text style={styles.text_header}>نمایه</Text>
                            </Box>

                            <TouchableOpacity
                                name="Box_Icon_Header"
                                style={styles.box_icon_header}
                                onPress={() => {
                                    this.FuncGoToPageSettingsProfile();
                                }}>
                                <AntDesign name="arrowright" style={styles.icon_back} />
                            </TouchableOpacity>
                        </Box>
                        {/* End Sectino Header*/}

                        {/* Start Sectino Content */}
                        <Box name="Content" style={styles.content}>
                            <Box name="Box_Image" style={styles.box_image_profile}>
                                <TouchableOpacity
                                    style={styles.box_button_image_profile}
                                    onPress={() => {
                                        this.FuncImageProfile();
                                    }}>
                                    <Image alt="Image Profile" source={require("./../../../../../../../../../Assets/Images/imagePerson5.png")} style={styles.image_profile} />
                                </TouchableOpacity>

                                <TouchableOpacity
                                    style={styles.button_camera}
                                    onPress={() => {
                                        this.FuncOpenSelectBoxImage();
                                    }}>
                                    <Ionicons name="camera" style={styles.icon_camera} />
                                </TouchableOpacity>
                            </Box>

                            <TouchableOpacity
                                name="Box_Name_User"
                                style={styles.box_name_user}
                                onPress={() => {
                                    this.FuncSetBoxChangeNameUser();
                                }}>
                                <Box name="Box_Text_Name_User_Top" style={styles.box_text_name_user_top}>
                                    <Entypo name="edit" style={styles.icon_edit_user} />

                                    <Box>
                                        <Text style={styles.text_name_user_box_top_top}>نام</Text>

                                        <Text style={styles.text_name_user_box_bottom_top}>Amir Mohammad</Text>
                                    </Box>

                                    <FontAwesome name="user" style={styles.icon_user} />
                                </Box>

                                <Box name="Box_Text_Name_User_Bottom" style={styles.box_text_name_user_bottom}>
                                    <Text style={styles.text_name_user_bottom}>این نام کاربری یا رمز عبور شما نیست, بلکه نامی است که برای دوستان شما در واتساپ نمایش داده میشود</Text>
                                </Box>
                            </TouchableOpacity>

                            <TouchableOpacity
                                name="Box_About"
                                style={styles.box_about}
                                onPress={() => {
                                    this.FuncGoToPageSettingsAbout();
                                }}>
                                <Entypo name="edit" style={styles.icon_edit_about} />

                                <Box>
                                    <Text style={styles.text_about_top}>درباره</Text>

                                    <Text style={styles.text_about_bottom}>hello world</Text>
                                </Box>

                                <Feather name="alert-circle" style={styles.icon_circle} />
                            </TouchableOpacity>

                            <TouchableOpacity
                                name="Box_Call"
                                style={styles.box_call}
                                onPress={() => {
                                    this.FuncGoToPageSettingsPhone();
                                }}>
                                <Box>
                                    <Text style={styles.text_call_top}>تلفن</Text>

                                    <Text style={styles.text_call_bottom}>+98 903 564 3545</Text>
                                </Box>

                                <Ionicons name="call" style={styles.icon_call} />
                            </TouchableOpacity>
                        </Box>
                        {/* End Sectino Content */}
                    </Box>
                </TouchableOpacity>
                {/* End Section App */}

                {/* Start Section Select Box Image */}
                <Box name="Box_Select_Box_Image" style={styles.box_select_box_image} left={this.state.PositionSelectBoxImage}>
                    <TouchableOpacity onPress={() => {
                        this.FuncGetImageFromGallery();
                        this.FuncOpenCloseSelectBoxImage();
                    }}>
                        <Box style={styles.box_gallery}>
                            <Image style={styles.image_gallery} alt="Image Camera" source={require("./../../../../../../../../../Assets/Images/ImageGallery.png")} />

                            <Text style={styles.text_gallery}>از گالری</Text>
                        </Box>
                    </TouchableOpacity>

                    <TouchableOpacity onPress={() => {
                        this.FuncGetImageFromCamera();
                        this.FuncOpenCloseSelectBoxImage();
                    }}>
                        <Box style={styles.box_camera}>
                            <Image style={styles.image_camera} alt="Image Galery" source={require("./../../../../../../../../../Assets/Images/ImageCamera.png")} />

                            <Text style={styles.text_camera}>از دوربین</Text>
                        </Box>
                    </TouchableOpacity>
                </Box>
                {/* End Section Select Box Image */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class