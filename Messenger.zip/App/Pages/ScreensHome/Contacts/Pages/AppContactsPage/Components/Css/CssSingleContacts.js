/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import { StyleSheet } from "react-native";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Style
const styles = StyleSheet.create({
    //////////////////////////////// Start Style App
    app: {
        width: "100%",
        height: "100%",
    },

    box_main_item: {
        width: "100%",
        height: 70,
    },

    box_item_chat: {
        width: "100%",
        height: "100%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "space-between",
    },

    box_last_time_message: {
        width: "17%",
        height: "100%",
        alignItems: "flex-end",
        justifyContent: "flex-start",
    },

    last_time_message: {
        color: "#888",
        fontSize: 10,
        paddingLeft: 8,
        paddingTop: 15,
    },

    box_text: {
        width: "65%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
    },

    text_name_chat: {
        color: "#222",
        fontSize: 16,
    },

    text_last_message: {
        color: "#666",
        fontSize: 16,
    },

    box_image_profile: {
        width: "18%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    image_profile: {
        width: "70%",
        height: "80%",
        borderRadius: 1000,
    },
    //////////////////////////////// End Style App
});
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Style
export { styles };