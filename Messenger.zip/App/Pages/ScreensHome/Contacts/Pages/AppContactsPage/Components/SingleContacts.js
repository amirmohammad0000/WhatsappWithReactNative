﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity } from "react-native";
import { styles } from "./Css/CssSingleContacts";
import { NativeBaseProvider, Box, Image, Text } from "native-base";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class SingleContacts extends React.Component {
    FuncGoToPageChat = () => {
        if (this.props.StateChat === "UserChat") {
            this.props.navigation.navigate("ScreensUserChat");
        } else if (this.props.StateChat === "GroupChat") {
            this.props.navigation.navigate("ScreensGroupChat");
        }
    };

    FuncViewImageProfile = () => {

    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <TouchableOpacity onPress={() => {
                    this.FuncGoToPageChat();
                }}>
                    <Box name="App" style={styles.app}>
                        <Box name="Box_Main_Item" style={styles.box_main_item}>
                            <Box name="Box_Item_Chat" style={styles.box_item_chat}>
                                <Box name="Box_Last_Time_Message" style={styles.box_last_time_message}>
                                    <Text style={styles.last_time_message}>{this.props.TimeLastMessage}</Text>
                                </Box>

                                <Box name="Box_Text" style={styles.box_text}>
                                    <Text style={styles.text_name_chat}>{this.props.NameChat}</Text>

                                    <Text style={styles.text_last_message}>{this.props.LastMessages}</Text>
                                </Box>

                                <TouchableOpacity name="Box_Image_Profile" style={styles.box_image_profile} onPress={() => {
                                    this.FuncViewImageProfile();
                                }}>
                                    <Image source={this.props.ImageProfile} alt="Image Profile" style={styles.image_profile} />
                                </TouchableOpacity>
                            </Box>
                        </Box>
                    </Box>
                </TouchableOpacity>
                {/* End Section App */}
            </NativeBaseProvider >
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class