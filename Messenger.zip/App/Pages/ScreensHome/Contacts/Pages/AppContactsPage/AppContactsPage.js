﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity, FlatList } from "react-native";
import { styles } from "./Css/CssAppContactsPage";
import { NativeBaseProvider, Box, Text } from "native-base";
import { Entypo, AntDesign, MaterialIcons, Ionicons } from "@expo/vector-icons";
import { launchCamera } from "react-native-image-picker";
import SingleContacts from "./Components/SingleContacts";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class AppContactsPage extends React.Component {
    state = {
        data: [
            {
                id: "1",
                StateChat: "UserChat",
                ImageProfile: require("./../../../../../Assets/Images/ImageSingleProfile.png"),
                NameChat: "Amir",
                TimeLastMessage: "12:45",
                LastMessages: "پیام ها و تماس ها سرتاسر رمزگذاری شده اند",
            },
            {
                id: "2",
                StateChat: "GroupChat",
                ImageProfile: require("./../../../../../Assets/Images/ImageGroupProfile.png"),
                NameChat: "کامپیوتر",
                TimeLastMessage: "2021/10/18",
                LastMessages: "کسی گروه ساختمان داده رو داره +98 914 056 7646",
            },
            {
                id: "3",
                StateChat: "UserChat",
                ImageProfile: require("./../../../../../Assets/Images/ImageSingleProfile.png"),
                NameChat: "hossein",
                TimeLastMessage: "2021/9/5",
                LastMessages: "hello",
            },
            {
                id: "4",
                StateChat: "UserChat",
                ImageProfile: require("./../../../../../Assets/Images/ImageSingleProfile.png"),
                NameChat: "ali",
                TimeLastMessage: "2021/10/20",
                LastMessages: "سلام من خوبم تو خوبی",
            },
        ],
        StateArchive: true,
        PositionMenuContacts: "100%",
    };

    FuncSetCamera = () => {
        launchCamera({}, () => {

        });
    };

    FuncOpenMenu = () => {
        this.setState({
            PositionMenuContacts: "55%",
        });
    };

    FuncCloseMenu = () => {
        this.setState({
            PositionMenuContacts: "100%",
        });
    };

    FuncGoToPageSearch = () => {
        this.props.navigation.navigate("SearchContacts");
    };

    FuncSetContacts = () => {
        this.props.navigation.navigate("ScreensContacts");
    };

    FuncSetStatus = () => {
        this.props.navigation.navigate("ScreensStatus");
    };

    FuncSetCalls = () => {
        this.props.navigation.navigate("ScreensCalls");
    };

    FuncGoToPageArchive = () => {
        this.props.navigation.navigate("ScreensArchive");
    };

    FuncGoToPageSelectContacts = () => {
        this.props.navigation.navigate("SelectContacts");
    };

    FuncGoToPageAddNewGroup = () => {
        this.props.navigation.navigate("AddNewGroup");
    };

    FuncGoToPageNewReleaseList = () => {
        this.props.navigation.navigate("NewReleaseList");
    };

    FuncGoToPageConnectedDevices = () => {
        this.props.navigation.navigate("ConnectedDevices");
    };

    FuncGoToPageStarredMessages = () => {
        this.props.navigation.navigate("StarredMessages");
    };

    FuncGoToPageSettings = () => {
        this.props.navigation.navigate("ScreensSettings");
    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <Box name="App" style={styles.app}>
                    {/* Start Section App */}
                    <TouchableOpacity
                        activeOpacity={1}
                        onPress={() => {
                            this.FuncCloseMenu();
                        }}>
                        <Box name="App" style={styles.app}>
                            {/* Start Section Header */}
                            <Box name="Header" style={styles.header}>
                                {/* Start Section Box Top */}
                                <Box name="Box_Top_App" style={styles.section_top_app}>
                                    <Box name="Box_Icons" style={styles.box_icons_section_top_app}>
                                        <TouchableOpacity onPress={() => {
                                            this.FuncOpenMenu();
                                        }} style={styles.button_menu}>
                                            <Entypo name="dots-three-vertical" style={styles.icon_dots} />
                                        </TouchableOpacity>

                                        <TouchableOpacity onPress={() => {
                                            this.FuncGoToPageSearch();
                                        }} style={styles.button_search}>
                                            <AntDesign name="search1" style={styles.icon_search} />
                                        </TouchableOpacity>
                                    </Box>

                                    <Box style={styles.box_text_section_top_app}>
                                        <Text style={styles.text_section_top_app}>واتساپ</Text>
                                    </Box>
                                </Box>
                                {/* End Section Box Top */}

                                {/* Start Section Box Bottom */}
                                <Box name="Box_Bottom_App" style={styles.section_bottom_app}>
                                    <Box style={styles.box_icon_camera_section_bottom_app}>
                                        <TouchableOpacity onPress={() => {
                                            this.FuncSetCamera();
                                            this.FuncCloseMenu();
                                        }} style={styles.button_camera}>
                                            <Entypo name="camera" style={styles.icon_camera_section_bottom_app} />
                                        </TouchableOpacity>
                                    </Box>

                                    <Box style={styles.box_text_contacts_section_bottom_app}>
                                        <TouchableOpacity onPress={() => {
                                            this.FuncSetContacts();
                                            this.FuncCloseMenu();
                                        }} style={styles.button_contacts}>
                                            <Text style={styles.text_contacts_section_bottom_app}>گفتگو</Text>
                                        </TouchableOpacity >
                                    </Box>

                                    <Box style={styles.box_text_status_section_bottom_app}>
                                        <TouchableOpacity onPress={() => {
                                            this.FuncSetStatus();
                                            this.FuncCloseMenu();
                                        }} style={styles.button_status}>
                                            <Text style={styles.text_status_section_bottom_app}>وضعیت</Text>
                                        </TouchableOpacity>
                                    </Box>

                                    <Box style={styles.box_text_calls_section_bottom_app}>
                                        <TouchableOpacity onPress={() => {
                                            this.FuncSetCalls();
                                            this.FuncCloseMenu();
                                        }} style={styles.button_calls}>
                                            <Text style={styles.text_calls_section_bottom_app}>تماس ها</Text>
                                        </TouchableOpacity>
                                    </Box>
                                </Box>
                                {/* End Section Box Bottom */}
                            </Box>
                            {/* End Section Header */}

                            {/* Start Section Content */}
                            <Box name="Content" style={styles.content}>
                                {
                                    this.state.StateArchive === false ?
                                        null
                                        :
                                        <TouchableOpacity
                                            name="Box_Archive"
                                            style={styles.box_archive}
                                            onPress={() => {
                                                this.FuncGoToPageArchive();
                                            }}                                        >
                                            <Ionicons name="archive-outline" style={styles.icon_archive} />

                                            <Text style={styles.text_archive}>بایگانی شده</Text>
                                        </TouchableOpacity>
                                }

                                <Box name="Box_Flat_List" style={styles.box_flat_list}>
                                    <FlatList data={this.state.data} renderItem={({ item }) => (
                                        <SingleContacts
                                            navigation={this.props.navigation}
                                            ImageProfile={item.ImageProfile}
                                            NameChat={item.NameChat}
                                            TimeLastMessage={item.TimeLastMessage}
                                            LastMessages={item.LastMessages}
                                            StateChat={item.StateChat} />
                                    )} />
                                </Box>

                                <Box name="Footer_Content" style={styles.footer_content}>
                                    <TouchableOpacity
                                        onPress={() => {
                                            this.FuncGoToPageSelectContacts();
                                        }}
                                        style={styles.button_select_contacts}>
                                        <MaterialIcons name="chat" style={styles.icon_chat} />
                                    </TouchableOpacity>
                                </Box>
                            </Box>
                            {/* End Section Content */}
                        </Box>
                    </TouchableOpacity>
                    {/* End Section App */}

                    {/* Start Section Menu Contacts */}
                    <Box name="Menu_Contacts" style={styles.menu_contacts} left={this.state.PositionMenuContacts}>
                        <TouchableOpacity onPress={() => {
                            this.FuncCloseMenu();
                            this.FuncGoToPageAddNewGroup();
                        }}>
                            <Box name="Menu_Item" style={styles.menu_item_contacts}>
                                <Text style={styles.text_menu_item_contacts}>گروه جدید</Text>
                            </Box>
                        </TouchableOpacity>

                        <TouchableOpacity onPress={() => {
                            this.FuncCloseMenu();
                            this.FuncGoToPageNewReleaseList();
                        }}>
                            <Box name="Menu_Item" style={styles.menu_item_contacts}>
                                <Text style={styles.text_menu_item_contacts}>لیست انتشار جدید</Text>
                            </Box>
                        </TouchableOpacity>

                        <TouchableOpacity onPress={() => {
                            this.FuncCloseMenu();
                            this.FuncGoToPageConnectedDevices();
                        }}>
                            <Box name="Menu_Item" style={styles.menu_item_contacts}>
                                <Text style={styles.text_menu_item_contacts}>دستگاه های متصل</Text>
                            </Box>
                        </TouchableOpacity>

                        <TouchableOpacity onPress={() => {
                            this.FuncCloseMenu();
                            this.FuncGoToPageStarredMessages();
                        }}>
                            <Box name="Menu_Item" style={styles.menu_item_contacts}>
                                <Text style={styles.text_menu_item_contacts}>پیام های ستاره دار</Text>
                            </Box>
                        </TouchableOpacity>

                        <TouchableOpacity onPress={() => {
                            this.FuncCloseMenu();
                            this.FuncGoToPageSettings();
                        }}>
                            <Box name="Menu_Item" style={styles.menu_item_contacts}>
                                <Text style={styles.text_menu_item_contacts}>تنطیمات</Text>
                            </Box>
                        </TouchableOpacity>
                    </Box>
                    {/* End Section Menu Contacts */}
                </Box >
            </NativeBaseProvider >
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class