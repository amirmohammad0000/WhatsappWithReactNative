////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import { StyleSheet } from "react-native";
////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Style
const styles = StyleSheet.create({
    //////////////////////////////// Start Style App
    app: {
        width: "100%",
        height: "100%",
    },
    //////////////////////////////// End Style App

    //////////////////////////////// Start Style Header
    header: {
        width: "100%",
        height: "14%",
        backgroundColor: "#072",
    },
    //////////////////////////////// Start Style Box Top
    section_top_app: {
        width: "100%",
        height: "50%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "space-between",
    },

    box_icons_section_top_app: {
        width: "10%",
        height: "100%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "space-between",
    },

    button_menu: {
        width: "100%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 1000,
    },

    icon_dots: {
        color: "#eee",
        fontSize: 18,
    },

    button_search: {
        width: "100%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 1000,
    },

    icon_search: {
        color: "#eee",
        fontSize: 18,
    },

    box_text_section_top_app: {
        width: "90%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
    },

    text_section_top_app: {
        color: "#eee",
        fontSize: 20,
        paddingRight: 10,
    },
    //////////////////////////////// End Style Box Top

    //////////////////////////////// Start Style Box Bottom
    section_bottom_app: {
        width: "100%",
        height: "50%",
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
    },

    box_icon_camera_section_bottom_app: {
        width: "8%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    button_camera: {
        width: "100%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    icon_camera_section_bottom_app: {
        color: "#ddd",
        fontSize: 20,
    },

    box_text_contacts_section_bottom_app: {
        width: "31%",
        height: "100%",
        borderBottomColor: "#eee",
        borderBottomWidth: 3,
    },

    button_contacts: {
        width: "100%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    text_contacts_section_bottom_app: {
        color: "#ddd",
        fontSize: 18,
    },

    box_text_status_section_bottom_app: {
        width: "31%",
        height: "100%",
    },

    button_status: {
        width: "100%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    text_status_section_bottom_app: {
        color: "#ddd",
        fontSize: 18,
    },

    box_text_calls_section_bottom_app: {
        width: "31%",
        height: "100%",
    },

    button_calls: {
        width: "100%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    text_calls_section_bottom_app: {
        color: "#ddd",
        fontSize: 18,
    },
    //////////////////////////////// End Style Box Bottom
    //////////////////////////////// End Style Header

    //////////////////////////////// Start Style Content
    content: {
        width: "100%",
        height: "86%",
    },

    box_archive: {
        width: "100%",
        height: 50,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "flex-start",
    },

    icon_archive: {
        color: "#080",
        fontSize: 20,
        paddingRight: 30,
    },

    text_archive: {
        color: "#222",
        fontSize: 18,
        paddingRight: 30,
    },

    box_flat_list: {
        width: "100%",
        height: "80%",
    },

    footer_content: {
        width: "100%",
        height: "12%",
        position: "absolute",
        bottom: 0,
        alignItems: "flex-end",
        justifyContent: "flex-start",
        paddingRight: 20,
    },

    button_select_contacts: {
        width: "14%",
        height: "75%",
        borderRadius: 1000,
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "#082",
    },

    icon_chat: {
        color: "#eee",
        fontSize: 22,
    },
    //////////////////////////////// End Style Content

    /////////////////////////////// Start Section Menu Contacts
    menu_contacts: {
        position: "absolute",
        top: 0,
        width: "45%",
        height: "32%",
        backgroundColor: "#fff",
        borderRadius: 2,
    },

    menu_item_contacts: {
        width: "100%",
        height: 47,
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 20,
    },

    text_menu_item_contacts: {
        color: "#222",
        fontSize: 16,
    },
    /////////////////////////////// End Section Menu Contacts
});
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Style
export { styles };