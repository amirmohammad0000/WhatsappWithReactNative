﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity } from "react-native";
import { styles } from "./Css/CssConnectedDevices";
import { NativeBaseProvider, Box, Image, Text } from "native-base";
import { AntDesign } from "@expo/vector-icons";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class ConnectedDevices extends React.Component {
    FuncGoToPageContacts = () => {
        this.props.navigation.goBack();
    };

    FuncConnectDevice = () => {

    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <Box name="App" style={styles.app}>
                    <Box name="Header" style={styles.header}>
                        <Box />

                        <Box name="Box_Text_Header" style={styles.box_text_header}>
                            <Text style={styles.text_header}>دستگاه های متصل</Text>
                        </Box>

                        <TouchableOpacity
                            name="Box_Icon_Header"
                            style={styles.box_icon_header}
                            onPress={() => {
                                this.FuncGoToPageContacts();
                            }}>
                            <AntDesign name="arrowright" style={styles.icon_back} />
                        </TouchableOpacity>
                    </Box>

                    <Box name="Content" style={styles.content}>
                        <Box name="Box_Connect_Device" style={styles.box_connect_device}>
                            <Image alt="Image Device" source={require("./../../../../../Assets/Images/ImageDevice.png")} style={styles.image_device} />

                            <Text style={styles.text_use_whatsapp_in_device}>استفاده از واتساپ در سایر دستگاه</Text>

                            <TouchableOpacity style={styles.button_connect_device} onPress={() => {
                                this.FuncConnectDevice();
                            }}>
                                <Text style={styles.text_connect_device}>اتصال یک دستگاه</Text>
                            </TouchableOpacity>
                        </Box>
                    </Box>
                </Box>
                {/* End Section App */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class