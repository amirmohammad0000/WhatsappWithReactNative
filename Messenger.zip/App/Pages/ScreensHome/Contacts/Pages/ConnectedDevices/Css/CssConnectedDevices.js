/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import { StyleSheet } from "react-native";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Style
const styles = StyleSheet.create({
    //////////////////////////////// Start Style App
    app: {
        width: "100%",
        height: "100%",
    },
    //////////////////////////////// End Style App

    //////////////////////////////// Start Style Header
    header: {
        width: "100%",
        height: "8%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "flex-end",
        backgroundColor: "#072",
    },

    box_text_header: {
        width: "90%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 30,
    },

    text_header: {
        color: "#eee",
        fontSize: 18,
    },

    box_icon_header: {
        width: "10%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 20,
    },

    icon_back: {
        color: "#eee",
        fontSize: 22,
    },
    //////////////////////////////// End Style Header

    //////////////////////////////// Start Style Content
    content: {
        width: "100%",
        height: "92%",
    },

    box_connect_device: {
        width: "100%",
        height: "33%",
        alignItems: "center",
        justifyContent: "space-evenly",
        backgroundColor: "#fff",
        paddingTop: 5,
        paddingBottom: 5,
    },

    image_device: {
        width: "40%",
        height: "40%",
    },

    text_use_whatsapp_in_device: {
        color: "#222",
        fontSize: 30,
    },

    button_connect_device: {
        width: "90%",
        height: "18%",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "#185",
        borderRadius: 2,
    },

    text_connect_device: {
        color: "#eee",
        fontSize: 15,
    },
    //////////////////////////////// End Style Content
});
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Style
export { styles };