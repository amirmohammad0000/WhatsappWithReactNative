﻿//////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import ScreensContacts from "./Contacts/ScreensContacts";
import ScreensStatus from "./Status/ScreensStatus";
import ScreensCalls from "./Calls/ScreensCalls";
//////////////////////////////////////////////////////////////////////// End Section Import

const Stack = createNativeStackNavigator();

//////////////////////////////////////////////////////////////////////// Start Section Class
export default class ScreensHome extends React.Component {
    render() {
        return (
            <Stack.Navigator>
                <Stack.Screen
                    name="ScreensContacts"
                    component={ScreensContacts}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="ScreensStatus"
                    component={ScreensStatus}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="ScreensCalls"
                    component={ScreensCalls}
                    options={{
                        headerShown: false,
                    }}
                />
            </Stack.Navigator>
        );
    }
}
//////////////////////////////////////////////////////////////////////// End Section Class