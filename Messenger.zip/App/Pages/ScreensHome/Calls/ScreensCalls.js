//////////////////////////////////////////////////////////////////////// Start Section Import*/
import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import AppCallsPage from "./Pages/AppCallsPage/AppCallsPage";
import CallsWithContacts from "./Pages/CallsWithContacts/CallsWithContacts";
import SearchCalls from "./Pages/SearchCalls/SearchCalls";
import CallsDetails from "./Pages/CallsDetails/CallsDetails";
import ScreensSettings from "./../Contacts/Pages/Settings/ScreensSettings";
import SettingsInviteFriend from "./../Contacts/Pages/Settings/Pages/SettingsInviteFriend/SettingsInviteFriend";
import HelpForContacts from "./../Contacts/Pages/SelectContacts/Pages/HelpForContacts/HelpForContacts";
//////////////////////////////////////////////////////////////////////// End Section Import

const Stack = createNativeStackNavigator();

//////////////////////////////////////////////////////////////////////// Start Section Class
export default class Calls extends React.Component {
    render() {
        return (
            <Stack.Navigator>
                {/* Start Section Stack */}
                <Stack.Screen
                    name="AppCallsPage"
                    component={AppCallsPage}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="CallsWithContacts"
                    component={CallsWithContacts}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="SearchCalls"
                    component={SearchCalls}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="CallsDetails"
                    component={CallsDetails}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="ScreensSettings"
                    component={ScreensSettings}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="SettingsInviteFriend"
                    component={SettingsInviteFriend}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="HelpForContacts"
                    component={HelpForContacts}
                    options={{
                        headerShown: false,
                    }}
                />
                {/* End Section Stack */}
            </Stack.Navigator>
        );
    }
}
//////////////////////////////////////////////////////////////////////// End Section Class