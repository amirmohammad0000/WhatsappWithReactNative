﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity } from "react-native";
import { styles } from "./Css/CssCallsDetails";
import { NativeBaseProvider, Box, Text, Image } from "native-base";
import { AntDesign, Entypo, Ionicons, MaterialIcons, Foundation, Feather } from "@expo/vector-icons";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class CallsDetails extends React.Component {
    state = {
        NameUser: "Amir",
        BioUser: "Hello World",
        ImageProfileUser: require("./../../../../../Assets/Images/imagePerson3.png"),
        DateCall: "امروز",
        StateCall: "خروجی",
        TimeCall: "10.20",
        IconStateCall: "arrow-up-right",
        StateAnswerCall: "بدون پاسخ",
        PositionMenu: "100%",
    };

    FuncOpenMenu = () => {
        this.setState({
            PositionMenu: "55%",
        });
    };

    FuncCloseMenu = () => {
        this.setState({
            PositionMenu: "100%",
        });
    };

    FuncGoToPageChat = () => {
        this.props.navigation.navigate("ScreensUserChat");
    };

    FuncGoToPageAppCallsPage = () => {
        this.props.navigation.goBack();
    };

    FuncCallsVideo = () => {

    };

    FuncCalls = () => {

    };

    FuncOpenModalProfile = () => {

    };

    FuncDeleteFromListCalls = () => {

    };

    FuncBlock = () => {

    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <TouchableOpacity
                    onPress={() => {
                        this.FuncCloseMenu();
                    }}
                    activeOpacity={1}>
                    <Box name="App" style={styles.app} >
                        {/* Start Section Header */}
                        <Box name="Header" style={styles.header}>
                            <Box name="Box_Left" style={styles.box_left_header}>
                                <TouchableOpacity onPress={() => {
                                    this.FuncOpenMenu();
                                }} style={styles.button_icon_menu}>
                                    <Entypo name="dots-three-vertical" style={styles.icon_menu} />
                                </TouchableOpacity>

                                <TouchableOpacity onPress={() => {
                                    this.FuncGoToPageChat();
                                }} style={styles.button_icon_chat}>
                                    <MaterialIcons name="chat" style={styles.icon_chat} />
                                </TouchableOpacity>
                            </Box>

                            <Box name="Box_Right" style={styles.box_right_header}>
                                <Text style={styles.text_header}>جزئیات تماس</Text>

                                <TouchableOpacity onPress={() => {
                                    this.FuncGoToPageAppCallsPage();
                                }} style={styles.button_icon_arrow}>
                                    <AntDesign name="arrowright" style={styles.icon_arrow} />
                                </TouchableOpacity>
                            </Box>
                        </Box>
                        {/* End Section Header */}

                        {/* Start Section Content */}
                        <Box name="Content" style={styles.content}>
                            <Box name="Box_Header_Content" style={styles.box_header_content}>
                                <Box name="Box_left_Header_Content" style={styles.box_left_header_content}>
                                    <Box box="Box_Left_Inner_Header_Content" style={styles.box_left_inner_header_content}>
                                        <TouchableOpacity onPress={() => {
                                            this.FuncCallsVideo();
                                        }}>
                                            <Foundation name="video" style={styles.icon_video} />
                                        </TouchableOpacity>

                                        <TouchableOpacity onPress={() => {
                                            this.FuncCalls();
                                        }}>
                                            <Ionicons name="call" style={styles.icon_calls} />
                                        </TouchableOpacity>
                                    </Box>

                                    <Box box="Box_Right_Inner_Header_Content" style={styles.box_right_inner_header_content}>
                                        <Text style={styles.text_name_user}>{this.state.NameUser}</Text>

                                        <Text style={styles.text_bio_user}>{this.state.BioUser}</Text>
                                    </Box>
                                </Box>

                                <TouchableOpacity
                                    name="Box_Right_Header_Content"
                                    style={styles.box_right_header_content}
                                    onPress={() => {
                                        this.FuncOpenModalProfile();
                                    }}>
                                    <Image alt="Image_Profile" source={this.state.ImageProfileUser} style={styles.image_profile_user} />
                                </TouchableOpacity>
                            </Box>

                            <Box name="Box_Content_Content" style={styles.box_content_content}>
                                <Box name="Box_Date" style={styles.box_date_calls}>
                                    <Text style={styles.text_date_calls}>{this.state.DateCall}</Text>
                                </Box>

                                <Box name="Box_Status_Calls" style={styles.box_status_calls}>
                                    <Box name="Box_Left_Calls" style={styles.box_left_calls}>
                                        <Text style={styles.text_state_answer_calls}>{this.state.StateAnswerCall}</Text>
                                    </Box>

                                    <Box name="Box_State_Icon_Status_Calls" style={styles.box_state_icon_status_calls}>
                                        <Box name="Box_Right_Calls" style={styles.box_right_calls}>
                                            <Text style={styles.text_state_calls}>{this.state.StateCall}</Text>

                                            <Text style={styles.text_time_calls}>{this.state.TimeCall}</Text>
                                        </Box>

                                        <Box name="Box_Icon_Calls" style={styles.box_icon_calls}>
                                            <Feather name={this.state.IconStateCall} style={styles.icon_state_calls} />
                                        </Box>
                                    </Box>
                                </Box>
                            </Box>
                        </Box>
                        {/* End Section Content */}
                    </Box>
                </TouchableOpacity>
                {/* End Section App */}

                {/* Start Section Menu */}
                <Box name="Menu" style={styles.menu} left={this.state.PositionMenu}>
                    <TouchableOpacity onPress={() => {
                        this.FuncCloseMenu();
                        this.FuncDeleteFromListCalls();
                    }}>
                        <Box name="Menu_Item" style={styles.menu_item}>
                            <Text style={styles.text_menu_item}>حذف از لیست تماس</Text>
                        </Box>
                    </TouchableOpacity>

                    <TouchableOpacity onPress={() => {
                        this.FuncCloseMenu();
                        this.FuncBlock();
                    }}>
                        <Box name="Menu_Item" style={styles.menu_item}>
                            <Text style={styles.text_menu_item}>مسدود کردن</Text>
                        </Box>
                    </TouchableOpacity>
                </Box>
                {/* End Section Menu */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class