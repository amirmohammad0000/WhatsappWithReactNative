/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import { StyleSheet } from "react-native";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Style
const styles = StyleSheet.create({
    //////////////////////////////// Start Style App
    app: {
        width: "100%",
        height: "100%",
    },
    //////////////////////////////// End Style App

    //////////////////////////////// Start Style Header
    header: {
        width: "100%",
        height: "8%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "space-between",
        backgroundColor: "#072",
    },

    box_left_header: {
        width: "18%",
        height: "100%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "space-evenly",
    },

    button_icon_menu: {
        width: "50%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    icon_menu: {
        color: "#eee",
        fontSize: 18,
    },

    button_icon_chat: {
        width: "50%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    icon_chat: {
        color: "#eee",
        fontSize: 20,
    },

    box_right_header: {
        width: "45%",
        height: "100%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "space-evenly",
    },

    text_header: {
        color: "#eee",
        fontSize: 20,
    },

    button_icon_arrow: {
        width: "20%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
    },

    icon_arrow: {
        color: "#eee",
        fontSize: 22,
    },
    //////////////////////////////// End Style Header

    //////////////////////////////// Start Style Content
    content: {
        width: "100%",
        height: "92%",
    },

    box_header_content: {
        width: "100%",
        height: "10%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "center",
    },

    box_left_header_content: {
        width: "85%",
        height: "100%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "space-between",
        borderBottomColor: "#aaa",
        borderBottomWidth: 1,
    },

    box_left_inner_header_content: {
        width: "30%",
        height: "100%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "space-around",
    },

    icon_video: {
        color: "#195",
        fontSize: 22,
    },

    icon_calls: {
        color: "#195",
        fontSize: 22,
    },

    box_right_inner_header_content: {
        width: "30%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
    },

    text_name_user: {
        color: "#222",
        fontWeight: "bold",
        fontSize: 18,
    },

    text_bio_user: {
        color: "#666",
        fontSize: 15,
    },

    box_right_header_content: {
        width: "15%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    image_profile_user: {
        width: "70%",
        height: "70%",
        borderRadius: 1000,
        borderBottomColor: "#aaa",
        borderBottomWidth: 1,
    },

    box_content_content: {
        width: "100%",
        height: "90%",
    },

    box_date_calls: {
        width: "100%",
        height: "6%",
        alignItems: "flex-start",
        justifyContent: "flex-start",
        paddingLeft: 70,
        paddingTop: 5,
    },

    text_date_calls: {
        color: "#888",
        fontSize: 15,
    },

    box_status_calls: {
        width: "100%",
        height: 50,
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "space-between",
    },

    box_left_calls: {
        width: "30%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    text_state_answer_calls: {
        color: "#777",
        fontSize: 16,
    },

    box_state_icon_status_calls: {
        width: "30%",
        height: "100%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "space-evenly",
    },

    box_right_calls: {
        width: "50%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
    },

    text_state_calls: {
        color: "#000",
        fontWeight: "900",
        fontSize: 18,
    },

    text_time_calls: {
        color: "#555",
        fontSize: 12,
    },

    box_icon_calls: {
        width: "50%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    icon_state_calls: {
        color: "#082",
        fontSize: 25,
    },
    //////////////////////////////// End Style Content

    //////////////////////////////// Start Style Menu
    menu: {
        position: "absolute",
        top: 0,
        width: "45%",
        height: "13%",
        backgroundColor: "#fff",
        borderRadius: 2,
    },

    menu_item: {
        width: "100%",
        height: 47,
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 20,
    },

    text_menu_item: {
        color: "#222",
        fontSize: 16,
    },
    //////////////////////////////// End Style Menu
});
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Style
export { styles };