﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity, FlatList } from "react-native";
import { styles } from "./Css/CssSearchCalls";
import { NativeBaseProvider, Box, Input, Text } from "native-base";
import { MaterialIcons, FontAwesome, AntDesign } from "@expo/vector-icons";
import SingleCalls from "./../AppCallsPage/Components/SingleCalls";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class SearchCalls extends React.Component {
    state = {
        data: [
            { id: "1", ImageProfile: require("./../../../../../Assets/Images/imagePerson1.png"), NameUser: "Ali", TimeCalls: "5 دقیقه پیش", IconStateCalls: "arrow-up-right" },
            { id: "2", ImageProfile: require("./../../../../../Assets/Images/imagePerson2.png"), NameUser: "Mohammad", TimeCalls: "20 دقیقه پیش", IconStateCalls: "arrow-up-right" },
        ],
        ValueInputSearch: "",
    };

    FuncGoToPageCallsDetails = () => {
        this.props.navigation.navigate("CallsDetails");
    };

    FuncGoToPageCallsWithContacts = () => {
        this.props.navigation.navigate("CallsWithContacts");
    };

    FuncGoToPageAppCallsPage = () => {
        this.props.navigation.goBack();
    };

    FuncSetValueInputSearch = (text) => {
        this.setState({
            ValueInputSearch: text,
        });
    };

    FuncRemoveValue = () => {
        this.setState({
            ValueInputSearch: "",
        });
    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <Box name="App" style={styles.app}>
                    {/* Start Section Header */}
                    <Box nmae="Header" style={styles.header}>
                        <TouchableOpacity onPress={() => {
                            this.FuncGoToPageAppCallsPage();
                        }}>
                            <AntDesign name="arrowright" style={styles.icon_back} />
                        </TouchableOpacity>

                        <Input
                            placeholder="جستجو ..."
                            variant="ghost"
                            width="80%"
                            height="100%"
                            autoFocus={true}
                            fontWeight="bold"
                            value={this.state.ValueInputSearch}
                            onChangeText={(text) => {
                                this.FuncSetValueInputSearch(text);
                            }}
                        />

                        <TouchableOpacity onPress={() => {
                            this.FuncRemoveValue();
                        }}>
                            <FontAwesome name="remove" style={styles.icon_delete} />
                        </TouchableOpacity>
                    </Box>
                    {/* End Section Header */}

                    {/* Start Section Content */}
                    <Box name="Content" style={styles.content}>
                        <Box name="Box_View_Calls" style={styles.box_view_calls}>
                            {
                                this.state.data !== ""
                                    ?
                                    <FlatList data={this.state.data} renderItem={({ item }) => (
                                        <TouchableOpacity onPress={() => {
                                            this.FuncGoToPageCallsDetails();
                                        }} style={styles.button_calls_single_calls}>
                                            <SingleCalls
                                                ImageProfile={item.ImageProfile}
                                                NameUser={item.NameUser}
                                                TimeCalls={item.TimeCalls}
                                                IconStateCalls={item.IconStateCalls} />
                                        </TouchableOpacity>
                                    )} />
                                    :
                                    <Box style={styles.box_text_center_page}>
                                        <Text style={styles.text_center_page}>برای اغاز تماس با مخاطبینی که واتساپ دارند, در پایین صفحه ضربه بزنید</Text>
                                    </Box>
                            }
                        </Box>

                        <Box name="Box_Select_Contacts" style={styles.box_select_contacts}>
                            <TouchableOpacity style={styles.button_select_contacts} onPress={() => {
                                this.FuncGoToPageCallsWithContacts();
                            }}>
                                <MaterialIcons name="add-call" style={styles.icon_calls} />
                            </TouchableOpacity>
                        </Box>
                    </Box>
                    {/* End Section Content */}
                </Box>
                {/* End Section App */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class