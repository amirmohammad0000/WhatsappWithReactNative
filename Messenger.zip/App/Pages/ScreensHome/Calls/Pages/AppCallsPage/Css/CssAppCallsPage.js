/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import { StyleSheet } from "react-native";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Style
const styles = StyleSheet.create({
    //////////////////////////////// Start Style App
    app: {
        width: "100%",
        height: "100%",
    },
    //////////////////////////////// End Style App

    //////////////////////////////// Start Style Header
    header: {
        width: "100%",
        height: "14%",
        backgroundColor: "#072",
    },
    //////////////////////////////// Start Style Box Top
    section_top_app: {
        width: "100%",
        height: "50%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "space-between",
    },

    box_icons_section_top_app: {
        width: "10%",
        height: "100%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "space-between",
    },

    button_menu: {
        width: "100%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 1000,
    },

    icon_dots: {
        color: "#eee",
        fontSize: 18,
    },

    button_search: {
        width: "100%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 1000,
    },

    icon_search: {
        color: "#eee",
        fontSize: 18,
    },

    box_text_section_top_app: {
        width: "90%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
    },

    text_section_top_app: {
        color: "#eee",
        fontSize: 20,
        paddingRight: 10,
    },
    //////////////////////////////// End Style Box Top

    //////////////////////////////// Start Style Box Bottom
    section_bottom_app: {
        width: "100%",
        height: "50%",
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
    },

    box_icon_camera_section_bottom_app: {
        width: "8%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    button_camera: {
        width: "100%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    icon_camera_section_bottom_app: {
        color: "#ddd",
        fontSize: 20,
    },

    box_text_contacts_section_bottom_app: {
        width: "31%",
        height: "100%",
    },

    button_contacts: {
        width: "100%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    text_contacts_section_bottom_app: {
        color: "#ddd",
        fontSize: 18,
    },

    box_text_status_section_bottom_app: {
        width: "31%",
        height: "100%",
    },

    button_status: {
        width: "100%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    text_status_section_bottom_app: {
        color: "#ddd",
        fontSize: 18,
    },

    box_text_calls_section_bottom_app: {
        width: "31%",
        height: "100%",
        borderBottomColor: "#eee",
        borderBottomWidth: 3,
    },

    button_calls: {
        width: "100%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    text_calls_section_bottom_app: {
        color: "#ddd",
        fontSize: 18,
    },
    //////////////////////////////// End Style Box Bottom
    //////////////////////////////// End Style Header

    //////////////////////////////// Start Style Content
    content: {
        width: "100%",
        height: "86%",
    },
    //////////////////////////////// End Style Content

    /////////////////////////////// Start Section Menu Calls
    menu_calls: {
        position: "absolute",
        top: 0,
        width: "45%",
        height: "7%",
        backgroundColor: "#fff",
        borderRadius: 2,
    },

    menu_item_calls: {
        width: "100%",
        height: 47,
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 20,
    },

    text_menu_item_calls: {
        color: "#222",
        fontSize: 16,
    },
    /////////////////////////////// End Section Menu Calls

    //////////////////////////////// Start Style Box View Calls
    box_view_calls: {
        width: "100%",
        height: "88%",
    },

    button_calls_single_calls: {
        width: "100%",
        height: 80,
    },

    box_text_center_page: {
        width: "100%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    text_center_page: {
        fontSize: 18,
        textAlign: "center",
        color: "#222",
        padding: 10,
    },

    box_select_contacts: {
        width: "100%",
        height: "12%",
        alignItems: "flex-end",
        justifyContent: "flex-start",
        paddingRight: 15,
        paddingTop: 5,
    },

    button_select_contacts: {
        width: 60,
        height: 60,
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "#094",
        borderRadius: 1000,
    },

    icon_calls: {
        fontSize: 24,
        color: "#fff",
    },
    //////////////////////////////// End Style Box View Calls
});
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Style
export { styles };