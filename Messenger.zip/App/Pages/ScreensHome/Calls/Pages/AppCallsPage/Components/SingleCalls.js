﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity } from "react-native";
import { styles } from "./Css/CssSingleCalls";
import { NativeBaseProvider, Box, Image, Text } from "native-base";
import { MaterialIcons, Feather } from "@expo/vector-icons";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class SingleCalls extends React.Component {
    FuncCallWithUser = () => {

    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <Box name="App" style={styles.app}>
                    <Box name="Box_Main_Item" style={styles.box_main_item}>
                        <Box name="Box_Right" style={styles.box_right}>
                            <TouchableOpacity style={styles.button_calls} onPress={() => {
                                this.FuncCallWithUser();
                            }}>
                                <MaterialIcons name="call" style={styles.icon_calls} />
                            </TouchableOpacity>
                        </Box>

                        <Box name="Box_Left" style={styles.box_left}>
                            <TouchableOpacity name="Box_Image_Profile" style={styles.box_image_profile}>
                                <Image source={this.props.ImageProfile} style={styles.image_profile} alt="Image Profile" />
                            </TouchableOpacity>

                            <Box name="Box_State_Calls" style={styles.box_text_state_calls}>
                                <Text style={styles.text_name_user}>{this.props.NameUser}</Text>

                                <Box name="Box_Icon_Text" style={styles.box_icon_text}>
                                    <Feather name={this.props.IconStateCalls} style={styles.icon_state_calls} />
                                    <Text style={styles.text_time_calls}>{this.props.TimeCalls}</Text>
                                </Box>
                            </Box>
                        </Box>
                    </Box>
                </Box>
                {/* End Section App */}
            </NativeBaseProvider >
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class