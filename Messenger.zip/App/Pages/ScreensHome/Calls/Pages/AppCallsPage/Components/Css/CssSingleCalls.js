/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import { StyleSheet } from "react-native";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Style
const styles = StyleSheet.create({
    //////////////////////////////// Start Style App
    app: {
        width: "100%",
        height: "100%",
    },

    box_main_item: {
        width: "100%",
        height: 80,
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "center",
    },

    box_right: {
        width: "15%",
        height: "100%",
    },

    button_calls: {
        width: "100%",
        height: "100%",
        alignItems: "flex-end",
        justifyContent: "center",
        padding: 15,
    },

    icon_calls: {
        color: "#094",
        fontSize: 22,
    },

    box_left: {
        width: "85%",
        height: "100%",
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center",
    },

    box_image_profile: {
        width: "20%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    image_profile: {
        width: "80%",
        height: "80%",
        borderRadius: 1000,
    },

    box_text_state_calls: {
        width: "80%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 8,
    },

    text_name_user: {
        width: "100%",
        height: "50%",
        color: "#222",
        fontSize: 18,
        fontWeight: "bold",
        textAlign: "left",
        paddingTop: 15,
    },

    box_icon_text: {
        width: "100%",
        height: "50%",
        flexDirection: "row",
        alignItems: "flex-start",
        justifyContent: "flex-start",
    },

    icon_state_calls: {
        color: "#094",
        fontSize: 15,
    },

    text_time_calls: {
        color: "#555",
        fontSize: 14,
        paddingRight: 10,
    },
    //////////////////////////////// End Style App
});
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Style
export { styles };