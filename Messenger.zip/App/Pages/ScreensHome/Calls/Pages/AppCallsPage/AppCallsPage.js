﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity, FlatList } from "react-native";
import { styles } from "./Css/CssAppCallsPage";
import { NativeBaseProvider, Box, Text } from "native-base";
import { MaterialIcons, Entypo, AntDesign } from "@expo/vector-icons";
import { launchCamera } from "react-native-image-picker";
import SingleCalls from "./Components/SingleCalls";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class AppCallsPage extends React.Component {
    state = {
        data: [
            { id: "1", ImageProfile: require("./../../../../../Assets/Images/imagePerson1.png"), NameUser: "Ali", TimeCalls: "5 دقیقه پیش", IconStateCalls: "arrow-up-right" },
            { id: "2", ImageProfile: require("./../../../../../Assets/Images/imagePerson2.png"), NameUser: "Mohammad", TimeCalls: "20 دقیقه پیش", IconStateCalls: "arrow-up-right" },
        ],
        PositionMenuCalls: "100%",
    };

    FuncSetCamera = () => {
        launchCamera({}, () => {

        });
    };

    FuncOpenMenu = () => {
        this.setState({
            PositionMenuCalls: "55%",
        });
    };

    FuncCloseMenu = () => {
        this.setState({
            PositionMenuCalls: "100%",
        });
    };

    FuncGoToPageSearch = () => {
        this.props.navigation.navigate("SearchCalls");
    };

    FuncSetContacts = () => {
        this.props.navigation.navigate("ScreensContacts");
    };

    FuncSetStatus = () => {
        this.props.navigation.navigate("ScreensStatus");
    };

    FuncSetCalls = () => {
        this.props.navigation.navigate("ScreensCalls");
    };

    FuncGoToPageSettings = () => {
        this.props.navigation.navigate("ScreensSettings");
    };

    FuncGoToPageCallsDetails = () => {
        this.props.navigation.navigate("CallsDetails");
    };

    FuncGoToPageCallsWithContacts = () => {
        this.props.navigation.navigate("CallsWithContacts");
    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <TouchableOpacity activeOpacity={1} onPress={() => {
                    this.FuncCloseMenu();
                }}>
                    <Box name="App" style={styles.app}>
                        {/* Start Section Header */}
                        <Box name="Header" style={styles.header}>
                            {/* Start Section Box Top */}
                            <Box name="Box_Top_App" style={styles.section_top_app}>
                                <Box name="Box_Icons" style={styles.box_icons_section_top_app}>
                                    <TouchableOpacity onPress={() => {
                                        this.FuncOpenMenu();
                                    }} style={styles.button_menu}>
                                        <Entypo name="dots-three-vertical" style={styles.icon_dots} />
                                    </TouchableOpacity>

                                    <TouchableOpacity onPress={() => {
                                        this.FuncGoToPageSearch();
                                    }} style={styles.button_search}>
                                        <AntDesign name="search1" style={styles.icon_search} />
                                    </TouchableOpacity>
                                </Box>

                                <Box style={styles.box_text_section_top_app}>
                                    <Text style={styles.text_section_top_app}>واتساپ</Text>
                                </Box>
                            </Box>
                            {/* End Section Box Top */}

                            {/* Start Section Box Bottom */}
                            <Box name="Box_Bottom_App" style={styles.section_bottom_app}>
                                <Box style={styles.box_icon_camera_section_bottom_app}>
                                    <TouchableOpacity onPress={() => {
                                        this.FuncSetCamera();
                                        this.FuncCloseMenu();
                                    }} style={styles.button_camera}>
                                        <Entypo name="camera" style={styles.icon_camera_section_bottom_app} />
                                    </TouchableOpacity>
                                </Box>

                                <Box style={styles.box_text_contacts_section_bottom_app}>
                                    <TouchableOpacity onPress={() => {
                                        this.FuncSetContacts();
                                        this.FuncCloseMenu();
                                    }} style={styles.button_contacts}>
                                        <Text style={styles.text_contacts_section_bottom_app}>گفتگو</Text>
                                    </TouchableOpacity >
                                </Box>

                                <Box style={styles.box_text_status_section_bottom_app}>
                                    <TouchableOpacity onPress={() => {
                                        this.FuncSetStatus();
                                        this.FuncCloseMenu();
                                    }} style={styles.button_status}>
                                        <Text style={styles.text_status_section_bottom_app}>وضعیت</Text>
                                    </TouchableOpacity>
                                </Box>

                                <Box style={styles.box_text_calls_section_bottom_app}>
                                    <TouchableOpacity onPress={() => {
                                        this.FuncSetCalls();
                                        this.FuncCloseMenu();
                                    }} style={styles.button_calls}>
                                        <Text style={styles.text_calls_section_bottom_app}>تماس ها</Text>
                                    </TouchableOpacity>
                                </Box>
                            </Box>
                            {/* End Section Box Bottom */}
                        </Box>
                        {/* End Section Header */}

                        {/* Start Section Content */}
                        <Box name="Content" style={styles.content}>
                            <Box name="Box_View_Calls" style={styles.box_view_calls}>
                                {
                                    this.state.data !== ""
                                        ?
                                        <FlatList data={this.state.data} renderItem={({ item }) => (
                                            <TouchableOpacity onPress={() => {
                                                this.FuncGoToPageCallsDetails();
                                            }} style={styles.button_calls_single_calls}>
                                                <SingleCalls
                                                    ImageProfile={item.ImageProfile}
                                                    NameUser={item.NameUser}
                                                    TimeCalls={item.TimeCalls}
                                                    IconStateCalls={item.IconStateCalls} />
                                            </TouchableOpacity>
                                        )} />
                                        :
                                        <Box style={styles.box_text_center_page}>
                                            <Text style={styles.text_center_page}>برای اغاز تماس با مخاطبینی که واتساپ دارند, در پایین صفحه ضربه بزنید</Text>
                                        </Box>
                                }
                            </Box>

                            <Box name="Box_Select_Contacts" style={styles.box_select_contacts}>
                                <TouchableOpacity style={styles.button_select_contacts} onPress={() => {
                                    this.FuncGoToPageCallsWithContacts();
                                }}>
                                    <MaterialIcons name="add-call" style={styles.icon_calls} />
                                </TouchableOpacity>
                            </Box>
                        </Box>
                        {/* End Section Content */}
                    </Box>
                </TouchableOpacity>
                {/* End Section App */}

                {/* Start Section Menu Calls */}
                <Box name="Menu_Calls" style={styles.menu_calls} left={this.state.PositionMenuCalls}>
                    <TouchableOpacity onPress={() => {
                        this.FuncCloseMenu();
                        this.FuncGoToPageSettings();
                    }}>
                        <Box name="Menu_Item" style={styles.menu_item_calls}>
                            <Text style={styles.text_menu_item_calls}>تنظیمات</Text>
                        </Box>
                    </TouchableOpacity>
                </Box>
                {/* End Section Menu Calls */}
                {/* End Section App */}
            </NativeBaseProvider >
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class