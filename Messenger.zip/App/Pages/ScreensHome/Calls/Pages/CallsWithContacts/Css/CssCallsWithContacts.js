/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import { StyleSheet } from "react-native";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Style
const styles = StyleSheet.create({
    //////////////////////////////// Start Style App
    app: {
        width: "100%",
        height: "100%",
    },
    //////////////////////////////// End Style App

    //////////////////////////////// Start Style Header
    header: {
        width: "100%",
        height: 62,
        backgroundColor: "#082",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "space-between",
    },

    box_left_header: {
        width: "20%",
        height: "100%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "space-evenly",
    },

    button_menu: {
        width: "50%",
        height: "100%",
        alignItems: "flex-end",
        paddingRight: 10,
        justifyContent: "center",
    },

    icon_menu: {
        color: "#eee",
        fontSize: 20,
    },

    button_search: {
        width: "50%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    icon_search: {
        color: "#eee",
        fontSize: 25,
    },

    box_right_header: {
        width: "45%",
        height: "100%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "space-around",
    },

    box_left_inner_header: {
        width: "65%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
    },

    text_header_contacts: {
        color: "#eee",
        fontSize: 17,
        fontWeight: "bold",
    },

    text_header_number_contacts: {
        color: "#eee",
        fontSize: 14,
    },

    box_right_inner_header: {
        width: "35%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
    },

    button_back: {
        width: "80%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    icon_arrow: {
        color: "#eee",
        fontSize: 20,
    },
    //////////////////////////////// End Style Header

    //////////////////////////////// Start Style Content
    content: {
        width: "100%",
        height: "74%",
    },

    box_calls_group_content: {
        width: "100%",
        height: "12%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "flex-end",
    },

    text_group_content: {
        color: "#222",
        fontSize: 18,
    },

    box_image_group_content: {
        width: "15%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    image_group_content: {
        width: "100%",
        height: "100%",
        borderRadius: 1000,
    },

    box_new_contacts: {
        width: "100%",
        height: "12%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "flex-end",
    },

    text_new_contacts: {
        color: "#222",
        fontSize: 18,
    },

    box_image_new_contacts: {
        width: "15%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    image_new_contacts: {
        width: "60%",
        height: "60%",
        borderRadius: 1000,
    },

    box_flat_list: {
        width: "100%",
        height: "76%",
    },
    //////////////////////////////// End Style Content

    //////////////////////////////// Start Style Footer
    footer: {
        width: "100%",
        height: 140,
        position: "absolute",
        bottom: 0,
    },

    box_one_footer: {
        width: "100%",
        height: "50%",
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "flex-start",
    },

    icon_invite_friends: {
        color: "#999",
        fontSize: 20,
        paddingRight: 20,
    },

    text_invite_friends: {
        color: "#222",
        fontSize: 18,
        paddingRight: 30,
    },

    box_two_footer: {
        width: "100%",
        height: "50%",
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "flex-start",
    },

    icon_help_fot_contacts: {
        color: "#999",
        fontSize: 20,
        paddingRight: 20,
    },

    text_help_fot_contacts: {
        color: "#222",
        fontSize: 18,
        paddingRight: 30,
    },
    //////////////////////////////// End Style Footer

    /////////////////////////////// Start Section Menu
    menu: {
        position: "absolute",
        top: 0,
        width: "45%",
        height: "24%",
        backgroundColor: "#fff",
        borderRadius: 2,
    },

    menu_item: {
        width: "100%",
        height: 47,
        alignItems: "flex-start",
        justifyContent: "center",
        paddingLeft: 20,
    },

    text_menu_item: {
        color: "#222",
        fontSize: 16,
    },
    /////////////////////////////// End Section Menu

    /////////////////////////////// Start Section Search Box
    header_search: {
        width: "100%",
        position: "absolute",
        top: 0,
        height: 62,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-evenly",
        backgroundColor: "#fff",
    },

    icon_delete: {
        color: "#777",
        fontSize: 25,
    },

    icon_back: {
        color: "#777",
        fontSize: 25,
    },
    /////////////////////////////// End Section Search Box
});
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Style
export { styles };