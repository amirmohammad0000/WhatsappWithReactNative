﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity } from "react-native";
import { styles } from "./Css/CssSingleContacts";
import { Ionicons, FontAwesome5 } from "@expo/vector-icons";
import { NativeBaseProvider, Box, Image, Text } from "native-base";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class SingleContacts extends React.Component {
    FuncViewProfile = () => {

    };

    FuncVideo = () => {

    };

    FuncCalls = () => {

    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <Box name="App" style={styles.app}>
                    <Box name="Box_Item_Single_Contacts" style={styles.box_item_single_contacts}>
                        <Box name="Box_Image_UserNmae" style={styles.box_image_usernmae}>
                            <TouchableOpacity
                                name="Box_Image"
                                style={styles.box_image}
                                onPress={() => {
                                    this.FuncViewProfile();
                                }}>
                                <Image alt="Image" source={this.props.ImageProfile} style={styles.image_profile} />
                            </TouchableOpacity>

                            <Box name="Box_Text" style={styles.box_text}>
                                <Text style={styles.text_user_name}>{this.props.UserName}</Text>

                                <Text style={styles.text_bio_user}>{this.props.BioUser}</Text>
                            </Box>
                        </Box>

                        <Box name="Box_Icon" style={styles.box_icon}>
                            <TouchableOpacity onPress={() => {
                                this.FuncVideo();
                            }}>
                                <FontAwesome5 name="video" style={styles.icon_video} />
                            </TouchableOpacity>

                            <TouchableOpacity onPress={() => {
                                this.FuncCalls();
                            }}>
                                <Ionicons name="call" style={styles.icon_calls} />
                            </TouchableOpacity>
                        </Box>
                    </Box>
                </Box>
                {/* End Section App */}
            </NativeBaseProvider >
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class