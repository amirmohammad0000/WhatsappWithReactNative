/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import { StyleSheet } from "react-native";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Style
const styles = StyleSheet.create({
    //////////////////////////////// Start Style App
    app: {
        width: "100%",
        height: "100%",
    },

    box_item_single_contacts: {
        width: "100%",
        height: 60,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
    },

    box_image_usernmae: {
        width: "50%",
        height: "100%",
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center",
    },

    box_image: {
        width: "40%",
        height: "100%",
        alignItems: "flex-end",
        justifyContent: "center",
        paddingRight: 20,
    },

    image_profile: {
        width: "60%",
        height: "70%",
        borderRadius: 1000,
    },

    box_text: {
        width: "60%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
    },

    text_user_name: {
        color: "#555",
        fontSize: 17,
        fontWeight: "bold",
    },

    text_bio_user: {
        color: "#777",
        fontSize: 14,
    },

    box_icon: {
        width: "50%",
        height: "100%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "flex-start",
    },

    icon_video: {
        color: "#082",
        fontSize: 20,
        paddingLeft: 20,
    },

    icon_calls: {
        color: "#082",
        fontSize: 20,
        paddingLeft: 20,
    },
    //////////////////////////////// End Style App
});
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Style
export { styles };