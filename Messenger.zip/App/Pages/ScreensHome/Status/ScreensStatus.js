//////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import AppStatusPage from "./Pages/AppStatusPage/AppStatusPage";
import SearchStatus from "./Pages/SearchStatus/SearchStatus";
import WriteStatus from "./Pages/WriteStatus/WriteStatus";
import SettingsStatusSettings from "./../Contacts/Pages/Settings/Pages/SettingsAccount/Pages/SettingsPrivacy/Pages/SettingsStatusSettings/SettingsStatusSettings";
import ScreensSettings from "./../Contacts/Pages/Settings/ScreensSettings";
//////////////////////////////////////////////////////////////////////// End Section Import

const Stack = createNativeStackNavigator();

//////////////////////////////////////////////////////////////////////// Start Section Class
export default class Status extends React.Component {
    render() {
        return (
            <Stack.Navigator>
                {/* Start Section Stack */}
                <Stack.Screen
                    name="AppStatusPage"
                    component={AppStatusPage}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="SearchStatus"
                    component={SearchStatus}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="WriteStatus"
                    component={WriteStatus}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="SettingsStatusSettings"
                    component={SettingsStatusSettings}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="ScreensSettings"
                    component={ScreensSettings}
                    options={{
                        headerShown: false,
                    }}
                />
                {/* End Section Stack */}
            </Stack.Navigator>
        );
    }
}
//////////////////////////////////////////////////////////////////////// End Section Class