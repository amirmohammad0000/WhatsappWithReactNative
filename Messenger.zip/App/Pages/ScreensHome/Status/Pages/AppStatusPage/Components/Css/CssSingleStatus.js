/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import { StyleSheet } from "react-native";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Style
const styles = StyleSheet.create({
    //////////////////////////////// Start Style App
    app: {
        width: "100%",
        height: "100%",
    },

    box_item_status: {
        width: "100%",
        height: 80,
        flexDirection: "row",
        alignItems: "flex-start",
        justifyContent: "center",
    },

    box_image_status: {
        width: "20%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    image_status: {
        width: "62%",
        height: "70%",
        borderRadius: 1000,
    },

    box_text: {
        width: "80%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
    },

    text_name_user: {
        color: "#000",
        fontSize: 18,
        fontWeight: "bold",
    },

    text_time_status: {
        color: "#555",
        fontSize: 14,
    },
    //////////////////////////////// End Style App
});
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Style
export { styles };