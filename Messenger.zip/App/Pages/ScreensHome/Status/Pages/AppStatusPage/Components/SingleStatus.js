﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity } from "react-native";
import { styles } from "./Css/CssSingleStatus";
import { NativeBaseProvider, Box, Image, Text } from "native-base";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class SingleStatus extends React.Component {
    FuncViewStatusUser = () => {

    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <Box name="App" style={styles.app}>
                    <TouchableOpacity onPress={() => {
                        this.FuncViewStatusUser();
                    }}>
                        <Box name="Box_Item_Status" style={styles.box_item_status}>
                            <Box name="Box_Image_Status" style={styles.box_image_status}>
                                <Image alt="Image Status" source={this.props.ImageStatus} style={styles.image_status} />
                            </Box>

                            <Box name="Box_Text" style={styles.box_text}>
                                <Text style={styles.text_name_user}>{this.props.NameUser}</Text>

                                <Text style={styles.text_time_status}>{this.props.TimeStatus}</Text>
                            </Box>
                        </Box>
                    </TouchableOpacity>
                </Box>
                {/* End Section App */}
            </NativeBaseProvider >
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class