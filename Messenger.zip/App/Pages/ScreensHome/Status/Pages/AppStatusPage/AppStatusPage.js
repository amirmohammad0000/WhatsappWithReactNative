﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { FlatList, TouchableOpacity } from "react-native";
import { styles } from "./Css/CssAppStatusPage";
import { NativeBaseProvider, Box, Image, Text } from "native-base";
import { launchCamera } from "react-native-image-picker";
import { Entypo, AntDesign, FontAwesome5 } from "@expo/vector-icons";
import SingleStatus from "./Components/SingleStatus";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class AppStatusPage extends React.Component {
    state = {
        PositionMenuStatus: "100%",
        data: [
            { id: "1", ImageStatus: require("./../../../../../Assets/Images/imagePerson4.png"), NameUser: "Amir", TimeStatus: "امروز 11.03" },
            { id: "2", ImageStatus: require("./../../../../../Assets/Images/imagePerson5.png"), NameUser: "Hossein", TimeStatus: "امروز 13.53" },
            { id: "3", ImageStatus: require("./../../../../../Assets/Images/imagePerson2.png"), NameUser: "Mohammad", TimeStatus: "امروز 17.45" },
        ],
    };

    FuncSetCamera = () => {
        launchCamera({}, () => {

        });
    };

    FuncOpenMenu = () => {
        this.setState({
            PositionMenuStatus: "55%",
        });
    };

    FuncCloseMenu = () => {
        this.setState({
            PositionMenuStatus: "100%",
        });
    };

    FuncGoToPageSearch = () => {
        this.props.navigation.navigate("SearchStatus");
    };

    FuncSetContacts = () => {
        this.props.navigation.navigate("ScreensContacts");
    };

    FuncSetStatus = () => {
        this.props.navigation.navigate("ScreensStatus");
    };

    FuncSetCalls = () => {
        this.props.navigation.navigate("ScreensCalls");
    };

    FuncGoToPageSettings = () => {
        this.props.navigation.navigate("ScreensSettings");
    };

    FuncGoToPageStatusSettings = () => {
        this.props.navigation.navigate("SettingsStatusSettings");
    };

    FuncAddStatus = () => {
        launchCamera({}, () => {

        });
    };

    FuncGoToPageWriteStatus = () => {
        this.props.navigation.navigate("WriteStatus");
    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <TouchableOpacity activeOpacity={1} onPress={() => {
                    this.FuncCloseMenu();
                }}>
                    <Box name="App" style={styles.app}>
                        {/* Start Section Header */}
                        <Box name="Header" style={styles.header}>
                            {/* Start Section Box Top */}
                            <Box name="Box_Top_App" style={styles.section_top_app}>
                                <Box name="Box_Icons" style={styles.box_icons_section_top_app}>
                                    <TouchableOpacity onPress={() => {
                                        this.FuncOpenMenu();
                                    }} style={styles.button_menu}>
                                        <Entypo name="dots-three-vertical" style={styles.icon_dots} />
                                    </TouchableOpacity>

                                    <TouchableOpacity onPress={() => {
                                        this.FuncGoToPageSearch();
                                    }} style={styles.button_search}>
                                        <AntDesign name="search1" style={styles.icon_search} />
                                    </TouchableOpacity>
                                </Box>

                                <Box style={styles.box_text_section_top_app}>
                                    <Text style={styles.text_section_top_app}>واتساپ</Text>
                                </Box>
                            </Box>
                            {/* End Section Box Top */}

                            {/* Start Section Box Bottom */}
                            <Box name="Box_Bottom_App" style={styles.section_bottom_app}>
                                <Box style={styles.box_icon_camera_section_bottom_app}>
                                    <TouchableOpacity onPress={() => {
                                        this.FuncSetCamera();
                                        this.FuncCloseMenu();
                                    }} style={styles.button_camera}>
                                        <Entypo name="camera" style={styles.icon_camera_section_bottom_app} />
                                    </TouchableOpacity >
                                </Box>

                                <Box style={styles.box_text_contacts_section_bottom_app}>
                                    <TouchableOpacity onPress={() => {
                                        this.FuncSetContacts();
                                        this.FuncCloseMenu();
                                    }} style={styles.button_contacts}>
                                        <Text style={styles.text_contacts_section_bottom_app}>گفتگو</Text>
                                    </TouchableOpacity >
                                </Box>

                                <Box style={styles.box_text_status_section_bottom_app}>
                                    <TouchableOpacity onPress={() => {
                                        this.FuncSetStatus();
                                        this.FuncCloseMenu();
                                    }} style={styles.button_status}>
                                        <Text style={styles.text_status_section_bottom_app}>وضعیت</Text>
                                    </TouchableOpacity>
                                </Box>

                                <Box style={styles.box_text_calls_section_bottom_app}>
                                    <TouchableOpacity onPress={() => {
                                        this.FuncSetCalls();
                                        this.FuncCloseMenu();
                                    }} style={styles.button_calls}>
                                        <Text style={styles.text_calls_section_bottom_app}>تماس ها</Text>
                                    </TouchableOpacity>
                                </Box>
                            </Box>
                            {/* End Section Box Bottom */}
                        </Box>
                        {/* End Section Header */}

                        {/* Start Section Content */}
                        <Box name="Content" style={styles.content}>
                            <Box name="Box_Header_Content" style={styles.box_header_content}>
                                <TouchableOpacity onPress={() => {
                                    this.FuncAddStatus();
                                }}>
                                    <Box style={styles.box_button_add_status}>
                                        <Box name="Box_image_add_status" style={styles.box_image_add_status}>
                                            <Image alt="Image Status" source={require("./../../../../../Assets/Images/ImageSingleProfile.png")} style={styles.image_status} />

                                            <AntDesign name="pluscircle" style={styles.icon_add_statsu} />
                                        </Box>

                                        <Box name="Box_Text_Add_Status" style={styles.box_text_add_status}>
                                            <Text style={styles.text_status_my}>وضعیت من</Text>

                                            <Text style={styles.text_upgrade_status}>برای به روزرسانی وضعیت ضربه بزنید</Text>
                                        </Box>
                                    </Box>
                                </TouchableOpacity>
                            </Box>

                            <Box name="Box_Content_Content" style={styles.box_content_content}>
                                <FlatList data={this.state.data} renderItem={({ item }) => (
                                    <SingleStatus ImageStatus={item.ImageStatus} NameUser={item.NameUser} TimeStatus={item.TimeStatus} />
                                )} />
                            </Box>

                            <Box name="Box_Footer_Content" style={styles.box_footer_content}>
                                <Box name="Box_Button_Add_Status" style={styles.box_button_add_status_footer}>
                                    <TouchableOpacity style={styles.button_add_status} onPress={() => {
                                        this.FuncGoToPageWriteStatus();
                                    }}>
                                        <FontAwesome5 name="pen" style={styles.icon_pen} />
                                    </TouchableOpacity>
                                </Box>

                                <Box name="Box_Button_Camera" style={styles.box_button_camera_footer}>
                                    <TouchableOpacity style={styles.button_camera_footer} onPress={() => {
                                        this.FuncAddStatus();
                                    }}>
                                        <Entypo name="camera" style={styles.icon_camera_footer} />
                                    </TouchableOpacity>
                                </Box>
                            </Box>
                        </Box>
                        {/* End Section Content */}
                    </Box>
                </TouchableOpacity>
                {/* End Section App */}

                {/* Start Section Menu Status */}
                <Box name="Menu_Status" style={styles.menu_status} left={this.state.PositionMenuStatus}>
                    <TouchableOpacity onPress={() => {
                        this.FuncCloseMenu();
                        this.FuncGoToPageStatusSettings();
                    }}>
                        <Box name="Menu_Item" style={styles.menu_item_status}>
                            <Text style={styles.text_menu_item_status}>حریم خصوصی وضعیت</Text>
                        </Box>
                    </TouchableOpacity>

                    <TouchableOpacity onPress={() => {
                        this.FuncCloseMenu();
                        this.FuncGoToPageSettings();
                    }}>
                        <Box name="Menu_Item" style={styles.menu_item_status}>
                            <Text style={styles.text_menu_item_status}>تنظیمات</Text>
                        </Box>
                    </TouchableOpacity>
                </Box>
                {/* End Section Menu Status */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class