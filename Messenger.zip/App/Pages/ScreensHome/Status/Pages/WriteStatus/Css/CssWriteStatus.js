/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import { StyleSheet } from "react-native";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Style
const styles = StyleSheet.create({
    //////////////////////////////// Start Style App
    app: {
        width: "100%",
        height: "100%",
    },

    box_input: {
        width: "100%",
        height: "90%",
        alignItems: "center",
        justifyContent: "center",
    },

    footer: {
        width: "100%",
        height: "10%",
    },

    box_top_footer: {
        width: "100%",
        height: "60%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "flex-end",
        marginRight: 10,
    },

    icon_color_palette_sharp: {
        color: "#fff",
        fontSize: 25,
        marginLeft: 20,
    },

    icon_type: {
        color: "#fff",
        fontSize: 25,
        marginLeft: 20,
    },

    icon_keyboard: {
        color: "#fff",
        fontSize: 25,
        marginLeft: 20,
    },

    box_bottom_footer: {
        width: "100%",
        height: "40%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "flex-end",
        backgroundColor: "#88888888",
        paddingRight: 10,
    },

    text_status: {
        color: "#222",
        fontSize: 16,
    },

    icon_arrow_right: {
        color: "#fff",
        fontSize: 20,
    },
    //////////////////////////////// End Style App
});
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Style
export { styles };