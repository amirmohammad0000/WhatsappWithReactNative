﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity } from "react-native";
import { styles } from "./Css/CssWriteStatus";
import { NativeBaseProvider, Box, Text, Input } from "native-base";
import { MaterialIcons, Ionicons, Feather } from "@expo/vector-icons";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class WriteStatus extends React.Component {
    state = {
        BackgroundColorApp: "#32de84",
        FontWeightStatus: "normal",
    };

    FuncSetBackgroundColorApp = () => {
        let Colors = [
            "#7CB9E8",
            "#7FFFD4",
            "#007FFF",
            "#A3C1AD",
            "#00BFFF",
            "#fd5c63",
            "#C41E3A",
            "#FF7F50",
            "#F400A1",
            "#32de84",
            "#4B5320",
            "#66FF00",
            "#008B8B",
            "#556B2F",
            "#DADD98",
            "#29AB87",
            "#66CDAA",
            "#98FB98",
            "#006241",
            "#008080"
        ];
        let NumberRandom = Math.floor(Math.random() * 20);
        let ColorSelected = Colors[NumberRandom];

        this.setState({
            BackgroundColorApp: ColorSelected,
        });
    };

    FuncSetFontWeightStatus = () => {
        if (this.state.FontWeightStatus === "normal") {
            this.setState({
                FontWeightStatus: "bold",
            });
        } else if (this.state.FontWeightStatus === "bold") {
            this.setState({
                FontWeightStatus: "normal",
            });
        }
    };

    FuncOpenKeyBoard = () => {

    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <Box name="App" style={styles.app} backgroundColor={this.state.BackgroundColorApp}>
                    <Box name="Box_Input" style={styles.box_input}>
                        <Input
                            placeholder="یک وضعیت تایپ کنید"
                            autoFocus={true}
                            width="90%"
                            height="100%"
                            fontWeight={this.state.FontWeightStatus}
                            fontSize={45}
                            color="#fff"
                            variant="ghost" />
                    </Box>

                    <Box name="Footer" style={styles.footer}>
                        <Box name="Box_Top_Footer" style={styles.box_top_footer}>
                            <TouchableOpacity
                                onPress={() => {
                                    this.FuncSetBackgroundColorApp();
                                }}>
                                <Ionicons name="color-palette-sharp" style={styles.icon_color_palette_sharp} />
                            </TouchableOpacity>

                            <TouchableOpacity
                                onPress={() => {
                                    this.FuncSetFontWeightStatus();
                                }}>
                                <Feather name="type" style={styles.icon_type} />
                            </TouchableOpacity>

                            <TouchableOpacity
                                onPress={() => {
                                    this.FuncOpenKeyBoard();
                                }}>
                                <MaterialIcons name="keyboard" style={styles.icon_keyboard} />
                            </TouchableOpacity>
                        </Box>

                        <Box name="Box_Bottom_Footer" style={styles.box_bottom_footer}>
                            <Text style={styles.text_status}>
                                وضعیت(مخاطبین)
                            </Text>

                            <MaterialIcons name="keyboard-arrow-right" style={styles.icon_arrow_right} />
                        </Box>
                    </Box>
                </Box>
                {/* End Section App */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class