﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { FlatList, TouchableOpacity } from "react-native";
import { styles } from "./Css/CssSearchStatus";
import { NativeBaseProvider, Box, Input, Image, Text } from "native-base";
import { launchCamera } from "react-native-image-picker";
import { Entypo, AntDesign, FontAwesome, FontAwesome5 } from "@expo/vector-icons";
import SingleStatus from "./../AppStatusPage/Components/SingleStatus";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class SearchStatus extends React.Component {
    state = {
        data: [
            { id: "1", ImageStatus: require("./../../../../../Assets/Images/imagePerson4.png"), NameUser: "Amir", TimeStatus: "امروز 11.03" },
            { id: "2", ImageStatus: require("./../../../../../Assets/Images/imagePerson5.png"), NameUser: "Hossein", TimeStatus: "امروز 13.53" },
            { id: "3", ImageStatus: require("./../../../../../Assets/Images/imagePerson2.png"), NameUser: "Mohammad", TimeStatus: "امروز 17.45" },
        ],
        ValueInputSearch: "",
    };

    FuncAddStatus = () => {
        launchCamera({}, () => {

        });
    };

    FuncGoToPageWriteStatus = () => {
        this.props.navigation.navigate("WriteStatus");
    };

    FuncGoToPageAppStatusPage = () => {
        this.props.navigation.goBack();
    };

    FuncSetValueInputSearch = (text) => {
        this.setState({
            ValueInputSearch: text,
        });
    };

    FuncRemoveValue = () => {
        this.setState({
            ValueInputSearch: "",
        });
    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <Box name="App" style={styles.app}>
                    {/* Start Section Header */}
                    <Box name="Header" style={styles.header}>
                        <TouchableOpacity onPress={() => {
                            this.FuncGoToPageAppStatusPage();
                        }}>
                            <AntDesign name="arrowright" style={styles.icon_back} />
                        </TouchableOpacity>

                        <Input
                            placeholder="جستجو ..."
                            variant="ghost"
                            width="80%"
                            height="100%"
                            autoFocus={true}
                            fontWeight="bold"
                            value={this.state.ValueInputSearch}
                            onChangeText={(text) => {
                                this.FuncSetValueInputSearch(text);
                            }}
                        />

                        <TouchableOpacity onPress={() => {
                            this.FuncRemoveValue();
                        }}>
                            <FontAwesome name="remove" style={styles.icon_delete} />
                        </TouchableOpacity>
                    </Box>
                    {/* End Section Header */}

                    {/* Start Section Content */}
                    <Box name="Content" style={styles.content}>
                        <Box name="Box_Header_Content" style={styles.box_header_content}>
                            <TouchableOpacity onPress={() => {
                                this.FuncAddStatus();
                            }}>
                                <Box style={styles.box_button_add_status}>
                                    <Box name="Box_image_add_status" style={styles.box_image_add_status}>
                                        <Image alt="Image Status" source={require("./../../../../../Assets/Images/ImageSingleProfile.png")} style={styles.image_status} />

                                        <AntDesign name="pluscircle" style={styles.icon_add_statsu} />
                                    </Box>

                                    <Box name="Box_Text_Add_Status" style={styles.box_text_add_status}>
                                        <Text style={styles.text_status_my}>وضعیت من</Text>

                                        <Text style={styles.text_upgrade_status}>برای به روزرسانی وضعیت ضربه بزنید</Text>
                                    </Box>
                                </Box>
                            </TouchableOpacity>
                        </Box>

                        <Box name="Box_Content_Content" style={styles.box_content_content}>
                            <FlatList data={this.state.data} renderItem={({ item }) => (
                                <SingleStatus ImageStatus={item.ImageStatus} NameUser={item.NameUser} TimeStatus={item.TimeStatus} />
                            )} />
                        </Box>

                        <Box name="Box_Footer_Content" style={styles.box_footer_content}>
                            <Box name="Box_Button_Add_Status" style={styles.box_button_add_status_footer}>
                                <TouchableOpacity style={styles.button_add_status} onPress={() => {
                                    this.FuncGoToPageWriteStatus();
                                }}>
                                    <FontAwesome5 name="pen" style={styles.icon_pen} />
                                </TouchableOpacity>
                            </Box>

                            <Box name="Box_Button_Camera" style={styles.box_button_camera_footer}>
                                <TouchableOpacity style={styles.button_camera} onPress={() => {
                                    this.FuncAddStatus();
                                }}>
                                    <Entypo name="camera" style={styles.icon_camera} />
                                </TouchableOpacity>
                            </Box>
                        </Box>
                    </Box>
                    {/* End Section Content */}
                </Box>
                {/* End Section App */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class