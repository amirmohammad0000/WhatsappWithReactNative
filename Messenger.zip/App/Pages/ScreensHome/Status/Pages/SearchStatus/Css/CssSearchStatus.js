/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import { StyleSheet } from "react-native";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Style
const styles = StyleSheet.create({
    //////////////////////////////// Start Style App
    app: {
        width: "100%",
        height: "100%",
    },
    //////////////////////////////// End Style App

    //////////////////////////////// Start Style Header
    header: {
        width: "100%",
        height: 60,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-evenly",
        backgroundColor: "#ffffff99",
    },

    icon_delete: {
        color: "#777",
        fontSize: 25,
    },

    icon_back: {
        color: "#777",
        fontSize: 25,
    },
    //////////////////////////////// End Style Header

    //////////////////////////////// Start Style Content
    content: {
        width: "100%",
        height: "93%",
    },

    box_header_content: {
        width: "100%",
        height: 70,
    },

    box_button_add_status: {
        width: "100%",
        height: "100%",
        flexDirection: "row",
        alignItems: "center",
    },

    box_image_add_status: {
        width: "20%",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
    },

    image_status: {
        top: 15,
        width: "70%",
        height: "90%",
        borderRadius: 1000,
    },

    icon_add_statsu: {
        top: -12,
        left: 18,
        fontSize: 25,
        color: "#080",
    },

    box_text_add_status: {
        width: "80%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center"
    },

    text_status_my: {
        fontSize: 18,
        color: "#222",
    },

    text_upgrade_status: {
        fontSize: 15,
        color: "#555",
    },

    box_content_content: {
        width: "100%",
        height: "70%",
    },

    box_footer_content: {
        width: "100%",
        height: 140,
        alignItems: "flex-end",
        justifyContent: "space-evenly",
    },

    box_button_add_status_footer: {
        width: "100%",
        height: "50%",
        alignItems: "flex-end",
        justifyContent: "flex-start",
        marginRight: 15,
    },

    button_add_status: {
        width: "10%",
        height: "65%",
        backgroundColor: "#ccc",
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 1000,
    },

    icon_pen: {
        fontSize: 18,
        color: "#555",
    },

    box_button_camera_footer: {
        width: "100%",
        height: "50%",
        alignItems: "flex-end",
        justifyContent: "flex-start",
        marginRight: 10,
    },

    button_camera: {
        width: "12%",
        height: "80%",
        backgroundColor: "#186",
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 1000,
    },

    icon_camera: {
        fontSize: 20,
        color: "#eee",
    },
    //////////////////////////////// End Style Content
});
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Style
export { styles };