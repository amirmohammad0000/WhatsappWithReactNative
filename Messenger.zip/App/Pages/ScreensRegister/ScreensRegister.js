//////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import GetStarted from "./GetStarted/GetStarted";
import ScreensLogin from "./Login/ScreensLogin";
//////////////////////////////////////////////////////////////////////// End Section Import

const Stack = createNativeStackNavigator();

//////////////////////////////////////////////////////////////////////// Start Section Class
export default class ScreensRegister extends React.Component {
    render() {
        return (
            <Stack.Navigator>
                {/* Start Section Stack */}
                <Stack.Screen
                    name="GetStarted"
                    component={GetStarted}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="ScreensLogin"
                    component={ScreensLogin}
                    options={{
                        headerShown: false,
                    }}
                />
                {/* End Section Stack */}
            </Stack.Navigator>
        );
    }
}
//////////////////////////////////////////////////////////////////////// End Section Class