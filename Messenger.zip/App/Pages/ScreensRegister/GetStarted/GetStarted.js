﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity } from "react-native";
import { styles } from "./Css/CssGetStarted";
import { NativeBaseProvider, Box, Text, Image } from "native-base";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class GetStarted extends React.Component {
    FuncGoToPageScreensLogin = () => {
        this.props.navigation.replace("ScreensLogin");
    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <Box name="App" style={styles.app}>
                    <Box name="Header" style={styles.header}>
                        <Text style={styles.text_header}>به پیام رسان خوش آمدید</Text>
                    </Box>

                    <Box name="Content" style={styles.content}>
                        <Image
                            style={styles.image_content}
                            source={require("./../../../Assets/Images/icon.png")}
                            alt="Logo" />
                    </Box>

                    <Box name="Footer" style={styles.footer}>
                        <Text style={styles.text_footer}>شیوه نامه حریم خصوصی مارا بخوانید.برای پذیرش شرایط استفاده از خدمات "تایید و ادامه" را بزنید</Text>

                        <TouchableOpacity style={styles.button_confirmation}
                            onPress={() => {
                                this.FuncGoToPageScreensLogin();
                            }}>
                            <Text style={styles.text_button_confirmation}>تایید و ادامه</Text>
                        </TouchableOpacity>
                    </Box>
                </Box>
                {/* End Section App */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class