/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import { StyleSheet } from "react-native";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Style
const styles = StyleSheet.create({
    //////////////////////////////// Start Style App
    app: {
        width: "100%",
        height: "100%",
    },
    //////////////////////////////// End Style App

    //////////////////////////////// Start Style Header
    header: {
        width: "100%",
        height: "24%",
        alignItems: "center",
        justifyContent: "center",
    },

    text_header: {
        color: "#0a0",
        fontSize: 35,
    },
    //////////////////////////////// End Style Header

    //////////////////////////////// Start Style Content
    content: {
        width: "100%",
        height: "40%",
        alignItems: "center",
        justifyContent: "center",
    },

    image_content: {
        width: "60%",
    },
    //////////////////////////////// End Style Content

    //////////////////////////////// Start Style Footer
    footer: {
        width: "100%",
        height: "36%",
        alignItems: "center",
        justifyContent: "center",
    },

    text_footer: {
        textAlign: "center",
        fontSize: 14,
        paddingRight: 6,
        paddingLeft: 6,
    },

    button_confirmation: {
        width: "60%",
        height: "15%",
        backgroundColor: "#096",
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 2,
        marginTop: 15,
    },

    text_button_confirmation: {
        fontSize: 15,
        color: "#fff",
    },
    //////////////////////////////// End Style Footer
});
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Style
export { styles };