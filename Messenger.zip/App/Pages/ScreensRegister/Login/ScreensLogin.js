//////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import AppLoginPage from "./Pages/AppLoginPage/AppLoginPage";
import Profile from "./Pages/Profile/Profile";
import Sms from "./Pages/Sms/Sms";
//////////////////////////////////////////////////////////////////////// End Section Import

const Stack = createNativeStackNavigator();

//////////////////////////////////////////////////////////////////////// Start Section Class
export default class ScreensLogin extends React.Component {
    render() {
        return (
            < Stack.Navigator >
                {/* Start Section Stack */}
                <Stack.Screen
                    name="AppLoginPage"
                    component={AppLoginPage}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="Profile"
                    component={Profile}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="Sms"
                    component={Sms}
                    options={{
                        headerShown: false,
                    }}
                />
                {/* End Section Stack */}
            </Stack.Navigator >
        );
    };
};
//////////////////////////////////////////////////////////////////////// End Section Class