/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import { StyleSheet } from "react-native";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Style
const styles = StyleSheet.create({
    //////////////////////////////// Start Style App
    app: {
        width: "100%",
        height: "100%",
    },
    //////////////////////////////// End Style App

    //////////////////////////////// Start Style Header
    header: {
        width: "100%",
        height: 50,
        flexDirection: "row-reverse",
        alignItems: "center",
    },

    icon_dots: {
        color: "#000",
        fontSize: 16,
        paddingLeft: 15,
    },

    text_phone_number_before: {
        color: "#080",
        fontSize: 18,
        paddingLeft: 90,
    },
    //////////////////////////////// End Style Header

    //////////////////////////////// Start Style Content
    content: {
        width: "100%",
        height: 200,
        alignItems: "center",
        paddingTop: 30,
    },

    text_confirm_phone_number: {
        textAlign: "center",
        fontSize: 15,
    },

    text_whats_phone_number: {
        color: "#08f",
        fontSize: 15,
    },

    box_select_country: {
        width: "60%",
        height: "15%",
        marginTop: 10,
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "flex-end",
        borderBottomColor: "#098",
        borderBottomWidth: 2,
    },

    text_select_country: {
        color: "#555",
        marginLeft: 110,
    },

    icon_down_content: {
        color: "#555",
        fontSize: 12,
    },

    box_input_content: {
        width: "60%",
        height: "30%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "center",
    },

    box_input_code_phone_number: {
        width: "20%",
        height: "100%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "center",
        marginRight: 8,
        borderBottomColor: "#098",
        borderBottomWidth: 2,
    },

    text_input_code_phone_number: {
        color: "#888",
        fontSize: 15,
        marginRight: 10,
    },

    box_input_phone_number: {
        width: "80%",
        height: "100%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "center",
        borderBottomColor: "#098",
        borderBottomWidth: 2,
    },

    text_bottom_content: {
        textAlign: "center",
        fontSize: 15,
        color: "#666",
        marginTop: 10,
    },
    //////////////////////////////// End Style Content

    //////////////////////////////// Start Style Footer
    footer: {
        position: "absolute",
        bottom: 0,
        width: "100%",
        alignItems: "center",
        justifyContent: "flex-end",
    },

    button_footer: {
        width: 90,
        height: 50,
        backgroundColor: "#096",
        alignItems: "center",
        justifyContent: "center",
        marginBottom: 40,
    },

    text_footer: {
        color: "#eee",
    },
    //////////////////////////////// End Style Footer

    //////////////////////////////// Start Style Menu
    menu: {
        width: "40%",
        height: "7%",
        backgroundColor: "#fff",
        borderRadius: 2,
        position: "absolute",
        top: 0,
        right: 0,
    },

    box_text: {
        width: "100%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
        padding: 10,
    },

    text_menu: {
        color: "#222",
        fontSize: 18,
    },
    //////////////////////////////// End Style Menu

    //////////////////////////////// Start Style Select Code Number
    box_select_code_number: {
        width: "100%",
        height: "100%",
        backgroundColor: "#fff",
        position: "absolute",
    },

    box_header_select_code_number: {
        width: "100%",
        height: 62,
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "space-between",
        borderBottomColor: "#99999999",
        borderBottomWidth: 1,
    },

    icon_search_select_code_number: {
        color: "#aaa",
        fontSize: 22,
        marginRight: 20,
    },

    box_icon_text_select_code_number: {
        width: "35%",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "space-between",
    },

    text_header_select_code_number: {
        color: "#096",
    },

    icon_arrow_select_code_number: {
        color: "#aaa",
        fontSize: 24,
        marginLeft: 20,
    },

    box_country: {
        width: "100%",
        height: "92%",
    },

    box_search_select_code_number: {
        position: "absolute",
        width: "100%",
        height: 62,
        backgroundColor: "#fff",
        flexDirection: "row-reverse",
        alignItems: "center",
        justifyContent: "space-evenly",
    },

    icon_delete_search_select_code_number: {
        color: "#aaa",
        fontSize: 24,
    },

    box_input_search_select_code_number: {
        width: "80%",
        height: "100%",
    },

    icon_arrow_search_select_code_number: {
        color: "#aaa",
        fontSize: 25,
    },
    //////////////////////////////// End Style Select Code Number
});
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Style
export { styles };