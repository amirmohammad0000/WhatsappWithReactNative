﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity, FlatList } from "react-native";
import { styles } from "./Css/CssAppLoginPage";
import { NativeBaseProvider, Box, Input, Text } from "native-base";
import { Entypo, AntDesign } from "@expo/vector-icons";
import SingleItemCountry from "./Components/SingleItemCountry";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class AppLoginPage extends React.Component {
    state = {
        data: [
            {
                id: "1",
                Flag: require("./../../../../../Assets/Images/ImageFlagIran.png"),
                NameCountry: "ایران",
                NumberCode: "+98",
            },
            {
                id: "2",
                Flag: require("./../../../../../Assets/Images/ImageFlagAfghanistan.png"),
                NameCountry: "افغانستان",
                NumberCode: "+93",
            },
            {
                id: "3",
                Flag: require("./../../../../../Assets/Images/ImageFlagArgentina.png"),
                NameCountry: "ارژانتین",
                NumberCode: "+54",
            },
            {
                id: "4",
                Flag: require("./../../../../../Assets/Images/ImageFlagAruba.png"),
                NameCountry: "اروبا",
                NumberCode: "+297",
            },
        ],
        TextSelectCountry: "ایران",
        PositionMenu: "100%",
        PositionBoxSelectCodeNumber: "100%",
        ValueCodeNumber: "98",
        PositionBoxSearchSelectCodeNumber: "100%",
        ValueInputSearch: "",
    };

    FuncSetTextCodeNumber = (text) => {
        this.setState({
            ValueCodeNumber: text,
        });
    };

    FuncGoToPageSms = () => {
        this.props.navigation.replace("Sms");
    };

    FuncCloseMenu = () => {
        this.setState({
            PositionMenu: "100%",
        });
    };

    FuncOpenMenu = () => {
        this.setState({
            PositionMenu: "60%",
        });
    };

    FuncHelp = () => {

    };

    FuncOpenBoxSelectCodeNumber = () => {
        this.setState({
            PositionBoxSelectCodeNumber: "0",
        });
    };

    FuncCloseBoxSelectCodeNumber = () => {
        this.setState({
            PositionBoxSelectCodeNumber: "100%",
        });
    };

    FuncOpenSearchInNumberCode = () => {
        this.setState({
            PositionBoxSearchSelectCodeNumber: "0",
        });
    };

    FuncCloseSearchInNumberCode = () => {
        this.setState({
            PositionBoxSearchSelectCodeNumber: "100%",
        });
    };

    FuncClearTextInputSearch = () => {
        this.setState({
            ValueInputSearch: "",
        });
    };

    FuncSetTextSearchCodeNumber = (text) => {
        this.setState({
            ValueInputSearch: text,
        });
    };

    FuncSetNumberCode = (NumberCode) => {
        let numberCode = NumberCode.split("+")[1];
        this.setState({
            ValueCodeNumber: numberCode,
        });
    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <TouchableOpacity activeOpacity={1} onPress={() => {
                    this.FuncCloseMenu();
                }}>
                    <Box name="App" style={styles.app}>
                        <Box name="Header" style={styles.header}>
                            <TouchableOpacity onPress={() => {
                                this.FuncOpenMenu();
                            }}>
                                <Entypo name="dots-three-vertical" style={styles.icon_dots} />
                            </TouchableOpacity>

                            <Text style={styles.text_phone_number_before}>شماره تلفن قبلی خود را وارد کنید</Text>
                        </Box>

                        <Box name="Content" style={styles.content}>
                            <Text style={styles.text_confirm_phone_number}>پیام رسان میبایست درستی شماره تلفن شما را تایید کند.<Text style={styles.text_whats_phone_number}>شماره من چیست؟</Text></Text>

                            <TouchableOpacity name="Select_Country" style={styles.box_select_country} onPress={() => {
                                this.FuncOpenBoxSelectCodeNumber();
                            }}>
                                <Text style={styles.text_select_country}>{this.state.TextSelectCountry}</Text>

                                <Entypo style={styles.icon_down_content} name="arrow-down" />
                            </TouchableOpacity>

                            <Box name="Box_Input" style={styles.box_input_content}>
                                <Box style={styles.box_input_code_phone_number}>
                                    <Text style={styles.text_input_code_phone_number}>+</Text>
                                    <Input
                                        width="100%"
                                        height="100%"
                                        fontSize={15}
                                        variant="unstyled"
                                        keyboardType="numeric"
                                        value={this.state.ValueCodeNumber}
                                        onChangeText={(text) => {
                                            this.FuncSetTextCodeNumber(text);
                                        }} />
                                </Box>

                                <Box style={styles.box_input_phone_number}>
                                    <Input
                                        width="100%"
                                        height="100%"
                                        fontSize={15}
                                        variant="unstyled"
                                        keyboardType="numeric" />
                                </Box>
                            </Box>

                            <Text style={styles.text_bottom_content}>این ممکن است مشمول هزینه اپراتور مخابراتی باشد</Text>
                        </Box>

                        <Box name="Footer" style={styles.footer}>
                            <TouchableOpacity
                                style={styles.button_footer}
                                onPress={() => {
                                    this.FuncGoToPageSms();
                                }}>
                                <Text style={styles.text_footer}>بعدی</Text>
                            </TouchableOpacity>
                        </Box>
                    </Box>
                </TouchableOpacity>
                {/* End Section App */}

                {/* Start Section Menu */}
                <Box name="Menu" style={styles.menu} left={this.state.PositionMenu}>
                    <TouchableOpacity style={styles.box_text} onPress={() => {
                        this.FuncHelp();
                        this.FuncCloseMenu();
                    }}>
                        <Text style={styles.text_menu}>کمک</Text>
                    </TouchableOpacity>
                </Box>
                {/* End Section Menu */}

                {/* Start Section Select Code Number */}
                <Box name="Box_Select_Code_Number" style={styles.box_select_code_number} left={this.state.PositionBoxSelectCodeNumber}>
                    <Box name="Header_Code_Number" style={styles.box_header_select_code_number}>
                        <TouchableOpacity onPress={() => {
                            this.FuncOpenSearchInNumberCode();
                        }}>
                            <AntDesign name="search1" style={styles.icon_search_select_code_number} />
                        </TouchableOpacity>

                        <Box style={styles.box_icon_text_select_code_number}>
                            <Text style={styles.text_header_select_code_number}>انتخاب کشور</Text>

                            <TouchableOpacity onPress={() => {
                                this.FuncCloseBoxSelectCodeNumber();
                            }}>
                                <Entypo name="arrow-right" style={styles.icon_arrow_select_code_number} />
                            </TouchableOpacity>
                        </Box>
                    </Box>

                    <Box name="Box_Country" style={styles.box_country}>
                        <FlatList style={styles.flat_list_select_code_number} data={this.state.data} renderItem={({ item }) => (
                            <TouchableOpacity onPress={() => {
                                this.FuncCloseBoxSelectCodeNumber();
                                this.FuncSetNumberCode(item.NumberCode);
                            }}>
                                <SingleItemCountry Flag={item.Flag} NameCountry={item.NameCountry} NumberCode={item.NumberCode} />
                            </TouchableOpacity>
                        )} />
                    </Box>
                </Box>

                <Box name="Box_Search_Select_Code_Number" style={styles.box_search_select_code_number} left={this.state.PositionBoxSearchSelectCodeNumber}>
                    <TouchableOpacity onPress={() => {
                        this.FuncClearTextInputSearch();
                    }}>
                        <AntDesign name="close" style={styles.icon_delete_search_select_code_number} />
                    </TouchableOpacity>

                    <Box style={styles.box_input_search_select_code_number}>
                        <Input
                            width="100%"
                            height="100%"
                            fontSize={15}
                            placeholder="جستجوی کشورها"
                            variant="unstyled"
                            value={this.state.ValueInputSearch}
                            onChangeText={(text) => {
                                this.FuncSetTextSearchCodeNumber(text);
                            }} />
                    </Box>

                    <TouchableOpacity onPress={() => {
                        this.FuncCloseSearchInNumberCode();
                    }}>
                        <Entypo name="arrow-right" style={styles.icon_arrow_search_select_code_number} />
                    </TouchableOpacity>
                </Box>
                {/* End Section Select Code Number */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class