/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import { StyleSheet } from "react-native";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Style
const styles = StyleSheet.create({
    //////////////////////////////// Start Style App
    app: {
        width: "100%",
        height: "100%",
    },
    //////////////////////////////// End Style App

    //////////////////////////////// Start Style Header
    header: {
        width: "100%",
        height: 50,
        flexDirection: "row-reverse",
        alignItems: "center",
    },

    icon_dots: {
        color: "#000",
        fontSize: 16,
        paddingLeft: 15,
    },

    text_phone_number_before: {
        color: "#080",
        fontSize: 18,
        paddingLeft: 120,
    },
    //////////////////////////////// End Style Header

    //////////////////////////////// Start Style Content
    content: {
        width: "100%",
        height: "94%",
    },

    box_header_content: {
        width: "100%",
        height: 120,
        alignItems: "center",
        justifyContent: "center",
    },

    text_send_message_content: {
        color: "#222",
        fontSize: 15,
    },

    text_number_wrong: {
        color: "#08f",
        fontSize: 15,
    },

    box_input_code_number_content: {
        width: "40%",
        height: 50,
        borderBottomColor: "#080",
        borderBottomWidth: 2,
        marginBottom: 2,
    },

    text_code_number_content: {
        color: "#222",
        fontSize: 16,
    },

    box_footer_content: {
        width: "100%",
        height: 100,
        alignItems: "flex-start",
        justifyContent: "space-around",
        paddingLeft: 20,
    },

    box_send_again_message: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center",
    },

    icon_send_again_message: {
        color: "#080",
        fontSize: 24,
    },

    text_send_again_message: {
        color: "#222",
        fontSize: 16,
        marginLeft: 20,
    },

    box_call_my: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center",
    },

    icon_call_my: {
        color: "#080",
        fontSize: 24,
    },

    text_call_my: {
        color: "#222",
        fontSize: 16,
        marginLeft: 20,
    },
    //////////////////////////////// End Style Content

    //////////////////////////////// Start Style Menu
    menu: {
        width: "40%",
        height: "7%",
        backgroundColor: "#fff",
        borderRadius: 2,
        position: "absolute",
        top: 0,
        right: 0,
    },

    box_text: {
        width: "100%",
        height: "100%",
        alignItems: "flex-start",
        justifyContent: "center",
        padding: 10,
    },

    text_menu: {
        color: "#222",
        fontSize: 18,
    },
    //////////////////////////////// End Style Menu
});
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Style
export { styles };