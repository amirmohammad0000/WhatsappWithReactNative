﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity } from "react-native";
import { styles } from "./Css/CssSms";
import { NativeBaseProvider, Box, Input, Text } from "native-base";
import { Entypo, Feather } from "@expo/vector-icons";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class Sms extends React.Component {
    state = {
        PositionMenu: "100%",
        TimeForSendMessage: "7",
        ValueCodeMessage: "",
        NumberPhone: "+98 903 964 7011",
    };

    FuncCloseMenu = () => {
        this.setState({
            PositionMenu: "100%",
        });
    };

    FuncGoToBack = () => {
        this.props.navigation.replace("AppLoginPage");
    };

    FuncHelp = () => {

    };

    FuncOpenMenu = () => {
        this.setState({
            PositionMenu: "60%",
        });
    };

    FuncSetTextCodeNumber = (text) => {
        if (this.state.ValueCodeMessage.length === 6) {
            this.props.navigation.replace("Profile");
        } else {
            this.setState({
                ValueCodeMessage: text,
            });
        }
    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <Box name="App" style={styles.app}>
                    {/* Start Section Header */}
                    <Box name="Header" style={styles.header}>
                        <TouchableOpacity onPress={() => {
                            this.FuncOpenMenu();
                        }}>
                            <Entypo name="dots-three-vertical" style={styles.icon_dots} />
                        </TouchableOpacity>

                        <Text style={styles.text_phone_number_before}>در حال تایید شماره شما</Text>
                    </Box>
                    {/* End Section Header */}

                    {/* Start Section Content */}
                    <Box name="Content" style={styles.content}>
                        <Box style={styles.box_header_content}>
                            <Text style={styles.text_send_message_content}>یک پیامک شامل کد به {this.state.NumberPhone} فرستادیم.
                                <Text onPress={() => {
                                    this.FuncGoToBack();
                                }} style={styles.text_number_wrong}>شماره نادرست است؟</Text>
                            </Text>

                            <Box style={styles.box_input_code_number_content}>
                                <Input
                                    width="100%"
                                    height="100%"
                                    fontSize={15}
                                    variant="unstyled"
                                    keyboardType="numeric"
                                    textAlign="center"
                                    value={this.state.ValueCodeMessage}
                                    onChangeText={(text) => {
                                        this.FuncSetTextCodeNumber(text);
                                    }} />
                            </Box>

                            <Text style={styles.text_code_number_content}>کد6-رقمی را وارد کنید</Text>
                        </Box>

                        <Box style={styles.box_footer_content}>
                            <TouchableOpacity>
                                <Box style={styles.box_send_again_message}>
                                    <Entypo name="message" style={styles.icon_send_again_message} />

                                    <Text style={styles.text_send_again_message}>ارسال مجدد پیامک تا {this.state.TimeForSendMessage} ساعت</Text>
                                </Box>
                            </TouchableOpacity>

                            <TouchableOpacity>
                                <Box style={styles.box_call_my}>
                                    <Feather name="phone-call" style={styles.icon_call_my} />

                                    <Text style={styles.text_call_my}>با من تماس بگیر</Text>
                                </Box>
                            </TouchableOpacity>
                        </Box>
                    </Box>
                    {/* End Section Content */}
                </Box>
                {/* End Section App */}

                {/* Start Section Menu */}
                <Box name="Menu" style={styles.menu} left={this.state.PositionMenu}>
                    <TouchableOpacity style={styles.box_text} onPress={() => {
                        this.FuncHelp();
                        this.FuncCloseMenu();
                    }}>
                        <Text style={styles.text_menu}>کمک</Text>
                    </TouchableOpacity>
                </Box>
                {/* End Section Menu */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class