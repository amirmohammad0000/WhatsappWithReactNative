/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import { StyleSheet } from "react-native";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Style
const styles = StyleSheet.create({
    //////////////////////////////// Start Style App
    app: {
        width: "100%",
        height: "100%",
    },
    //////////////////////////////// End Style App

    //////////////////////////////// Start Style Header
    header: {
        width: "100%",
        height: 50,
        alignItems: "center",
        justifyContent: "center",
    },

    text_data_profile: {
        color: "#080",
        fontSize: 18,
    },
    //////////////////////////////// End Style Header

    //////////////////////////////// Start Style Content
    content: {
        width: "100%",
        height: 250,
        alignItems: "center",
        justifyContent: "space-between",
    },

    text_header: {
        color: "#777",
        fontSize: 15,
    },

    image_profile: {
        width: 150,
        height: 150,
        borderColor: "#aaa",
        borderWidth: 1,
        borderRadius: 1000,
    },

    box_input: {
        width: "90%",
        height: 50,
        borderBottomColor: "#080",
        borderBottomWidth: 2,
    },
    //////////////////////////////// End Style Content

    //////////////////////////////// Start Style Footer
    footer: {
        position: "absolute",
        bottom: 0,
        width: "100%",
        alignItems: "center",
        justifyContent: "flex-end",
    },

    button_footer: {
        width: 90,
        height: 50,
        backgroundColor: "#096",
        alignItems: "center",
        justifyContent: "center",
        marginBottom: 40,
    },

    text_footer: {
        color: "#eee",
    },
    //////////////////////////////// End Style Footer

    //////////////////////////////// Start Style Select Box Image
    box_select_box_image: {
        position: "absolute",
        bottom: 0,
        width: "100%",
        height: 100,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "flex-start",
        backgroundColor: "#fff",
    },

    box_gallery: {
        width: 120,
        height: 100,
        alignItems: "center",
        justifyContent: "center",
        paddingLeft: 10,
        paddingRight: 10,
    },

    image_gallery: {
        width: "60%",
        height: "60%",
    },

    text_gallery: {
        color: "#444",
        fontSize: 20,
    },

    box_camera: {
        width: 120,
        height: 100,
        alignItems: "center",
        justifyContent: "center",
        paddingLeft: 10,
        paddingRight: 10,
        borderLeftColor: "#aaa",
        borderLeftWidth: 1,
    },

    image_camera: {
        width: "60%",
        height: "60%",
    },

    text_camera: {
        color: "#444",
        fontSize: 20,
    },
    //////////////////////////////// End Style Select Box Image
});
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Style
export { styles };