﻿/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Import
import React from "react";
import { TouchableOpacity } from "react-native";
import { styles } from "./Css/CssProfile";
import { launchCamera, launchImageLibrary } from "react-native-image-picker";
import { NativeBaseProvider, Image, Box, Input, Text } from "native-base";
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Import

/////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class Profile extends React.Component {
    state = {
        ValueNameUser: "",
        PositionSelectBoxImage: "100%",
        PathImageProfile: "",
    };

    FuncSetTextNameUser = (text) => {
        this.setState({
            ValueNameUser: text,
        });
    };

    FuncGoToPageScreensHome = () => {
        this.props.navigation.replace("ScreensHome");
    };

    FuncOpenCloseSelectBoxImage = () => {
        if (this.state.PositionSelectBoxImage === "100%") {
            this.setState({
                PositionSelectBoxImage: "0",
            });
        } else {
            this.setState({
                PositionSelectBoxImage: "100%",
            });
        }
    };

    FuncGetImageFromGallery = () => {
        launchImageLibrary({}, (response) => {
            response.assets.forEach((item) => {
                if (item.uri !== "") {
                    this.setState({
                        PathImageProfile: item.uri,
                    });
                }
            });
        });
    };

    FuncGetImageFromCamera = () => {
        launchCamera({}, (response) => {
            response.assets.forEach((item) => {
                if (item.uri !== "") {
                    this.setState({
                        PathImageProfile: item.uri,
                    });
                }
            });
        });
    };

    render() {
        return (
            <NativeBaseProvider>
                {/* Start Section App */}
                <TouchableOpacity
                    activeOpacity={1}
                    onPress={() => {
                        this.FuncOpenCloseSelectBoxImage();
                    }}>
                    <Box name="App" style={styles.app}>
                        <Box name="Header" style={styles.header}>
                            <Text style={styles.text_data_profile}>اطلاعات پروفایل</Text>
                        </Box>

                        <Box name="Content" style={styles.content}>
                            <Text style={styles.text_header}>لطفا نام خود را وارد کنید و یک تصویر نمایه اختیاری برای خود انتخاب کنید</Text>

                            <TouchableOpacity onPress={() => {
                                this.FuncOpenCloseSelectBoxImage();
                            }}>
                                <Image source={{ uri: this.state.PathImageProfile }} alt="Image Profile" style={styles.image_profile} />
                            </TouchableOpacity>

                            <Box name="Box_Input" style={styles.box_input}>
                                <Input
                                    width="100%"
                                    height="100%"
                                    fontSize={15}
                                    variant="unstyled"
                                    placeholder="نام خود را اینجا وارد کنید"
                                    value={this.state.ValueNameUser}
                                    onChangeText={(text) => {
                                        this.FuncSetTextNameUser(text);
                                    }} />
                            </Box>
                        </Box>

                        <Box name="Footer" style={styles.footer}>
                            <TouchableOpacity
                                style={styles.button_footer}
                                onPress={() => {
                                    this.FuncGoToPageScreensHome();
                                }}>
                                <Text style={styles.text_footer}>بعدی</Text>
                            </TouchableOpacity>
                        </Box>
                    </Box>
                </TouchableOpacity>
                {/* End Section App */}

                {/* Start Section Select Box Image */}
                <Box name="Box_Select_Box_Image" style={styles.box_select_box_image} left={this.state.PositionSelectBoxImage}>
                    <TouchableOpacity onPress={() => {
                        this.FuncGetImageFromGallery();
                        this.FuncOpenCloseSelectBoxImage();
                    }}>
                        <Box style={styles.box_gallery}>
                            <Image style={styles.image_gallery} alt="Image Camera" source={require("./../../../../../Assets/Images/ImageGallery.png")} />

                            <Text style={styles.text_gallery}>از گالری</Text>
                        </Box>
                    </TouchableOpacity>

                    <TouchableOpacity onPress={() => {
                        this.FuncGetImageFromCamera();
                        this.FuncOpenCloseSelectBoxImage();
                    }}>
                        <Box style={styles.box_camera}>
                            <Image style={styles.image_camera} alt="Image Galery" source={require("./../../../../../Assets/Images/ImageCamera.png")} />

                            <Text style={styles.text_camera}>از دوربین</Text>
                        </Box>
                    </TouchableOpacity>
                </Box>
                {/* End Section Select Box Image */}
            </NativeBaseProvider>
        );
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////// End Section Class